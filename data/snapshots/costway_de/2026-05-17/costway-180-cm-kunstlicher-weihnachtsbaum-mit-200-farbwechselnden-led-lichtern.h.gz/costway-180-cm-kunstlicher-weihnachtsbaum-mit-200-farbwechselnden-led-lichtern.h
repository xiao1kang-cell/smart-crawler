<!doctype html>
<html lang="de">
    <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# product: http://ogp.me/ns/product#">
                <meta charset="utf-8"/>
<meta name="title" content="180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern - Costway"/>
<meta name="description" content="Costway 180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern 








Für eine festliche Atmosphäre!Unser 180cm hoher Weihnachtsbaum ist eine tolle Wahl. Er hat 423 verschneite Zweige, die ihm ein dichtes und üppiges Aussehen ve"/>
<meta name="keywords" content="künstlicher weihnachtsbaum, verschneiter beleuchteter weihnachtsbaum, klappbarer weihnachtsbaum, weihnachtsbaum für innen- und außendekoration, verschneiter weihnachtsbaum, weihnachtsbaum mit LED lichtern und metallständer, dichter weihnachtsbaum
"/>
<meta name="robots" content="INDEX,FOLLOW"/>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0"/>
<meta name="format-detection" content="telephone=no"/>
<title>180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern  - Costway</title>
<link  rel="stylesheet" type="text/css"  media="all" href="https://www.costway.de/static/version1778723978/_cache/merged/89d1ce6a9820717dbaa37fc35977182d.min.css" />
<link  rel="stylesheet" type="text/css"  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
<link  rel="stylesheet" type="text/css"  media="screen and (min-width: 768px)" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/css/styles-l.min.css" />
<link  rel="stylesheet" type="text/css"  media="print" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/css/print.min.css" />
<link  rel="stylesheet" type="text/css"  rel="stylesheet" type="text/css" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/css/toastr.min.css" />
<link  rel="stylesheet" type="text/css"  media="all" rel="stylesheet" type="text/css" href="/pub/images/swiper.min.css" />















<link rel="preload" as="font" crossorigin="anonymous" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/fonts/Blank-Theme-Icons/Blank-Theme-Icons.woff2" />
<link  rel="stylesheet" type="text/css" href="/pub/images/jquery.scrollbar.css" />
<link  rel="icon" type="image/x-icon" href="https://www.costway.de/media/favicon/stores/1/favicon.ico" />
<link  rel="shortcut icon" type="image/x-icon" href="https://www.costway.de/media/favicon/stores/1/favicon.ico" />
<link rel="preload" href="https://cdn1.costway.com/cgs-assets/tracking.js?lang=de" as="script">
<script data-no-defer="true" type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://cdn1.costway.com/cgs-assets/tracking.js?lang=de"></script>
<script data-no-defer="true" type="b582c3d0dfb6bd35c494053c-text/javascript">
setConfig({country:'de'})
function initializeCountdown() {
            const countdownElements = document.querySelectorAll('.end-days-emarsys');
            if (countdownElements.length === 0) return;

            countdownElements.forEach(function (countdownElement) {
                let dropCountdownTime = parseInt(countdownElement.getAttribute("data-countdown"), 10);
                const timer = setInterval(function () {
                    if (dropCountdownTime <= 0) {
                    clearInterval(timer);
                    countdownElement.closest('.emars-tagwrap').style.display = 'none';
                    return;
                    }
                    let days = Math.floor(dropCountdownTime / (60 * 60 * 24));
                    let hours = Math.floor((dropCountdownTime % (60 * 60 * 24)) / (60 * 60));
                    let minutes = Math.floor((dropCountdownTime % (60 * 60)) / 60);
                    let seconds = dropCountdownTime % 60;
                    if (days > 0) {
                        hours = days * 24 + hours;
                    }
                    hours = hours > 9 ? hours : '0' + hours;
                    minutes = minutes > 9 ? minutes : '0' + minutes;
                    seconds = seconds > 9 ? seconds : '0' + seconds;
                    countdownElement.textContent = hours + " : " + minutes + " : " + seconds;
                    dropCountdownTime -= 1;
                }, 1000);
            });
        }
</script>
<!-- Emarsys global  -->
<script data-no-defer="true" type="b582c3d0dfb6bd35c494053c-text/javascript">
    var ScarabQueue = ScarabQueue || [];
    (function(id) {
      if (document.getElementById(id)) return;
      var js = document.createElement('script'); js.id = id;
      js.src = '//cdn.scarabresearch.com/js/10E1F72114CD2ADC/scarab-v2.js';
      var fs = document.getElementsByTagName('script')[0];
      fs.parentNode.insertBefore(js, fs);
    })('scarab-js-api');
    // 全局价格格式化
    var formatPrice =function (price,fraction_digits) {
        const priceNumber = parseFloat(price);
        return new Intl.NumberFormat('de-DE', {
            currency: 'EUR',
             minimumFractionDigits: priceNumber >= 1000 && Number.isInteger(priceNumber)  && fraction_digits ===  'undefined' ? 0 : 2,  
             maximumFractionDigits: 2
        }).format(priceNumber)
      }
    var setPositionLoadingBox =  function (element) {
        element.style.position = 'relative';
        element.classList.add('has-loading-box');
        element.insertAdjacentHTML('beforeend', '<div class="costway-loading-box"><div class="costway-loading"></div></div>');
    }
</script>    
<!-- Emarsys global end -->

<style>  
.block-new-products .block-title-main {display: none;}
    .has-loading-box .costway-loading-box {
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 999999;
        background: rgba(255, 255, 255, 0.6);
        position: absolute;
        z-index: 1;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
    }
    .has-loading-box .costway-loading-box .costway-loading {
        border-radius: 50%;
        margin: 0 auto;
        animation-name: spinner-rotate;
        animation-duration: 0.8s;
        animation-timing-function: linear;
        animation-iteration-count: infinite;
        border-style: solid;
        width: 30px;
        height: 30px;
        border-width: 2px;
        -webkit-transform-origin: 50% 50% calc((16px / 2) + 2px);
        transform-origin: 50% 50% calc((16px / 2) + 2px);
        border-color: rgba(82, 82, 82, 0.25);
        border-top-color: #525252;
    }
    @keyframes spinner-rotate {
        0% {
        transform: rotate(0);
        }
        100% {
        transform: rotate(360deg);
        }
    }   


/* 第三方图标 */
.cmpwrapper{
position: relative;
    z-index: 1010;
}

body .crisp-client .cc-1brb6 {z-index: 80;}
body #crisp-chatbox > div > a.cc-1m2mf {
    right: 42.5px !important;
    bottom: 20px  !important;
}

@media (max-width: 1480px) {
   body #crisp-chatbox > div > a.cc-1m2mf {
    right: 2.5px !important;
}
}

@media (max-width: 750px) {
    body #crisp-chatbox > div > a.cc-1m2mf {
        bottom: 32px;
right: 7.5px !important;
    }

    .cms-index-index #crisp-chatbox > div > a.cc-1m2mf {
        bottom: 12vw !important;
    }

    .cms-index-index .scrollup {
        bottom: calc(12vw + 64px) !important;
    }

    .catalog-product-view #crisp-chatbox > div > a.cc-1m2mf {
        bottom: 28vw !important;
    }

    .catalog-product-view .scrollup {
        bottom: calc(28vw + 64px) !important;
    }

}

.ui-helper-hidden-accessible {
    display: none !important;
    visibility: hidden !important;
}
#search_mini_form .amxnotif-container {display:none  !important; }
</style>
<!-- Emarsys global end -->

<link rel="manifest" href="/manifest.json" />

<!-- Emarsys Web Push  -->
<script data-no-defer="true" type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://assets.emarsys.net/web-emarsys-sdk/4.5.0/web-emarsys-sdk.js" async></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" data-no-defer="true">
    // initialization - start
    var WebEmarsysSdk = WebEmarsysSdk || [];
    WebEmarsysSdk.push([
        "init",
        {
            applicationCode: "EMS8A-77F27", // your Domain code obtained above
            //enableMacSafariVapid: true, // If true, enables VAPID instead of APNS for Safari on Mac
            safariWebsitePushID: "web.com.costway.de",
            defaultNotificationTitle: "www.costway.de", // sets your default title for push notifications
            defaultNotificationIcon: "https://cdn1.costway.com/offline-package/appstatic/logo/logo_webpush.png", // URL to your notification icon
            autoSubscribe: false, // If true, prompts a user to subscribe for pushes upon SDK initialization which is not recommended
            enableLogging: true,
            serviceWorker: {
                url: "service-worker.js",
                applicationServerPublicKey: "BLFZAoG8bWa6l74BGZQu_1fCTLZcgijlcBioUsFPMTvJPnhxlGcgqQT6HxAOiTZFrulDu9-8HczOAYDX0LDgtcs",
            },
        },
    ]);
    // initialization - end
</script>
<!-- Emarsys Web Push end -->
<link rel="preconnect" href="https://www.googletagmanager.com">
 <link rel="preconnect" href="https://maps.googleapis.com">
 <link rel="preconnect" href="https://accounts.google.com">



<!-- Google Tag Manager -->
<script data-no-defer="true" type="b582c3d0dfb6bd35c494053c-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WXMKW85');</script>
<!-- End Google Tag Manager -->

<!--test-->



<style>
.coupons-tips{display:flex !important}

header.page-header.htype-4 .block-search {
z-index:5  !important
}
.product-info-main .product.attibute.overview,.product-info-main .product.attribute.overview {
display:none  !important;
}
</style>






<style>
header.page-header.htype-4 .nav-sections .navigation>ul li.level0.parent>a.level-top {
    padding-left: 20px  !important;
}
header.page-header.htype-4 .nav-sections .navigation>ul li.level0.parent:last-child>a.level-top {
    padding-right: 0;
}
.page-products .category-view {display: block;}
.cart-container .cart-discount{
   display:none !important;
}

@media (min-width:767px){
     .catalog-product-view .amrelated-grid-wrapper .product-item-details {
         max-width:175px;
     }

.catalogsearch-result-index .no-search-results{
 margin-left:0 !important;
}

}

</style>


<style>
    .old-price .price-final_price .price-wrapper .price{color:#999 !important}
    .cms-index-index .old-price .price,
    .catalog-category-view .old-price .price,
    .catalog-product-view .old-price .price,
    .catalogsearch-result-index .old-price .price{text-decoration: line-through !important}

    .cms-index-index .old-price,
    .catalog-category-view .old-price,
    .catalogsearch-result-index .old-price,
    .catalog-product-view .old-price{text-decoration: none !important;font-weight: bold !important;color:#999 !important; }
</style>


<style>
    input::-webkit-input-placeholder {color: #999 !important;}
    #shipping-new-address-form label span,#shipping-new-address-form legend span{font-weight: bold !important;}
</style>

<style>
header.page-header.htype-4 .nav-sections .navigation>ul li.level0.parent>a.level-top {
    padding-left: 30px !important;
}


.catalog-product-view .page-detail-delivery-time{
    display: none !important;
}

.product_list_container .classfy-link ul #blog #blog-content > p:nth-child(1) > div > strong > a {
    display: inline-block;
    padding: 0px 15px;
    height: 36px;
    line-height: 36px;
    background: #fff;
    color: #333;
    font-size: 16px;
    cursor: pointer;
    border-radius: 30px;
    margin-bottom: 15px;
    border: 1px solid #cccccc;
    transition: all .3s;
    margin-right: 15px;
}
.product_list_container .classfy-link ul #blog #blog-content > p:nth-child(1) > div > strong > a:hover {
    background-color: #FDAC0E;
    color: #ffffff;
    opacity: 0.6;
}
.amrelated-grid-wrapper .product-item-photo .price-drop-list .price-drop-con .end-days-emarsys {font-size: 12px;}

@media (max-width:767px){
     .catalog-product-view .amrelated-grid-wrapper .slick-slide {
        width: 44vw !important;
     }
.amrelated-grid-wrapper .product-item-photo .price-drop-list .price-drop-con {padding-left: 23vw;}
   .amrelated-grid-wrapper .product-item-photo .price-drop-list .price-drop-con .end-days-emarsys {font-size: 3.2vw;}
}

.search-suggestions a {margin:0 12px 0 0 !important; }

@media (min-width:750px) {
    .new-nav-main .nav_list>li:nth-child(8){
        .nav-title-group{
            margin-top:0 !important; 
        }
    }
}
</style>

<script  data-no-defer="true"  type="text/plain" class="cmplazyload" data-cmp-vendor="s366">
(function (w,d,dn,t){w[dn]=w[dn]||[];w[dn].push({eventType:'init',value:t,dc:''});
var f=d.getElementsByTagName('script')[0],c=d.createElement('script');c.async=true;
c.src='https://tags.creativecdn.com/5qif67DrrUC6SvjvdUwJ.js';
f.parentNode.insertBefore(c,f);})(window,document,'rtbhEvents','5qif67DrrUC6SvjvdUwJ');
</script>            






<style>
    picture.mfwebp source.lazyload,
    picture.mfwebp source.lazy {background:none;content:none;}
</style>
<style>
    #social-login-popup .social-login-title {
        background-color: #6e716e    }

    #social-login-popup .social-login #bnt-social-login-authentication,
    #social-login-popup .forgot .primary button,
    #social-login-popup .create .primary button,
    #social-login-popup .fake-email .primary button {
        background-color: #6e716e;
        border: #6e716e    }

    .block.social-login-authentication-channel.account-social-login .block-content {
        text-align: center;
    }

    
                    #bnt-social-login-fake-email {
                    background-color: grey !important;
                    border: grey !important;
                    }

                    #request-popup .social-login-title {
                    background-color: grey !important;
                    }
                
    /* Compatible ETheme_YOURstore*/
    div#centerColumn .column.main .block.social-login-authentication-channel.account-social-login {
        max-width: 900px !important;
        margin: 0 auto !important;
    }

    div#centerColumn .column.main .block.social-login-authentication-channel.account-social-login .block-content {
        text-align: center;
    }

    @media (max-width: 1024px) {
        div#centerColumn .column.main .block.social-login-authentication-channel.account-social-login .block-content {
            padding: 0 15px;
        }
    }
</style>

<!-- <link rel="stylesheet" type="text/css" media="all" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css"> -->
    <link rel="canonical" href="https://www.costway.de/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html"/>

<meta property="og:type" content="product" />
<meta property="og:title"
      content="180&#x20;cm&#x20;K&#xFC;nstlicher&#x20;Weihnachtsbaum&#x20;mit&#x20;200&#x20;Farbwechselnden&#x20;LED-Lichtern" />
<meta property="og:image"
      content="https://www.costway.de/media/catalog/product/cache/91b17ec672c43b669d01d5228e518663/k/_/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_2_.jpg" />
<meta property="og:description"
      content="F&#xFC;r&#x20;eine&#x20;festliche&#x20;Atmosph&#xE4;re&#x21;" />
<meta property="og:url" content="https://www.costway.de/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html" />
    <meta property="product:price:amount" content="96.99"/>
    <meta property="product:price:currency"
      content="EUR"/>
        </head>
    <body data-container="body"
          data-mage-init='{"loaderAjax": {}, "loader": { "icon": "https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/images/loader-2.gif"}}'
        id="html-body" itemtype="http://schema.org/Product" x-itemscope="x-itemscope" class="catalog-product-view product-costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern page-layout-1column">
        
<link rel="preload" as="font" href="https://cdn1.costway.de/public/font/poppins-regular.ttf" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" media="all" href="https://www.costway.de/media/adbeaut/generated_css/design_default.css">
    <link rel="stylesheet" type="text/css" media="all" href="https://www.costway.de/media/adbeaut/generated_css/settings_default.css">

<link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/requirejs/require.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/requirejs-config.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/mage/requirejs/mixins.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/jquery.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle0.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle1.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle2.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle3.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle4.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle5.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle6.min.js" as="script"><link rel="preload" href="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle7.min.js" as="script">
    
    




    <link rel="stylesheet" type="text/css" media="all" href="https://www.costway.de/media/megamenu/generated_css/megamenu_default.css">




<div class="cookie-status-message" id="cookie-status" style="display: none;">
    The store will not work correctly in the case when cookies are disabled.</div>




    <noscript>
        <div class="message global noscript">
            <div class="content">
                <p>
                    <strong>JavaScript seems to be disabled in your browser.</strong>
                    <span>
                        For the best experience on our site, be sure to turn on Javascript in your browser.                    </span>
                </p>
            </div>
        </div>
    </noscript>



                <div class="page-wrapper">

<!--增强转化email end-->
<!-- SEO 增加H1 -->

        <header class="page-header htype-4 ">
    <div id="header-fixed-box">
        <div class="panel wrapper">
                            <div class="header-widget">
                    <ul class="header-lb">
                                                    <li class="slide-item">
                                <a href="/vatertag?entrypoint=top_banner">
                                                                            <picture>
                                            <source media="(max-width: 750px)" srcset="/media/advertising/7/1/714-70_10.jpg">
                                            <img loading="eager" fetchpriority="high" src="/media/advertising/1/9/1920-40_11.jpg" 
                                                width="1920" height="40" alt="">
                                        </picture>
                                                                    </a>
                            </li>
                                                    <li class="slide-item">
                                <a href="/gartenfest?entrypoint=top_banner">
                                                                            <picture>
                                            <source media="(max-width: 750px)" data-srcset="/media/advertising/7/1/714x70_top_banner_3.jpg">
                                            <img class="swiper-lazy" data-src="/media/advertising/1/9/1920x40_top_banner_3.jpg" 
                                                width="1920" height="40" alt="">
                                        </picture>
                                                                    </a>
                            </li>
                                                    <li class="slide-item">
                                <a href="/haushaltsgerate/klimaanlagen-ventilatoren.html?entrypoint=top_banner">
                                                                            <picture>
                                            <source media="(max-width: 750px)" data-srcset="/media/advertising/7/1/714_70.png">
                                            <img class="swiper-lazy" data-src="/media/advertising/1/9/1920_40.png" 
                                                width="1920" height="40" alt="">
                                        </picture>
                                                                    </a>
                            </li>
                                            </ul>
                </div>
                
            <div class="link lan-main">
                <div class="language">
                    <a href="#" onclick="if (!window.__cfRLUnblockHandlers) return false; event.preventDefault();" class="default-lan" data-cf-modified-b582c3d0dfb6bd35c494053c-=""><img src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/images/de.png" alt="DE"></a>
                    <ul class="lan-box">
                        <li class="lan_list"><a href="https://www.costway.com/"><i class="usa"></i><span>USA</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.co.uk/"><i class="uk"></i><span>GBR</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.it/"><i class="it"></i><span>ITA</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.ca/"><i class="ca"></i><span>CAN</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.fr/"><i class="fr"></i><span>FRA</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.es/"><i class="es"></i><span>ESP</span></a></li>
                        <li class="lan_list"><a href="https://costway.pl"><i class="pol"></i><span>POL</span></a></li>
                        <li class="lan_list"><a href="https://au.costway.com/"><i class="aus"></i><span>AUS</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.at/"><i class="at"></i><span>AUT</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.be/"><i class="be"></i><span>BEL</span></a></li>
                        <li class="lan_list"><a href="https://nl.costway.com/"><i class="nl"></i><span>NLD</span></a></li>
                        <li class="lan_list"><a href="https://www.costway.se/"><i class="swe"></i><span>SWE</span></a></li>
                    </ul>
                </div>
            </div>

            <div class="panel header">
                <a class="action skip contentarea"
   href="#contentarea">
    <span>
        Skip to Content    </span>
</a>
                                                <ul class="header links"><li class="item link compare" data-bind="scope: 'compareProducts'" data-role="compare-products-link">
    <a class="action compare no-display" title="Produkte&#x20;vergleichen"
       data-bind="attr: {'href': compareProducts().listUrl}, css: {'no-display': !compareProducts().count}"
    >
        Produkte vergleichen        <span class="counter qty" data-bind="text: compareProducts().countCaption"></span>
    </a>
</li>

    <li class="greet welcome" data-bind="scope: 'customer'">
        <!-- ko if: customer().fullname  -->
        <span class="logged-in"
              data-bind="text: new String('Willkommen, %1!').replace('%1', customer().fullname)">
        </span>
        <!-- /ko -->
        <!-- ko ifnot: customer().fullname  -->
        <span class="not-logged-in"
              data-bind="html: 'Kostenloser&#x20;Versand&#x20;innerhalb&#x20;Deutschlands&#x21;'"></span>
                <!-- /ko -->
    </li>
    
<li><a href="https://www.costway.de/customer/account/" id="idFhr7kzSb" >Mein Konto</a></li><li class="link wishlist" data-bind="scope: 'wishlist'">
    <a href="https://www.costway.de/wishlist/">Meine Wunschliste        <!-- ko if: wishlist().counter -->
        <span data-bind="text: wishlist().counter" class="counter qty"></span>
        <!-- /ko -->
    </a>
</li>

<li><a href="https://www.costway.de/customer/account/create/" id="idGnxm7s2p" >Ein Konto erstellen</a></li>    <li class="link authorization-link" data-label="Oder">
        <a href="/customer/account/create">Registrieren</a>
    </li>
</ul>            </div>
        </div>
        <div class="header content">
            <style>
    .backto-cart {
        color: #666666 !important;
        font-size: 16px;
        float: right;
        margin-top: 38px;
        margin-right: 6px;
        display: none;
    }
    .backto-cart svg {
        width: 7px;
        height: 12px;
        margin-left: 3px;
    }
    .backto-cart svg path {
        fill: #666666;
    }
    .checkout-index-index .backto-cart {
        display: block;
    }
    @media screen and (max-width: 767px) {
        .checkout-index-index .backto-cart {
            display: none;
        }  
    }
</style>

<span data-action="toggle-nav" class="action nav-toggle"><span>Toggle Nav</span></span>
<a
    class="logo"
    href="https://www.costway.de/"
    title="COSTWAY"
    aria-label="store logo">
    <img src="https://www.costway.de/media/logo/stores/1/logo.gif"
         title="COSTWAY"
         alt="COSTWAY"
            width="314"            height="66"    />
</a>

<a href="/checkout/cart" class="backto-cart">
    Zurück zum Warenkorb 
    <svg class="svg_left_arrow" viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-81f499ba=""><path d="M0.211203 1.15676L5.37611 5.99978L0.211203 10.8432C0.147864 10.9026 0.0966584 10.9741 0.0605105 11.0536C0.0243626 11.1331 0.00397997 11.219 0.000526936 11.3065C-0.0029261 11.394 0.010618 11.4813 0.0403856 11.5635C0.0701531 11.6457 0.115561 11.7211 0.174018 11.7854C0.232474 11.8498 0.302833 11.9018 0.381079 11.9385C0.459324 11.9753 0.543924 11.996 0.630047 11.9995C0.716169 12.003 0.802129 11.9892 0.883017 11.959C0.963906 11.9287 1.03814 11.8826 1.10148 11.8232L6.78874 6.48999C6.85535 6.42756 6.90851 6.3518 6.94487 6.26747C6.98123 6.18313 7 6.09207 7 6C7 5.90793 6.98123 5.81687 6.94487 5.73253C6.90851 5.6482 6.85535 5.57244 6.78874 5.51001L1.10148 0.176783C1.03814 0.117398 0.963906 0.0712679 0.883017 0.0410272C0.802129 0.0107865 0.716169 -0.0029726 0.630047 0.00053532C0.543924 0.00404324 0.459324 0.0247495 0.381079 0.0614721C0.302833 0.0981946 0.232474 0.150214 0.174018 0.214561C0.115561 0.278907 0.0701531 0.35432 0.0403856 0.436494C0.010618 0.518669 -0.0029261 0.605994 0.000526936 0.693486C0.00397997 0.780978 0.0243626 0.866922 0.0605105 0.946411C0.0966584 1.0259 0.147864 1.09738 0.211203 1.15676Z" fill="#333333" data-v-81f499ba=""></path></svg>
</a>
            <div class="header-search-icon">
                
            </div>
            <style>
    .user-login{
        position: relative;
        transition: all .2s;
        cursor: pointer;
        display: inline-block;
        height: auto;
        padding: 0;
        margin: 25px 20px 0 10px;
        float: right;
    }
    .user-login-icon{
        display:inline-block;
        width: 30px;
        height:30px;
        background: url(/pub/images/user-nav/user-icon-pc.png) center center no-repeat;
        background-size: 100% 100%;
    }
   @media screen and (min-width: 1201px) {
    .user-login:hover .user-login-list{
        display: block;
    }
    }
    
    .user-login .user-login-list{
        display: none;
        position: absolute;
        top: 30px;
        left: -87px;
        width: 350px;
        max-height: 350px;
        overflow-y: auto;
        background: #FFFFFF;
        box-shadow: 0px 2px 8px rgb(157 157 157 / 25%);
        z-index: 99;
    }
    .user-login .user-login-list{
        padding: 10px 20px;
        border-radius: 0.1875rem;
        box-shadow: 0 2px 5px rgb(0 0 0 / 15%);
        width: 188px;
        left: -86px;
    }
    .user-login .user-login-list li a{
        display: block;
        margin: 10px 0;
        text-align: left;
    }
    .user-login .user-login-list li a:hover{
        color: #FFC842;
    }
    .page-header.htype-4 .header.panel{
        display: none;
    }
    .user-login-list .milestone-badge {
        border-top: 1px solid #e4e4e4;
    }
    .user-login .user-login-list .logged-in a {
        border: 1px solid #FDAC0E;
        height: 28px;
        line-height: 28px;
        border-radius: 28px;
        color: #FDAC0E;
        text-align: center;
        margin: 10px -5px 0;
    }
    .user-login .user-login-list .myrewardszone a {
        background-color: #FFF2E2;
        height: 32px;
        line-height: 32px;
        border-radius: 20px;
        color: #F97E05;
        padding-left: 12px;
        position: relative;
        margin: 0 -5px;
    }
    .user-login .user-login-list .myrewardszone a::after {
        content: '';
        background-image: url('/pub/images/user-nav/myrewardszone-pc.png');
        position: absolute;
        right: 10px;
        top: 4px;
        width: 24px;
        height: 24px;
        display: block;
    }
    @media only screen and (max-width: 1200px) {
        .user-login{
            position: absolute;
            top: 15px;
            width: 30px;
            height: 30px;
            right: 65px;
            margin: 0;
            padding: 0;            
        }      
        header.page-header.htype-4 .block-search .block-content{
            margin-top: 0px!important;
        }
        header.page-header.htype-4 .block-search .block.block-content .actions .action.search{
            top: 5px !important;
        }
        

    }
    @media (max-width: 767px) {
        .user-login{
            width: 5.33vw;
            height: 5.33vw;
            right: calc(5.33vw + 4vw + 15px);
        }
         .user-login-icon{
            display:inline-block;
            width: 5.33vw;
            height:5.33vw;
            background: url("/pub/images/user-nav/user-icon-mb.png") center center no-repeat;
            background-size: 100% 100%;
        }
    }
</style>
</style>
<div data-block="minicart" class="minicart-wrapper">
    <a class="action showcart" id="mini-cart-icon" href="https://www.costway.de/checkout/cart/"
       data-bind="scope: 'minicart_content'">
        <span class="text">Mein Warenkorb</span>
        <span class="counter qty empty"
              data-bind="css: { empty: !!getCartParam('summary_count') == false }, blockLoader: isLoading">
            <span class="counter-number"><!-- ko text: getCartParam('summary_count') --><!-- /ko --></span>
            <span class="counter-label">
            <!-- ko if: getCartParam('summary_count') -->
                <!-- ko text: getCartParam('summary_count') --><!-- /ko -->
                <!-- ko i18n: 'Artikel' --><!-- /ko -->
                <!-- /ko -->
            </span>
        </span>
    </a>
            <div class="minicart-sidebar" data-mage-init='{"minicartSidebar": {}}'>
            <div id="minicart-content-wrapper" data-bind="scope: 'minicart_content'">
                <!-- ko template: getTemplate() --><!-- /ko -->
            </div>
        </div>
    <div id="custom-minicart-overlay"></div>
        
    
</div>
<div class="user-login"> 
    <div class="user-login-icon"></div>
    <ul class="user-login-list layui-anim layui-anim-upbit">
                            <li class="link my-account">
                <a href="/customer/account/create">Anmelden/Registrieren</a>
            </li>
            <li>
                <a href="/customer/account">Mein Konto</a>
            </li>
            <li>
                <a href="/sales/order/history">Meine Bestellungen</a>
            </li>
            <li>
                <a href="/aw_rewardpoints/info/coupon/">Meine Gutscheine</a>
            </li>
            <li>
                <a href="/wishlist/">Meine Wunschliste</a>
            </li>
            <li>
                <a href="/aw_rewardpoints/info/">Meine Prämienpunkte</a>
            </li>
            <li class="myrewardszone">
                <a href="/myrewardszone?entrypoint=accountmenu">Mein Prämienbereich</a>
            </li>
            </ul>
</div>            <div class="header_top_search">
                

    <div class="block block-search">
        <div class="block block-title"><strong>Suche</strong></div>
        <div class="block block-content">
            <form class="form minisearch" id="search_mini_form" action="https://www.costway.de/search/result/" method="get">
                <div class="field search">
                    <label class="label" for="search" data-role="minisearch-label">
                        <span>Suche</span>
                    </label>
                    <div class="control">
                        <input id="search"
                               data-mage-init='{"quickSearch":{
                               "formSelector":"#search_mini_form",
                               "url":"https://www.costway.de/search/ajax/suggest/",
                               "destinationSelector":"#search_autocomplete"}
                               }'
                               type="text"
                               name="q"
                               value=""
                               placeholder="Durchsuche hier den gesamten Laden..."
                               class="input-text"
                               maxlength="128"
                               role="combobox"
                               aria-haspopup="false"
                               aria-autocomplete="both"
                               autocomplete="off"/>
                        <div id="search_autocomplete" class="search-autocomplete"></div>
                        <div class="nested">
    <a class="action advanced" href="https://www.costway.de/catalogsearch/advanced/" data-action="advanced-search">
        Advanced Search    </a>
</div>





<div id="amasty-xsearch-preload" class="amasty-xsearch-preload" data-amsearch-js="preload"></div>
                    </div>
                </div>
                <div class="actions">
                    <button type="submit"
                            title="Suche"
                            class="action search">
                        <span>Suche</span>
                    </button>
                </div>
            </form>
           <!-- 增加词条 -->
                                                                                        <div class="search-right-icon">
<!--                        <a href="/mega-woche?entrypoint=hotwords"><img src="/pub/images/black-friday/rabatt-10-de.png" alt="10% Rabatt"></a>-->
                        <a href="/mega-woche?entrypoint=hotwords"><img src="/media/advertising/e/x/extra_-10_3_.png" alt="Mega Woche -10%"></a>
                    </div>
                                                    <!-- 增加词条 end -->

            <div class="search-suggestions">

                                                    <a href="/flash-deals?entrypoint=hotwords" >
                                                Flash Sale                    </a>
                                    <a href="/haushaltsgerate/klimaanlagen-ventilatoren.html?entrypoint=hotwords" style="position: relative;">
                        <img src="/pub/images/footer/hot.png" alt="hot" style="position: absolute;top: -10px;right: -16px;width: 25px;">                        Klimaanlagen                    </a>
                                    <a href="/gartenfest?entrypoint=hotwords" style="position: relative;">
                        <img src="/pub/images/footer/hot.png" alt="hot" style="position: absolute;top: -10px;right: -16px;width: 25px;">                        Gartenmöbel                    </a>
                
            </div>
        </div>
    </div>
            </div>
        </div>
    </div>
            <div class="page-main">
        <div class="sections nav-sections">
                        <div class="section-items nav-sections-items" data-mage-init='{"tabs":{"openedState":"active"}}'>
                                                                            <div class="section-item-title nav-sections-item-title" data-role="collapsible">
                        <a class="nav-sections-item-switch" data-toggle="switch" href="#store.links">Mein Konto</a>
                    </div>
                    <div class="section-item-content nav-sections-item-content" id="store.links" data-role="content"><!-- Account links --></div>
                                                </div>
        </div>
        
<div class="new-nav-main" id="new-nav-main">
    <div class="mb-categories-bar">
        <!-- <div class="back" id="categories-black">Zurück</div> -->
        <div class="close" id="categories-close"></div>
    </div>
    <div class="mb-categories-main">
        <div class="left-side-bar-main" id="left-side-bar-main">
            <ul class="left-side-bar" id="left-side-bar">
            </ul>
        </div>

        <div class="mb-sub-categories">
            <div class="mb-top-sub-nav" id="mb-top-sub-nav">
                <ul class="empty"></ul>
            </div>
            <div class="mb-sub-categories-main">
                <div class="mb-sub-categories-content">
                </div>
            </div>
        </div>
    </div>

    <div class="nav">
        <ul class="nav_list">
                                                <li>
                        <a class="top-nav" href="https://www.costway.de/mobel.html?entrypoint=bar">Möbel</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/mobel/wohnzimmer.html?entrypoint=bar">Wohnzimmermöbel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/sofas.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Sofas__1.png" src="/pub/images/default_120.png">Sofas                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/stuhle.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Sessel_St_hle__1.png" src="/pub/images/default_120.png">Sessel & Stühle                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/couchtische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Couchtische__1.png" src="/pub/images/default_120.png">Couchtische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/beistelltische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Beistelltische__1.png" src="/pub/images/default_120.png">Beistelltische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/kommoden.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kommoden__1.png" src="/pub/images/default_120.png">Kommoden                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/tv-mobel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/TV-M_bel__1.png" src="/pub/images/default_120.png">TV-Möbel                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/bucherregale.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Lager-_Regalsysteme__1.jpg" src="/pub/images/default_120.png">Lager- & Regalsysteme                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/ottoman-hocker.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Ottoman_Hocker__1_2.jpg" src="/pub/images/default_120.png">Ottoman & Hocker                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/mobel/wohnzimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/mobel/schlafzimmer.html?entrypoint=bar">Schlafzimmermöbel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/betten-bettgestelle.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Betten_Bettgestelle__1.jpg" src="/pub/images/default_120.png">Betten & Bettgestelle                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/matratzen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Matratzen__1_1.png" src="/pub/images/default_120.png">Matratzen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/betten-bettwasche.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Bettwaren__1.jpg" src="/pub/images/default_120.png">Bettwaren                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/nachttische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Nachttische__1.png" src="/pub/images/default_120.png">Nachttische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/schminktische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Schminktische__1.png" src="/pub/images/default_120.png">Schminktische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/schmuckschranke.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Schmuckschr_nke__1.png" src="/pub/images/default_120.png">Schmuckschränke                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/kleiderstander.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kleiderst_nder__1.png" src="/pub/images/default_120.png">Kleiderständer                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/kommoden.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kommoden__1.png" src="/pub/images/default_120.png">Kommoden                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/mobel/schlafzimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/mobel/kuche-esszimmer.html?entrypoint=bar">Küche & Esszimmermöbel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/kuchenwagen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/K_chenwagen_-inseln__1.png" src="/pub/images/default_120.png">Küchenwagen & -inseln                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/esszimmertische-stuhle.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Esszimmertische_-st_hle__1.png" src="/pub/images/default_120.png">Esszimmertische & -stühle                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/hocker-barhocker.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Barhocker__1.png" src="/pub/images/default_120.png">Barhocker                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/weinregale.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Weinregale__1.png" src="/pub/images/default_120.png">Weinregale                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/buffets-sideboards.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Buffets_Sideboards__1.png" src="/pub/images/default_120.png">Buffets & Sideboards                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/mobel/kuche-esszimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/mobel/buro-geschaftliches.html?entrypoint=bar">Homeoffice & Arbeitsplatz</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/schreibtische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Schreibtische__1.png" src="/pub/images/default_120.png">Schreibtische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/laptoptische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Laptoptische__1.jpg" src="/pub/images/default_120.png">Laptoptische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/burostuhle.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/B_rost_hle__1.jpg" src="/pub/images/default_120.png">Bürostühle                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/gaming-stuhle.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gaming-St_hle__1.png" src="/pub/images/default_120.png">Gaming-Stühle                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/buroschranke.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/B_roschr_nke__1.png" src="/pub/images/default_120.png">Büroschränke                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/burobedarf.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/B_robedarf__1.png" src="/pub/images/default_120.png">Bürobedarf                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/prasentationsbedarf.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Pr_sentationsbedarf__1.jpg" src="/pub/images/default_120.png">Präsentationsbedarf                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/absperrungen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Absperrungen__1.jpg" src="/pub/images/default_120.png">Absperrungen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/bucherregale.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Lager-_Regalsysteme__1.jpg" src="/pub/images/default_120.png">Bücherregale                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/mobel/buro-geschaftliches.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/mobel/flur.html?entrypoint=bar">Flurmöbel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/konsolentische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Konsolentische__1.png" src="/pub/images/default_120.png">Konsolentische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/schuhregale-schranke.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Schuhregale_-schr_nke__1.png" src="/pub/images/default_120.png">Schuhregale & -schränke                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/kleiderstander.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kleiderst_nder__1.png" src="/pub/images/default_120.png">Kleiderständer                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/mobel/flur.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/mobel/badezimmermobel.html?entrypoint=bar">Badmöbel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/spiegelschranke.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/H_ngeschr_nke__1.png" src="/pub/images/default_120.png">Hängeschränke                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/badschranke-badregale.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Badschr_nke_Badregale__1.png" src="/pub/images/default_120.png">Badschränke & Badregale                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/mobel/duschstuhle.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Duschst_hle__1.jpg" src="/pub/images/default_120.png">Duschstühle                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/mobel/badezimmermobel.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                                                                                                            <ul class="custom-category-ul">
                                                <li class="nav_title">
                                                    <a href="https://www.costway.de/baby-kind/babyzimmer.html?entrypoint=bar">Babyzimmermöbel</a>
                                                </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/gitterbetten-kleinkinderbetten.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Babybetten__1.png" src="/pub/images/default_120.png">Babybetten                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/hochstuhle-sitzerhohungen.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Hochst_hle__1.png" src="/pub/images/default_120.png">Hochstühle                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/babywippen.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Babywippen__1.png" src="/pub/images/default_120.png">Babywippen                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/wickeltische-toilettenzubehor.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Wickeltische_Toilettenzubeh_r__1.png" src="/pub/images/default_120.png">Wickeltische & Toilettenzubehör                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/spiel-krabbeldecken.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Spiel-_Krabbeldecken__1.png" src="/pub/images/default_120.png">Spiel- & Krabbeldecken                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/bettgitter.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Bettgitter__1.png" src="/pub/images/default_120.png">Bettgitter                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/babyschutzgitter.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Laufgitter__1.png" src="/pub/images/default_120.png">Laufgitter                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/baby-walker.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Baby_Walker__1.png" src="/pub/images/default_120.png">Baby Walker                                                        </a>
                                                    </li>
                                                                                                <li class="all"><a href="https://www.costway.de/baby-kind/babyzimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                            </ul>
                                                                                    <ul class="custom-category-ul">
                                                <li class="nav_title">
                                                    <a href="https://www.costway.de/baby-kind/kinderzimmer.html?entrypoint=bar">Kinderzimmermöbel</a>
                                                </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/mobelgarnituren-fur-babies-kinder.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kindersitzgruppen__2.png" src="/pub/images/default_120.png">Kindersitzgruppen﻿                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/kindersitzmobel.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kindersitzm_bel__1.png" src="/pub/images/default_120.png">Kindersitzmöbel                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/kinderbetten.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kinderbetten__1.png" src="/pub/images/default_120.png">Kinderbetten                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/schminktische-fur-kinder.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kinder-Schminktische__1.png" src="/pub/images/default_120.png">Kinder-Schminktische                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/baby-kind/regale-fur-kinder.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kinderregale__1.png" src="/pub/images/default_120.png">Kinderregale                                                        </a>
                                                    </li>
                                                                                                <li class="all"><a href="https://www.costway.de/baby-kind/kinderzimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                            </ul>
                                                                                                                                                    <!-- 如果不够4的倍数 需要补齐-->
                                                                    </div>
                                <div class="second_nav_pic">
                                                                            <a href="/mobel/sofas.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/M_bel_1_1.jpg" />
                                        </a>
                                                                                                                <a href="/mobel/kuche-esszimmer.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/M_bel_2_1.jpg" />
                                        </a>
                                                                    </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/garten.html?entrypoint=bar">Garten</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/garten/gartenmobel.html?entrypoint=bar">Gartenmöbel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/gartenmobelgarnituren.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gartenm_belgarnituren__1.png" src="/pub/images/default_120.png">Gartenmöbelgarnituren                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/gartensitzmobel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gartensitzm_bel__1.png" src="/pub/images/default_120.png">Gartensitzmöbel                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/gartentische.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gartentische__1.png" src="/pub/images/default_120.png">Gartentische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/hollywoodschaukeln-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Hollywoodschaukeln_Zubeh_r__1.png" src="/pub/images/default_120.png">Hollywoodschaukeln & Zubehör                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/hangematten-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/H_ngematten_Zubeh_r__1.png" src="/pub/images/default_120.png">Hängematten & Zubehör                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/garten/gartenmobel.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/garten/sonnenschutz.html?entrypoint=bar">Sonnenschutz</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/pavillons.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Pavillons__1_1.png" src="/pub/images/default_120.png">Pavillons                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/markisen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Markisen__1_1.jpg" src="/pub/images/default_120.png">Markisen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/sonnenschirme-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Sonnenschirme__1_1.png" src="/pub/images/default_120.png">Sonnenschirme                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/sonnenschirmstander.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Sonnenschirmst_nder__1_1.png" src="/pub/images/default_120.png">Sonnenschirmständer                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/garten/sonnenschutz.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/garten/rasen-garten.html?entrypoint=bar">Gärtnern</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/blumentopfe-pflanzregale.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Pflanzregale__1.png" src="/pub/images/default_120.png">Pflanzregale                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/blumentopfe.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Blument_pfe__1.png" src="/pub/images/default_120.png">Hochbeete & Rankhilfen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/gewachshauser.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gew_chsh_user__1.png" src="/pub/images/default_120.png">Gewächshäuser                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/gartenmaschinen-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gartenmaschinen_Zubeh_r__1.png" src="/pub/images/default_120.png">Gartenmaschinen & Zubehör                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/garten/rasen-garten.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/garten/heizen-im-garten.html?entrypoint=bar">Heizen im Garten</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/feuerstellen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Feuerstellen__1.png" src="/pub/images/default_120.png">Feuerstellen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/terrassenstrahler.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Terrassenstrahler__1.png" src="/pub/images/default_120.png">Terrassenstrahler                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/kaminzubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kaminzubeh_r__1.png" src="/pub/images/default_120.png">Kaminzubehör                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/garten/heizen-im-garten.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/garten/gerateschuppen-garagen.html?entrypoint=bar">Geräteschuppen & Garagen</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/gerateschuppen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Ger_teschuppen__1.png" src="/pub/images/default_120.png">Geräteschuppen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/garten/heimwerker.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Heimwerker__1.jpg" src="/pub/images/default_120.png">Heimwerker                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/garten/gerateschuppen-garagen.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        <li class="nav_title"><a href="https://www.costway.de/garten/grills.html?entrypoint=bar">Grills</a></li>
                                            <li class="all"><a href="https://www.costway.de/garten/grills.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                                                                                                                                </ul>
                                                                                                                                                            <ul class="custom-category-ul">
                                                <li class="nav_title">
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/spielzeug-fur-draussen.html?entrypoint=bar">Outdoor-Spielzeuge</a>
                                                </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/spielzeuge-hobbys/hupfburgen.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/H_pfburgen__1.png" src="/pub/images/default_120.png">Hüpfburgen                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/spielzeuge-hobbys/hupfburg-zubehor.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Luftgebl_se__1.png" src="/pub/images/default_120.png">Luftgebläse                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/spielzeuge-hobbys/trampoline-zubehor.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Trampoline_Zubeh_r__1.png" src="/pub/images/default_120.png">Trampoline & Zubehör                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/spielzeuge-hobbys/schaukeln-schaukel-sets.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Schaukeln_Schaukel-Sets__1.jpg" src="/pub/images/default_120.png">Schaukeln & Schaukel-Sets                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/spielzeuge-hobbys/rutschen.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Rutschen__1_1.jpg" src="/pub/images/default_120.png">Rutschen                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/spielzeuge-hobbys/rasenspiele.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Rasenspiele__1.png" src="/pub/images/default_120.png">Rasenspiele                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/spielzeuge-hobbys/sandkasten.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Sandspielzeug__1.jpg" src="/pub/images/default_120.png">Sandspielzeug                                                        </a>
                                                    </li>
                                                                                                <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/spielzeug-fur-draussen.html?entrypoint=bar"><span>Alle</span></a></li>
                                            </ul>
                                                                                                                                                        <ul class="nav-title-group">
                                                                                    <li class="nav_title"><a href="https://www.costway.de/dekoration/gartendekoration.html?entrypoint=bar">Gartendekoration</a></li>
                                            <li class="all"><a href="https://www.costway.de/dekoration/gartendekoration.html?entrypoint=bar"><span>Alle</span></a></li>
                                                                                                                            </ul>
                                                                        <!-- 如果不够4的倍数 需要补齐-->
                                                                    </div>
                                <div class="second_nav_pic">
                                                                            <a href="/garten/gartenmobel.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Garten_1_1.jpg" />
                                        </a>
                                                                                                                <a href="/garten/sonnenschutz.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Garten_2_1.jpg" />
                                        </a>
                                                                    </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/kuche.html?entrypoint=bar">Küche</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/kuche/kochzubehor-kuchenhelfer.html?entrypoint=bar">Kochzubehör & Küchenhelfer</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/kuche/fleischverarbeitungs-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Wurstf_ller__1.jpg" src="/pub/images/default_120.png">Wurstfüller                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/kuche/kochzubehor-kuchenhelfer.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                            <li class="nav_title"><a href="https://www.costway.de/kuche/kuchenorganizer.html?entrypoint=bar">Küchenorganizer</a></li>
                                            <li class="all"><a href="https://www.costway.de/kuche/kuchenorganizer.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/kuche/kochgeschirr-backformen.html?entrypoint=bar">Kochgeschirr & Backformen</a></li>
                                            <li class="all"><a href="https://www.costway.de/kuche/kochgeschirr-backformen.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                                                                                                                                                                                                            </ul>
                                                                                                                                                            <ul class="custom-category-ul">
                                                <li class="nav_title">
                                                    <a href="https://www.costway.de/mobel/kuche-esszimmer.html?entrypoint=bar">Küche & Esszimmermöbel</a>
                                                </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/kuchenwagen.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/K_chenwagen_-inseln__1.png" src="/pub/images/default_120.png">Küchenwagen & -inseln                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/esszimmertische-stuhle.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Esszimmertische_-st_hle__1.png" src="/pub/images/default_120.png">Esszimmertische & -stühle                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/hocker-barhocker.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Barhocker__1.png" src="/pub/images/default_120.png">Barhocker                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/weinregale.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Weinregale__1.png" src="/pub/images/default_120.png">Weinregale                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/buffets-sideboards.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Buffets_Sideboards__1.png" src="/pub/images/default_120.png">Buffets & Sideboards                                                        </a>
                                                    </li>
                                                                                                <li class="all"><a href="https://www.costway.de/mobel/kuche-esszimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                            </ul>
                                                                                    <ul class="custom-category-ul">
                                                <li class="nav_title">
                                                    <a href="https://www.costway.de/haushaltsgerate/kuchengerate.html?entrypoint=bar">Küchengeräte</a>
                                                </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/haushaltsgerate/kuhlschranke.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/K_hlschr_nke__1.png" src="/pub/images/default_120.png">Kühlschränke                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/haushaltsgerate/eiswurfelmaschine.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Eisw_rfelmaschine__1.png" src="/pub/images/default_120.png">Eiswürfelmaschine                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/haushaltsgerate/kuchenmaschine.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/K_chenmaschine__1.png" src="/pub/images/default_120.png">Küchenmaschine                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/haushaltsgerate/kleine-kuchengerate.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kleine_K_chenger_te__1.png" src="/pub/images/default_120.png">Kleine Küchengeräte                                                        </a>
                                                    </li>
                                                                                                <li class="all"><a href="https://www.costway.de/haushaltsgerate/kuchengerate.html?entrypoint=bar"><span>Alle</span></a></li>
                                            </ul>
                                                                                                                                                    <!-- 如果不够4的倍数 需要补齐-->
                                                                    </div>
                                <div class="second_nav_pic">
                                                                            <a href="/mobel/kuchenwagen.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/K_che_1.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/haushaltsgerate.html?entrypoint=bar">Haushaltsgeräte</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/haushaltsgerate/kuchengerate.html?entrypoint=bar">Küchengeräte</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/kuhlschranke.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/K_hlschr_nke__1.png" src="/pub/images/default_120.png">Kühlschränke                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/eiswurfelmaschine.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Eisw_rfelmaschine__1.png" src="/pub/images/default_120.png">Eiswürfelmaschine                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/kuchenmaschine.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/K_chenmaschine__1.png" src="/pub/images/default_120.png">Küchenmaschine                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/kleine-kuchengerate.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kleine_K_chenger_te__1.png" src="/pub/images/default_120.png">Kleine Küchengeräte                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/haushaltsgerate/kuchengerate.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/haushaltsgerate/klimatisierung.html?entrypoint=bar">Klimatisierung</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/kamine.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Elektrokamine__1.png" src="/pub/images/default_120.png">Elektrokamine                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/raumheizungen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Raumheizungen__1.png" src="/pub/images/default_120.png">Raumheizungen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/klimaanlagen-ventilatoren.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Klimaanlagen__1.png" src="/pub/images/default_120.png">Klimaanlagen & Ventilatoren                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/luftreiniger.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Luftreiniger__1.png" src="/pub/images/default_120.png">Luftreiniger & Luftentfeuchter                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/haushaltsgerate/klimatisierung.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/haushaltsgerate/waschen-trocknen.html?entrypoint=bar">Waschen & Trocknen</a></li>
                                            <li class="all"><a href="https://www.costway.de/haushaltsgerate/waschen-trocknen.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/haushaltsgerate/staubsauger-dampfreiniger.html?entrypoint=bar">Staubsauger & Dampfreiniger</a></li>
                                            <li class="all"><a href="https://www.costway.de/haushaltsgerate/staubsauger-dampfreiniger.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                        </ul>
                                                                                                                                                <!-- 如果不够4的倍数 需要补齐-->
                                    <ul class='empty'></ul>                                </div>
                                <div class="second_nav_pic">
                                                                            <a href="/haushaltsgerate/klimatisierung.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Haushaltsger_te-Klimaanlagen_1.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/dekoration.html?entrypoint=bar">Deko</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/dekoration/festtags-dekoartikel.html?entrypoint=bar">Festtags-Dekoartikel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/weihnachten.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Weihnachten__1.png" src="/pub/images/default_120.png">Weihnachten                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/halloween.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Halloween__1.png" src="/pub/images/default_120.png">Halloween                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/dekoration/festtags-dekoartikel.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/dekoration/spiegel.html?entrypoint=bar">Spiegel</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/wandspiegel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Wandspiegel__1.png" src="/pub/images/default_120.png">Wandspiegel                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/standspiegel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Standspiegel__1.png" src="/pub/images/default_120.png">Standspiegel                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/kosmetikspiegel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kosmetikspiegel__1.jpg" src="/pub/images/default_120.png">Kosmetikspiegel                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/dekoration/spiegel.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/dekoration/innendeko.html?entrypoint=bar">Wohndekorationen</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/raumteiler.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Raumteiler__1.png" src="/pub/images/default_120.png">Raumteiler                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/teppiche.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Teppiche__1.png" src="/pub/images/default_120.png">Teppiche                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/dekoration/gartendekoration.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gartendekoration__1.png" src="/pub/images/default_120.png">Gartendekoration                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haushaltsgerate/kamine.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Elektrokamine__1.png" src="/pub/images/default_120.png">Elektrokamine                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/dekoration/innendeko.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/dekoration/beleuchtung.html?entrypoint=bar">Beleuchtung</a></li>
                                            <li class="all"><a href="https://www.costway.de/dekoration/beleuchtung.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/dekoration/kunstliche-pflanzen.html?entrypoint=bar">Künstliche Pflanzen</a></li>
                                            <li class="all"><a href="https://www.costway.de/dekoration/kunstliche-pflanzen.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                                                    </ul>
                                                                                                                                                <!-- 如果不够4的倍数 需要补齐-->
                                                                    </div>
                                <div class="second_nav_pic">
                                                                            <a href="/dekoration/festtags-dekoartikel.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Deko_1.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/spielzeuge-hobbys.html?entrypoint=bar">Spielzeuge & Hobbys</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/spielzeuge-hobbys/elektrospielzeuge.html?entrypoint=bar">Kinderfahrzeuge</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/spielzeugautos.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Spielzeugautos__1.png" src="/pub/images/default_120.png">Spielzeugautos                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/spielzeugmotorrader.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Spielzeugmotorr_der__1.jpg" src="/pub/images/default_120.png">Spielzeugmotorräder                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/go-karts.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Go-Karts__1.jpg" src="/pub/images/default_120.png">Go-Karts                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/fahrrad-scooter.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Scooter__1.png" src="/pub/images/default_120.png">Scooter                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/laufrader.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Laufr_der__1.png" src="/pub/images/default_120.png">Laufräder                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/baby-walker.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Baby_Walker__1.png" src="/pub/images/default_120.png">Baby Walker                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/elektrospielzeuge.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/spielzeuge-hobbys/spielzeug-fur-draussen.html?entrypoint=bar">Outdoor-Spielzeuge</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/hupfburgen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/H_pfburgen__1.png" src="/pub/images/default_120.png">Hüpfburgen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/hupfburg-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Luftgebl_se__1.png" src="/pub/images/default_120.png">Luftgebläse                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/trampoline-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Trampoline_Zubeh_r__1.png" src="/pub/images/default_120.png">Trampoline & Zubehör                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/schaukeln-schaukel-sets.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Schaukeln_Schaukel-Sets__1.jpg" src="/pub/images/default_120.png">Schaukeln & Schaukel-Sets                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/rutschen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Rutschen__1_1.jpg" src="/pub/images/default_120.png">Rutschen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/rasenspiele.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Rasenspiele__1.png" src="/pub/images/default_120.png">Rasenspiele                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/sandkasten.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Sandspielzeug__1.jpg" src="/pub/images/default_120.png">Sandspielzeug                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/spielzeug-fur-draussen.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/spielzeuge-hobbys/kinder-rollenspiele.html?entrypoint=bar">Kinder-Rollenspiele</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/kinderkuche.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kinderk_che__1.jpg" src="/pub/images/default_120.png">Kinderküche                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/spielzelte.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Spielzelte_Spielh_user__1.png" src="/pub/images/default_120.png">Spielzelte & Spielhäuser                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/kinder-rollenspiele.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/spielzeuge-hobbys/sportspielzeuge.html?entrypoint=bar">Sportspielzeuge</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/boxen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Boxen__1.png" src="/pub/images/default_120.png">Boxen                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/sportspielzeuge.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/spielzeuge-hobbys/musikinstrumente.html?entrypoint=bar">Musikinstrumente</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/tasteninstrumente.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Tasteninstrumente__1.png" src="/pub/images/default_120.png">Tasteninstrumente                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/elektronische-schlagzeuge.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Drums__1.png" src="/pub/images/default_120.png">Drums                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/gitarren.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gitarren__1.png" src="/pub/images/default_120.png">Gitarren                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/musikspielzeug.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Musikspielzeug__1.png" src="/pub/images/default_120.png">Musikspielzeug                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/musikinstrumente.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                                                                                                                                                                                <li class="nav_title"><a href="https://www.costway.de/spielzeuge-hobbys/bausteine-klotze.html?entrypoint=bar">Bausteine</a></li>
                                            <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/bausteine-klotze.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/spielzeuge-hobbys/klettergerate.html?entrypoint=bar">Klettergeräte</a></li>
                                            <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/klettergerate.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                                                                                                <li class="nav_title"><a href="https://www.costway.de/spielzeuge-hobbys/schaukelspielzeug.html?entrypoint=bar">Schaukelspielzeug</a></li>
                                            <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/schaukelspielzeug.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/spielzeuge-hobbys/lernspielzeug.html?entrypoint=bar">Lernspielzeug</a></li>
                                            <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/lernspielzeug.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/spielzeuge-hobbys/spiele.html?entrypoint=bar">Spielzimmer</a></li>
                                            <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/spiele.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                            </ul><ul class="nav-title-group">
                                                                                                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/spielzeuge-hobbys/malen-zeichnen.html?entrypoint=bar">Malen & Zeichnen</a></li>
                                            <li class="all"><a href="https://www.costway.de/spielzeuge-hobbys/malen-zeichnen.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                        </ul>
                                                                                                                                                <!-- 如果不够4的倍数 需要补齐-->
                                    <ul class='empty'></ul>                                </div>
                                <div class="second_nav_pic">
                                                                            <a href="/spielzeuge-hobbys/elektrospielzeuge.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Spielzeuge_Hobbys_1_1.jpg" />
                                        </a>
                                                                                                                <a href="/spielzeuge-hobbys/hupfburgen.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Spielzeuge_Hobbys_2_1.jpg" />
                                        </a>
                                                                    </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/baby-kind.html?entrypoint=bar">Baby & Kind</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/baby-kind/babyzimmer.html?entrypoint=bar">Babyzimmer</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/gitterbetten-kleinkinderbetten.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Babybetten__1.png" src="/pub/images/default_120.png">Babybetten                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/hochstuhle-sitzerhohungen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Hochst_hle__1.png" src="/pub/images/default_120.png">Hochstühle                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/babywippen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Babywippen__1.png" src="/pub/images/default_120.png">Babywippen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/wickeltische-toilettenzubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Wickeltische_Toilettenzubeh_r__1.png" src="/pub/images/default_120.png">Wickeltische & Toilettenzubehör                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/spiel-krabbeldecken.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Spiel-_Krabbeldecken__1.png" src="/pub/images/default_120.png">Spiel- & Krabbeldecken                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/bettgitter.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Bettgitter__1.png" src="/pub/images/default_120.png">Bettgitter                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/babyschutzgitter.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Laufgitter__1.png" src="/pub/images/default_120.png">Laufgitter                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/baby-walker.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Baby_Walker__1.png" src="/pub/images/default_120.png">Baby Walker                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/baby-kind/babyzimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/baby-kind/kinderzimmer.html?entrypoint=bar">Kinderzimmer</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/mobelgarnituren-fur-babies-kinder.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kindersitzgruppen__2.png" src="/pub/images/default_120.png">Kindersitzgruppen﻿                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/kindersitzmobel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kindersitzm_bel__1.png" src="/pub/images/default_120.png">Kindersitzmöbel                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/kinderbetten.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kinderbetten__1.png" src="/pub/images/default_120.png">Kinderbetten                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/schminktische-fur-kinder.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kinder-Schminktische__1.png" src="/pub/images/default_120.png">Kinder-Schminktische                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/baby-kind/regale-fur-kinder.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kinderregale__1.png" src="/pub/images/default_120.png">Kinderregale                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/baby-kind/kinderzimmer.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/baby-kind/taschen-gepack-fur-kinder.html?entrypoint=bar">Kinderkoffer</a></li>
                                            <li class="all"><a href="https://www.costway.de/baby-kind/taschen-gepack-fur-kinder.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/baby-kind/kinderwagen.html?entrypoint=bar">Kinderwagen</a></li>
                                            <li class="all"><a href="https://www.costway.de/baby-kind/kinderwagen.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                        </ul>
                                                                                                                                                <!-- 如果不够4的倍数 需要补齐-->
                                    <ul class='empty'></ul>                                </div>
                                <div class="second_nav_pic">
                                                                            <a href="/baby-kind/kinderzimmer.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Baby_Kind_2.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/sport-freizeit.html?entrypoint=bar">Sport & Freizeit</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/sport-freizeit/fitnessgerate.html?entrypoint=bar">Fitnessgeräte</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/laufbander.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Laufb_nder__1.png" src="/pub/images/default_120.png">Laufbänder                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/heimtrainer.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Heimtrainer__1.png" src="/pub/images/default_120.png">Heimtrainer                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/rudergerate.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Ruderger_te__1.png" src="/pub/images/default_120.png">Rudergeräte                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/steppbretter.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Steppbretter__1.jpg" src="/pub/images/default_120.png">Steppbretter                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/rollentrainer.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Rollentrainer__1.jpg" src="/pub/images/default_120.png">Rollentrainer                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/sport-freizeit/fitnessgerate.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/sport-freizeit/kraft-gewichtstraining.html?entrypoint=bar">Kraft- & Gewichtstraining</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/banke-stange-bauchtrainer.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/B_nke_Stange_Bauchtrainer__1.png" src="/pub/images/default_120.png">Bänke, Stange & Bauchtrainer                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/gewichte-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gewichte_Zubeh_r__1.png" src="/pub/images/default_120.png">Gewichte & Zubehör                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/spielzeuge-hobbys/boxen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Boxen__1.png" src="/pub/images/default_120.png">Boxen                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/sport-freizeit/kraft-gewichtstraining.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/sport-freizeit/turnen-yoga.html?entrypoint=bar">Tanzen & Yoga</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/gymnastikmatten.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Gymnastikmatten__1.jpg" src="/pub/images/default_120.png">Gymnastikmatten                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/turnstangen-schwebebalken.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Turnstangen_Schwebebalken__1.jpg" src="/pub/images/default_120.png">Turnstangen & Schwebebalken                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/ballettstangen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Ballettstangen_Tanzstangenkits__1.png" src="/pub/images/default_120.png">Ballettstangen & Tanzstangenkits                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/yoga-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Yoga_Zubeh_r_.jpg" src="/pub/images/default_120.png">Yoga Zubehör                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/sport-freizeit/turnen-yoga.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/sport-freizeit/boot-wassersport.html?entrypoint=bar">Boot- & Wassersport</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/surfen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Surfen__1.jpg" src="/pub/images/default_120.png">Surfen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/pool-whirlpool-zubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Schwimmen__1.jpg" src="/pub/images/default_120.png">Schwimmen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/boot-wassersport/boote-bootszubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Boote_Bootszubeh_r_1.jpg" src="/pub/images/default_120.png">Boote & Bootszubehör                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/sport-freizeit/boot-wassersport.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/sport-freizeit/camping-wandern.html?entrypoint=bar">Camping & Wandern</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/campingmobel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Campingm_bel__1.png" src="/pub/images/default_120.png">Campingmöbel                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/campingbedarf.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Campingbedarf__1.png" src="/pub/images/default_120.png">Campingbedarf                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/mobile-toiletten-duschen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Mobile_Toiletten_Duschen__1.png" src="/pub/images/default_120.png">Mobile Toiletten & Duschen                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/sport-freizeit/kuhlboxen.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/K_hlbeh_lter__1.jpg" src="/pub/images/default_120.png">Kühlbehälter                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/sport-freizeit/camping-wandern.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                                                                                                                                                                                                                                                            <li class="nav_title"><a href="https://www.costway.de/sport-freizeit/ballsport.html?entrypoint=bar">Ballsport</a></li>
                                            <li class="all"><a href="https://www.costway.de/sport-freizeit/ballsport.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/sport-freizeit/golf.html?entrypoint=bar">Golf</a></li>
                                            <li class="all"><a href="https://www.costway.de/sport-freizeit/golf.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                                                    </ul>
                                                                                                                                                <!-- 如果不够4的倍数 需要补齐-->
                                    <ul class='empty'></ul><ul class='empty'></ul>                                </div>
                                <div class="second_nav_pic">
                                                                            <a href="/sport-freizeit/fitnessgerate.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Sport_Freizeit_1.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/haustierbedarf.html?entrypoint=bar">Haustierbedarf</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/haustierbedarf/hundebedarf.html?entrypoint=bar">Hundebedarf</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haustierbedarf/hund-haustiergitter.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Hund-_Haustiergitter__1.png" src="/pub/images/default_120.png">Hund- & Haustiergitter                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haustierbedarf/hundezubehor.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Hundezubeh_r__1.jpg" src="/pub/images/default_120.png">Hundezubehör                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/haustierbedarf/hundebedarf.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/haustierbedarf/katzenbedarf.html?entrypoint=bar">Katzenbedarf</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haustierbedarf/katzenmobel.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Katzenh_user__1.jpg" src="/pub/images/default_120.png">Katzenhäuser                                                    </a>
                                                </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/haustierbedarf/kratzbaume.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kratzb_ume__1.png" src="/pub/images/default_120.png">Kratzbäume                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/haustierbedarf/katzenbedarf.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/haustierbedarf/sonstiger-tierbedarf.html?entrypoint=bar">Sonstiger Tierbedarf</a></li>
                                            <li class="all"><a href="https://www.costway.de/haustierbedarf/sonstiger-tierbedarf.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                        </ul>
                                                                                                                                                <!-- 如果不够4的倍数 需要补齐-->
                                    <ul class='empty'></ul>                                </div>
                                <div class="second_nav_pic">
                                                                            <a href="/haustierbedarf/katzenbedarf.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Haustierbedarf_1.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/badezimmer.html?entrypoint=bar">Bad</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                            <li class="nav_title"><a href="https://www.costway.de/badezimmer/handtuchhalter.html?entrypoint=bar">Handtuchhalter</a></li>
                                            <li class="all"><a href="https://www.costway.de/badezimmer/handtuchhalter.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/badezimmer/waschekorbe.html?entrypoint=bar">Wäschekörbe</a></li>
                                            <li class="all"><a href="https://www.costway.de/badezimmer/waschekorbe.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/badezimmer/waschestander.html?entrypoint=bar">Wäscheständer</a></li>
                                            <li class="all"><a href="https://www.costway.de/badezimmer/waschestander.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                    <li class="nav_title"><a href="https://www.costway.de/badezimmer/reinigungsutensilien.html?entrypoint=bar">Reinigungsutensilien</a></li>
                                            <li class="all"><a href="https://www.costway.de/badezimmer/reinigungsutensilien.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                                                    </ul>
                                                                                                                                                            <ul class="custom-category-ul">
                                                <li class="nav_title">
                                                    <a href="https://www.costway.de/mobel/badezimmermobel.html?entrypoint=bar">Badmöbel</a>
                                                </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/spiegelschranke.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/H_ngeschr_nke__1.png" src="/pub/images/default_120.png">Hängeschränke                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/badschranke-badregale.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Badschr_nke_Badregale__1.png" src="/pub/images/default_120.png">Badschränke & Badregale                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/mobel/duschstuhle.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Duschst_hle__1.jpg" src="/pub/images/default_120.png">Duschstühle                                                        </a>
                                                    </li>
                                                                                                <li class="all"><a href="https://www.costway.de/mobel/badezimmermobel.html?entrypoint=bar"><span>Alle</span></a></li>
                                            </ul>
                                                                                                                                                    <!-- 如果不够4的倍数 需要补齐-->
                                    <ul class='empty'></ul><ul class='empty'></ul>                                </div>
                                <div class="second_nav_pic">
                                                                            <a href="/mobel/badezimmermobel.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Bad_1.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                                                <li>
                        <a class="top-nav" href="https://www.costway.de/pflege-kosmetik.html?entrypoint=bar">Pflege & Kosmetik</a>
                        <div class="second_nav nav_2">
                            <div class="second_nav_cont ">
                                <div class="second_nav_list sub_nav_1">
                                                                            <ul class="">
                                            <li class="nav_title">
                                                <a href="https://www.costway.de/pflege-kosmetik/massage-entspannung.html?entrypoint=bar">Massage & Entspannung</a>
                                            </li>
                                                                                            <li>
                                                    <a href="https://www.costway.de/pflege-kosmetik/massagegerate.html?entrypoint=bar">
                                                    <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Massageger_te__1.png" src="/pub/images/default_120.png">Massagegeräte                                                    </a>
                                                </li>
                                                                                        <li class="all"><a href="https://www.costway.de/pflege-kosmetik/massage-entspannung.html?entrypoint=bar"><span>Alle</span></a></li>
                                        </ul>
                                                                        <!--上面的循环存在空分类才做下面操作-->
                                                                            <ul class="nav-title-group">
                                                                                                                                                                                                        <li class="nav_title"><a href="https://www.costway.de/pflege-kosmetik/haarkosmetik.html?entrypoint=bar">Haarstyling & Friseurbedarf</a></li>
                                            <li class="all"><a href="https://www.costway.de/pflege-kosmetik/haarkosmetik.html?entrypoint=bar"><span>Alle</span></a></li>

                                                                                                                                                                                                                                                                                </ul>
                                                                                                                                                            <ul class="custom-category-ul">
                                                <li class="nav_title">
                                                    <a href="https://www.costway.de/dekoration/spiegel.html?entrypoint=bar">Spiegel</a>
                                                </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/dekoration/wandspiegel.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Wandspiegel__1.png" src="/pub/images/default_120.png">Wandspiegel                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/dekoration/standspiegel.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Standspiegel__1.png" src="/pub/images/default_120.png">Standspiegel                                                        </a>
                                                    </li>
                                                                                                    <li>
                                                        <a href="https://www.costway.de/dekoration/kosmetikspiegel.html?entrypoint=bar">
                                                            <img class="menu-lazy" alt="" data-original="https://www.costway.de/media/zetman/category/Kosmetikspiegel__1.jpg" src="/pub/images/default_120.png">Kosmetikspiegel                                                        </a>
                                                    </li>
                                                                                                <li class="all"><a href="https://www.costway.de/dekoration/spiegel.html?entrypoint=bar"><span>Alle</span></a></li>
                                            </ul>
                                                                                                                                                        <ul class="nav-title-group">
                                                                                    <li class="nav_title"><a href="https://www.costway.de/mobel/schmuckschranke.html?entrypoint=bar">Schmuckschränke</a></li>
                                            <li class="all"><a href="https://www.costway.de/mobel/schmuckschranke.html?entrypoint=bar"><span>Alle</span></a></li>
                                                                                                                            </ul>
                                                                        <!-- 如果不够4的倍数 需要补齐-->
                                                                    </div>
                                <div class="second_nav_pic">
                                                                            <a href="/pflege-kosmetik/massage-entspannung.html">
                                            <img class="menu-ad-lazy" data-original="https://www.costway.de/media/zetman/category/Pflege_Kosmetik_1.jpg" />
                                        </a>
                                                                                                        </div>
                            </div>
                        </div>

                    </li>
                                        <!--兼容后台自定义配置menu功能-->
                    </ul>
    </div>
</div>


<div class="nav-box" id="nav-box"><i id="close-nav" class="close-nav"></i>
            <div>
            <div class="sign">
                <p><a href="/customer/account/create?entrypoint=accountmenu">Anmelden/Registrieren</a></p>
            </div>
            
        </div>
        
    <div class="menu-title">
        Mein Konto    </div>
    <ul class="my-account-nav">   
        <li class="">
            <a href="/customer/account?entrypoint=accountmenu">
                <img class="lazy" data-original="/pub/images/user-nav/nav-icon-1.png">
                Kontoinformationen                <span></span>
            </a>
        </li>
        <li class="">
            <a href="/wishlist?entrypoint=accountmenu">
                <img  class="lazy"
                data-original="/pub/images/user-nav/nav-icon-2.png">
                Meine Wunschliste                <span>0</span></a>
        </li>
        <li class="">
            <a href="/aw_rewardpoints/info/coupon?entrypoint=accountmenu">
                <img  class="lazy" data-original="/pub/images/user-nav/nav-icon-3.png">
               Meine Gutscheine                <span>0</span></a>
        </li>

        <li class="">
            <a id="facebook_community" href="https://www.facebook.com/groups/705896188954836?entrypoint=accountmenu">
                <img  class="lazy" data-original="/pub/images/user-nav/nav-icon-4.png">
               Facebook-Community            </a>
        </li>
      
        <li>
            <a href="/sales/order/history?entrypoint=accountmenu">
                <img class="lazy" data-original="/pub/images/user-nav/nav-icon-5.png">                
                Meine Bestellungen                <span></span>
            </a>
        </li>
    
        <li >
            <a href="/review/customer?entrypoint=accountmenu">
                <img class="lazy" data-original="/pub/images/user-nav/nav-icon-6.png">                
                Meine Produktbewertungen                <span></span></a>
        </li>     
        <li>
            <a href="/kontakt?entrypoint=accountmenu">
                <img class="lazy" data-original="/pub/images/user-nav/nav-icon-7.png">
                Kontaktieren Sie Uns                <span></span></a>
        </li>      
    </ul>
    <a href="/myrewardszone?entrypoint=accountmenu">
        <div class="menu-title border my-benefits-title">
            Mein Prämienbereich        </div>
    </a>
    <ul class="my-benefits-nav">
        <li class="item milestone-badge"><a target="_blank" href="/milestone-badge?entrypoint=my_benefits"><span>Meilenstein</span></a></li>
        <li class="item loyalty-cashback"><a target="_blank" href="/loyalty-cashback?entrypoint=my_benefits"><span>Treueprogramm</span></a></li>
        <li class="item reward-points"><a href="/aw_rewardpoints/info?entrypoint=my_benefits">Prämienpunkte</a></li>
    </ul>

    </div>

<!-- 兼容后台自定义配置Sale活动链接功能 -->
<div class="sales-content">
    <ul class="sales-items">
                                    <li>
                    <a href="/flash-deals?entrypoint=sidebar">
                        <img class="menu-lazy" data-original="https://www.costway.de/media/advertising/d/e/de-1_1.png" alt ="Flash Sale" />
                    </a>
                </li>
                            <li>
                    <a href="/grosse-lagerraeumung?entrypoint=sidebar">
                        <img class="menu-lazy" data-original="https://www.costway.de/media/advertising/d/e/de-2_2.png" alt ="Ausverkauf" />
                    </a>
                </li>
                            <li>
                    <a href="/bestseller?entrypoint=sidebar">
                        <img class="menu-lazy" data-original="https://www.costway.de/media/advertising/d/e/de-3_1.png" alt ="Bestseller" />
                    </a>
                </li>
                            <li>
                    <a href="/aktionsangebot?entrypoint=sidebar">
                        <img class="menu-lazy" data-original="https://www.costway.de/media/advertising/d/e/de-4.png" alt ="Alle Artikel unter 99 €" />
                    </a>
                </li>
                            <li>
                    <a href="/mega-woche?entrypoint=sidebar">
                        <img class="menu-lazy" data-original="https://www.costway.de/media/advertising/d/e/de-5.png" alt ="10% Rabatt" />
                    </a>
                </li>
                            <li>
                    <a href="/frische-auswahl?entrypoint=sidebar">
                        <img class="menu-lazy" data-original="https://www.costway.de/media/advertising/d/e/de-6.png" alt ="Neue Kollektion" />
                    </a>
                </li>
                        </ul>
</div>


    </div>
    </header>



<!-- 隐私弹窗按钮埋点 -->





<div class="breadcrumbs">
    <ul class="items">
                    <li class="item 0">
                            <a href="https://www.costway.de/" title="Go to Home Page">Home</a>
                        </li>
                    <li class="item 1">
                            <a href="https://www.costway.de/dekoration.html" title="Deko">Deko</a>
                        </li>
                    <li class="item 2">
                            <a href="https://www.costway.de/dekoration/festtags-dekoartikel.html" title="Festtags-Dekoartikel">Festtags-Dekoartikel</a>
                        </li>
                    <li class="item 3">
                            <a href="https://www.costway.de/dekoration/weihnachten.html" title="Weihnachten">Weihnachten</a>
                        </li>
                    <li class="item 4">
                            <a href="https://www.costway.de/dekoration/weihnachtsbaume.html" title="Weihnachtsbäume">Weihnachtsbäume</a>
                        </li>
                    <li class="item 5">
                            180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern                        </li>
            </ul>
</div>
<main id="maincontent" class="page-main"><a id="contentarea" tabindex="-1"></a>
<div class="page messages"><div data-placeholder="messages"></div>
<div data-bind="scope: 'messages'">
    <!-- ko if: cookieMessages && cookieMessages.length > 0 -->
    <div aria-atomic="true" role="alert" data-bind="foreach: { data: cookieMessages, as: 'message' }" class="messages">
        <!-- ko if: message.text !== 'CARDHOLDERINFO: cardholder' -->
            <div data-bind="attr: {
                class: 'message-' + message.type + ' ' + message.type + ' message',
                'data-ui-id': 'message-' + message.type
            }">
                <div data-bind="html: $parent.prepareMessageForHtml(message.text)"></div>
            </div>
        <!-- /ko -->
    </div>
    <!-- /ko -->

    <!-- ko if: messages().messages && messages().messages.length > 0 -->
    <div aria-atomic="true" role="alert" class="messages" data-bind="foreach: {
        data: messages().messages, as: 'message'
    }">
        <div data-bind="attr: {
            class: 'message-' + message.type + ' ' + message.type + ' message',
            'data-ui-id': 'message-' + message.type
        }">
            <div data-bind="html: $parent.prepareMessageForHtml(message.text)"></div>
        </div>
    </div>
    <!-- /ko -->
</div>

</div><div class="columns"><div class="column main"><div class="product media">

<div class="gallery-placeholder _block-content-loading" data-gallery-role="gallery-placeholder">
    <img
        alt="main product photo"
        class="gallery-placeholder__image"
        src="https://www.costway.de/media/catalog/product/cache/c4db9a9c74edf330d39d62982732ede8/k/_/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_2_.jpg"
        width="627"
        height="627"

    />
</div>



</div><div class="product-info-main"><div class="page-title-wrapper&#x20;product">
    <div class="page-title-con">
        <h1 class="page-title"
                        >
                                        180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern                    </h1>
    </div>
    </div>



<div class="product attribute overview" >
        <div class="value"x-itemprop="description">
                    <p>Für eine festliche Atmosphäre!</p>                    </div>
</div>




<div class="product-info-price"><div class="product-info-stock-sku">        <div class="product-reviews-summary" x-itemprop="aggregateRating" x-itemscope
         x-itemtype="http://schema.org/AggregateRating">
                <div class="rating-summary">
             <span class="label"><span>Bewertung:</span></span>
             <div class="rating-result" title="96%">
                 <span style="width: 96%" >
                     <span>
                         <span x-itemprop="ratingValue">96                         </span>% of <span x-itemprop="bestRating">100</span>
                     </span>
                 </span>
             </div>
         </div>
                            <div class="reviews-actions">
            <a class="action view"
               href="https://www.costway.de/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html#reviews">
                <span x-itemprop="reviewCount">3</span>&nbsp;
                <span>Bewertungen                </span>
            </a>
<!--            <a class="action add" href="--><!--">-->
                    <!--            </a>-->
        </div>
    </div>


<div class="product attribute sku" >
                        <strong class="type">Artikel-Nr.:</strong>
                <div class="value"x-itemprop="sku">
                    45691872                    </div>
</div>




</div><div class="price-box price-final_price" data-role="priceBox" data-product-id="4961" data-price-box="product-id-4961">
    <span class="special-price">
        

<span class="price-container price-final_price&#x20;tax&#x20;weee"
         x-itemprop="offers" x-itemscope x-itemtype="http://schema.org/Offer">
            <span style="display:none">Sonderangebot</span>
        <span  id="product-price-4961"                data-price-amount="96.99"
        data-price-type="finalPrice"
        class="price-wrapper "
    ><span class="price">96,99 €</span></span>
                <link x-itemprop="url" href="https://example.com/anvil" />
        <meta x-itemprop="availability" content="InStock" />
        <meta x-itemprop="priceCurrency" content="EUR" />
        <meta x-itemprop="itemCondition" content="NewCondition" />
        <meta x-itemprop="price" content="96.99" />
        <meta x-itemprop="priceValidUntil" content="2026-12-31" />
    </span>
    </span>
    <span class="product-incl-btw">inkl. MwSt.</span>
    
        <span class="old-price">
            

<span class="price-container price-final_price&#x20;tax&#x20;weee"
        >
            <span style="display:none">Listenpreis</span>
        <span  id="old-price-4961"                data-price-amount="136.99"
        data-price-type="oldPrice"
        class="price-wrapper "
    ><span class="price">136,99 €</span></span>
        </span>
        </span>

                    <span class="product-discount">-<font>29%</font> Rabatt</span>
              

<!--    显示批量设置标签1-->

<!--注释产品列表显示多件折扣-->
</div></div><style>
    .klarna-placement-container{
        margin-top: 15px;
        margin-bottom: 15px;
        min-height: 21.5px;
    }
  .klarna-placement-container  klarna-placement::part(osm-container){
    border: none;
    padding: 0;
} 
.klarna-placement-container  klarna-placement::part(osm-badge){
  width: 50px;
  height: 21.05px;
}
.klarna-placement-container  klarna-placement::part(osm-legal){
    display: none;
}
.klarna-placement-container  klarna-placement::part(osm-message){
    margin-left: -4px;
}
.klarna-placement-container  klarna-placement::part(osm-message),
.klarna-placement-container  klarna-placement::part(osm-cta){
    font-family: "Poppins-regular";
    font-size: 14px;
    line-height: 1.5;
} 
</style>
<!-- Placement v2 -->
<div class="klarna-placement-container">
    <klarna-placement
        data-key="credit-promotion-badge"
        data-locale="de-DE"
                    data-purchase-amount="9699"
                            data-theme="default"
                
    ></klarna-placement>
</div>
<!-- end Placement -->
<div id="product-coupon-rows" class="product-coupon-rows">
    <div class="product-coupon-main">
        <div id="coupon-description-list" class="coupon-description-list">
        </div>
        <div class="coupon-description-more">
            <span class="txt">Jetzt sichern</span>
            <span class="arrow">></span>
        </div>
    </div>
</div>
<div id="prodetail-new-coupons-wrapper" class="prodetail-new-coupons-wrapper">
    <div id="prodetail-new-coupons-main" class="prodetail-new-coupons-main">
        <div class="title">
            <span class="coupon-text">Coupon Details</span>
            <button type="button" id="prodetail-new-coupons-close" class="action close prodetail-new-coupons-close"><svg
                    class="prodetail-new-coupons-close" width="18" height="18" viewBox="0 0 18 18" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M17.312 0C17.129 8.2016e-05 16.9535 0.0728569 16.8241 0.202316L0.20211 16.8221C0.138032 16.8862 0.0872029 16.9623 0.0525247 17.046C0.0178466 17.1297 -1.26282e-06 17.2194 0 17.31C1.26295e-06 17.4006 0.0178517 17.4904 0.0525322 17.5741C0.0872127 17.6578 0.138044 17.7338 0.202124 17.7979C0.266204 17.862 0.342278 17.9128 0.426001 17.9475C0.509725 17.9822 0.599459 18 0.690081 18C0.780702 18 0.870436 17.9822 0.954159 17.9475C1.03788 17.9128 1.11395 17.862 1.17803 17.7979L17.8014 1.17667C17.8968 1.07972 17.9615 0.95681 17.9874 0.823309C18.0132 0.689806 17.9992 0.551634 17.947 0.426069C17.8948 0.300505 17.8067 0.193119 17.6937 0.117336C17.5808 0.0415554 17.448 0.000741959 17.312 0Z"
                        fill="#333333" />
                    <path
                        d="M0.692654 5.72205e-06C0.55574 -0.000608444 0.421741 0.0395546 0.307732 0.115377C0.193722 0.191202 0.104862 0.299253 0.0524743 0.425768C8.62123e-05 0.55228 -0.0134585 0.69153 0.0135656 0.825771C0.0405898 0.960011 0.106959 1.08317 0.204218 1.17955L16.8438 17.8199C16.9752 17.9396 17.1477 18.004 17.3254 17.9998C17.5031 17.9956 17.6724 17.923 17.798 17.7972C17.9236 17.6714 17.9959 17.5021 17.9998 17.3243C18.0038 17.1466 17.9391 16.9742 17.8192 16.8429L1.18109 0.202572C1.11701 0.138329 1.04087 0.0873661 0.957057 0.0526047C0.873242 0.0178452 0.78339 -3.05176e-05 0.692654 5.72205e-06Z"
                        fill="#333333" />
                </svg></button>
        </div>
        <!-- <div class="new-coupons-title">Special Event Savings</div> -->
        <div class="scrollbar-inner">
            <div id="new-coupons-wrap" class="new-coupons-wrap">
                <div id="new-coupons-list" class="new-coupons-list">

                </div>
            </div>
        </div>
        <p class="new-coupon-bootom-tips">*Normalerweise kann nur ein Coupon auf jede Bestellung angewendet werden.</p>
    </div>
    <div class="new-coupons-box-bg"></div>
</div>


<style>
.product-coupon-wrap {
    background: rgba(232, 84, 52, 0.05);
    border-radius: 6px;
    line-height: 30px;
    color: #333;
    margin-bottom: 10px;
    padding-right: 15px;
    position: relative;
    display: inline-block;
}
.product-coupon-wrap .costwayday-get-now {
    text-decoration: underline;
    cursor: pointer;
}
.product-coupon-wrap .icon1 {
    vertical-align: middle;
    margin: 0 4px 0 8px;
    width: 20px;
}
.coupon-promotion .product-coupon-wrap .icon2 {
    margin: 0 0 0 7px;
    vertical-align: middle;
}
.product-coupon-wrap .pound {
    position: absolute;
    top: 1.5px;
    left: 14px;
    color: #fff;
    font-size: 12px;
}
.product-coupon-wrap .use-code-box {
    margin-left: 14px;
}
.product-coupon-wrap .costwayday-get-now {
    margin-left: 20px;
}
.product-coupon-wrap .code-tips {
    font-weight: 700;
}
.product-coupon-wrap .code-tips.copied {
    text-decoration: underline dotted #333;
}
.product-coupon-wrap .copy-svg {
    width: 15px;
    height: 16px;
    margin-right: 0;
    outline: none;
    cursor: pointer;
    position: absolute;
    top: -4px;
    padding: 3px;
    right: -2px;
}
.product-coupon-wrap .svg-box {
    display: inline-block;
    width: 1.5rem;
    margin-left: 5px;
    position: relative;
    height: 13px;
}
.product-coupon-wrap .svg-box:hover .tooltiptext {
    visibility: visible;
}
.product-coupon-wrap .tooltiptext {
    cursor: auto;
    visibility: hidden;
    background-color: rgb(102, 102, 102);
    color: #fff;
    text-align: center;
    padding: 3px 8px;
    border-radius: 6px;
    position: absolute;
    z-index: 1;
    top: -50px;
    margin-left: -60px;
    right: -29px;
    line-height: 30px;
}
.product-coupon-wrap .tooltiptext.copied {
        top: -42px;
        right: -24px;
        visibility: visible;
    }
    .product-coupon-wrap .tooltiptext::after {
        content: " ";
        position: absolute;
        top: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: rgb(102, 102, 102) transparent transparent transparent;
    }
    .product-coupon-wrap .copied-box {
        display: none;
    }
    .product-coupon-wrap .copy-copied-svg {
        height: 11px;
    }
    .border-dashed {
        border-bottom:1px dashed #ddd;
        display: block;
        margin-bottom: 1rem;
    }
    .coupon-promotion .product-coupon-wrap {
        background-color: #F9F9F9;
    }
    .pc {
        display: inline-block;
    }
    .mb {
        display: none !important;
    }
    .coupon-promotion .product-coupon-wrap .costwayday-get-now {
        margin-left: 0;
    }
    .coupon-promotion .tips {
        white-space: pre;
    }
@media screen and (max-width:767px) {
    .mb {
        display: inline-block !important;
    }
    .pc {
        display: none !important;
    }
    .product-coupon-wrap {
        display: block;
        padding-right: 0;
    }
    .product-coupon-wrap .costwayday-get-now {
        display: inline-block;
        margin-left: 36px;
    }
    .product-coupon-con {
        line-height: 24px;
    }
    .prodetail-coupons-wrapper .prodetail-coupons-main .coupons-list .right {
        margin-left: 12px;
    }
}
</style>
<!--优惠信息存在,如果是配置缺货产品就不显示,其他都显示-->


<div class="dePro-delivery-wrapper">
    <div class="detailPro-delivery free-delivery">
        <svg width="22" height="22" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M21.5995 9.26489C22.2055 9.26489 22.7865 9.50489 23.2145 9.93189L26.832 13.5419C27.0436 13.7529 27.2115 14.0035 27.3261 14.2794C27.4407 14.5553 27.4998 14.8511 27.5 15.1499V20.9599C27.4997 21.1157 27.4687 21.2699 27.4087 21.4138C27.3488 21.5576 27.2611 21.6882 27.1507 21.7981C27.0403 21.9081 26.9093 21.9952 26.7652 22.0545C26.6212 22.1139 26.4668 22.1442 26.311 22.1439H24.4395C24.2196 21.3582 23.7487 20.666 23.0986 20.1731C22.4485 19.6802 21.6549 19.4135 20.839 19.4139C19.124 19.4139 17.6765 20.5689 17.2385 22.1439H13.495C13.2751 21.3582 12.8042 20.666 12.1541 20.1731C11.504 19.6802 10.7104 19.4135 9.8945 19.4139C8.1795 19.4139 6.732 20.5689 6.2945 22.1439H6.064C5.90819 22.1442 5.75383 22.1139 5.60975 22.0545C5.46568 21.9952 5.33469 21.9081 5.22429 21.7981C5.11388 21.6882 5.0262 21.5576 4.96627 21.4138C4.90634 21.2699 4.87533 21.1157 4.875 20.9599V17.5234H15.435C15.7099 17.5235 15.9822 17.4695 16.2362 17.3644C16.4903 17.2593 16.7211 17.1052 16.9156 16.9109C17.1101 16.7166 17.2644 16.4859 17.3698 16.232C17.4751 15.978 17.5294 15.7058 17.5295 15.4309V9.26489H21.5995V9.26489ZM24.6275 8.51639C23.8237 7.71476 22.7347 7.26469 21.5995 7.26489H16.5295C16.3982 7.26489 16.2681 7.29076 16.1468 7.34101C16.0255 7.39127 15.9153 7.46493 15.8224 7.55779C15.7295 7.65064 15.6559 7.76088 15.6056 7.88221C15.5554 8.00353 15.5295 8.13357 15.5295 8.26489V15.4314C15.5295 15.4804 15.4895 15.5239 15.435 15.5239H3.875C3.60978 15.5239 3.35543 15.6293 3.16789 15.8168C2.98036 16.0043 2.875 16.2587 2.875 16.5239V20.9604C2.875 22.7209 4.305 24.1444 6.064 24.1444H7.1585C7.42372 24.1444 7.67807 24.039 7.86561 23.8515C8.05314 23.664 8.1585 23.4096 8.1585 23.1444C8.1585 22.1909 8.9335 21.4144 9.8945 21.4144C10.1221 21.414 10.3475 21.4584 10.5579 21.5452C10.7683 21.6319 10.9596 21.7592 11.1208 21.9199C11.282 22.0805 11.41 22.2713 11.4974 22.4814C11.5849 22.6915 11.6301 22.9168 11.6305 23.1444C11.6305 23.4096 11.7359 23.664 11.9234 23.8515C12.1109 24.039 12.3653 24.1444 12.6305 24.1444H18.103C18.3682 24.1444 18.6226 24.039 18.8101 23.8515C18.9976 23.664 19.103 23.4096 19.103 23.1444C19.103 22.1909 19.878 21.4144 20.839 21.4144C21.0666 21.414 21.292 21.4584 21.5024 21.5452C21.7128 21.6319 21.9041 21.7592 22.0653 21.9199C22.2265 22.0805 22.3545 22.2713 22.4419 22.4814C22.5294 22.6915 22.5746 22.9168 22.575 23.1444C22.575 23.4096 22.6804 23.664 22.8679 23.8515C23.0554 24.039 23.3098 24.1444 23.575 24.1444H26.311C28.0705 24.1449 29.5 22.7209 29.5 20.9604V15.1504C29.5 14.0154 29.048 12.9279 28.245 12.1259L24.6275 8.51639V8.51639Z" fill="#333333"/>
            <path d="M20.889 21.375C21.1166 21.3746 21.342 21.419 21.5524 21.5058C21.7628 21.5925 21.9541 21.7198 22.1153 21.8805C22.2765 22.0411 22.4045 22.2319 22.4919 22.442C22.5794 22.6521 22.6246 22.8774 22.625 23.105C22.625 24.059 21.85 24.8355 20.889 24.8355C20.6614 24.8359 20.436 24.7915 20.2256 24.7047C20.0151 24.618 19.8239 24.4907 19.6627 24.33C19.5015 24.1694 19.3735 23.9786 19.286 23.7685C19.1986 23.5584 19.1534 23.3331 19.153 23.1055C19.153 22.1515 19.928 21.375 20.889 21.375ZM24.625 23.105C24.625 21.043 22.95 19.375 20.889 19.375C18.8275 19.375 17.153 21.043 17.153 23.105C17.153 25.1675 18.8275 26.8355 20.889 26.8355C22.9505 26.8355 24.625 25.1675 24.625 23.1055V23.105ZM9.88897 21.375C10.1166 21.3746 10.342 21.419 10.5524 21.5058C10.7628 21.5925 10.9541 21.7198 11.1153 21.8805C11.2765 22.0411 11.4045 22.2319 11.4919 22.442C11.5794 22.6521 11.6246 22.8774 11.625 23.105C11.625 24.059 10.85 24.8355 9.88897 24.8355C9.66139 24.8359 9.43596 24.7915 9.22555 24.7047C9.01515 24.618 8.82388 24.4907 8.66268 24.33C8.50148 24.1694 8.37349 23.9786 8.28604 23.7685C8.19858 23.5584 8.15337 23.3331 8.15297 23.1055C8.15297 22.1515 8.92797 21.375 9.88897 21.375ZM13.625 23.105C13.625 21.043 11.95 19.375 9.88897 19.375C7.82747 19.375 6.15297 21.043 6.15297 23.105C6.15297 25.1675 7.82747 26.8355 9.88897 26.8355C11.9505 26.8355 13.625 25.1675 13.625 23.1055V23.105ZM21.319 11.1685C21.2262 11.2615 21.1526 11.3718 21.1024 11.4932C21.0523 11.6146 21.0265 11.7447 21.0267 11.8761C21.0268 12.0074 21.0528 12.1375 21.1033 12.2588C21.1537 12.3801 21.2275 12.4902 21.3205 12.583L23.5435 14.801C23.7312 14.9884 23.9856 15.0935 24.2509 15.0933C24.5161 15.093 24.7703 14.9875 24.9577 14.7998C25.1451 14.612 25.2502 14.3576 25.25 14.0924C25.2498 13.8271 25.1442 13.5729 24.9565 13.3855L22.733 11.167C22.5452 10.9797 22.2908 10.8747 22.0257 10.875C21.7605 10.8752 21.5063 10.9808 21.319 11.1685V11.1685ZM17.5 5.875C17.5 5.34457 17.2893 4.83586 16.9142 4.46079C16.5391 4.08571 16.0304 3.875 15.5 3.875H4.87497C4.34454 3.875 3.83583 4.08571 3.46076 4.46079C3.08569 4.83586 2.87497 5.34457 2.87497 5.875V16.375C2.87497 16.6402 2.98033 16.8946 3.16787 17.0821C3.3554 17.2696 3.60976 17.375 3.87497 17.375H15.5C16.0304 17.375 16.5391 17.1643 16.9142 16.7892C17.2893 16.4141 17.5 15.9054 17.5 15.375V5.875ZM4.87497 5.875H15.5V15.375H4.87497V5.875Z" fill="#333333"/>
        </svg>Kostenloser Versand
    </div>
</div>





    <div id="early-bird-warpper"></div>
 




    <div class="product-notdiscount-box bg" style="display:none" >
        <span><span>
    </div>
        <div data-aw-reward-points-block-name="aw_reward_points.product.view.earning"></div>



<style>
    .product-reward-points-discount{
        margin-bottom:20px;
    }
</style>
        <div data-aw-reward-points-block-name="aw_reward_points.product.view.discount"></div>

<style>
    .shipping-container {
       margin-bottom:1rem;
    }

    .shipping-header {
        
        position: relative;
    }

    .delivery-info {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
    }

    .delivery-date {
        font-size: 14px;
        font-weight: 500;        
    }

    .info-icon {
        width: 14px;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        font-weight: bold;
        cursor: pointer;
        position: relative;
        -webkit-tap-highlight-color: transparent;
    }
    .info-icon svg{
        -webkit-tap-highlight-color: transparent;
        pointer-events: none;
    }

    .delivers-tooltip {
        position: absolute;
        background-color: #fff;
        color: #666;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: normal;
        white-space: nowrap;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 1000;
        box-shadow: 0px 1px 8px 0px rgba(157, 157, 157, 0.25);
    }
    .delivers-tooltip p {
        margin-bottom:0;
    }
    .delivers-tooltip .got-it{
        display:none;
    }

    .delivers-tooltip::before {
        content: '';
        position: absolute;
        width: 0;
        height: 0;
        border-style: solid;
    }

    /* PC端：提示框在右边 */
    @media (min-width: 769px) {
        .delivers-tooltip {
            left: calc(100% + 8px);
            top: 50%;
            transform: translateY(-50%);
        }

        .delivers-tooltip::before {
            border-width: 6px 6px 6px 0;
            border-color: transparent #fff transparent transparent;
            left: -6px;
            top: 50%;
            transform: translateY(-50%);
        }
        .info-icon:hover .delivers-tooltip {
            opacity: 1;
            visibility: visible;
        }
    }

     



    .shipping-to-line {
        display: inline-flex;
        align-items: center;
    }

    .shipping-to {
        font-size: 14px;
        color: #333;
    }

    .shipping-to .address {
        font-weight: 500;
        text-decoration:underline;
        cursor: pointer;
    }

    .expand-arrow {
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: transform 0.3s ease;
    }

    .expand-arrow.expanded {
        transform: rotate(180deg);
    }

    .expand-arrow svg {
        width: 17px;
        height: 7px;
    }

    .form-section {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
    }

    .form-section.expanded {
        max-height: 200px;
    }

    .form-content {
        padding: 15px 0 0;
    }

    .zip-input-container {
        display: flex;
        gap: 0;
        align-items: center;
        max-width:320px;
    }

    .zip-input {
        flex: 1;
        padding: 10px 12px !important;
        border: 1px solid #ddd;
        border-top-left-radius: 6px  !important;
        border-bottom-left-radius: 6px  !important;
        border-top-right-radius: 0  !important;
        border-bottom-right-radius: 0  !important;              
        font-size: 14px  !important;
        height:40px  !important;
        background-color: #fff  !important;
        transition: border-color 0.2s ease  !important;
    }

    .zip-input:focus {
        outline: none  !important;
        border-color: #ddd  !important;
        border-top-left-radius: 6px  !important;
        border-bottom-left-radius: 6px  !important;
        border-top-right-radius: 0  !important;
        border-bottom-right-radius: 0  !important;  
        box-shadow:none !important; 
    }

    .zip-input::placeholder {
        color: #999;
    }

    .update-btn {
        padding: 10px 20px;
        background-color: #222;
        color: #fff;
        border: none;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px;  
        font-size: 14px;
        height:40px;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .update-btn:hover {
         background-color: #222 !important;
        color: #fff !important;
        border: none  !important;
    }

    .update-btn:disabled {
        background-color: #999;
        cursor: not-allowed;
    }   

    .message {
        line-height:1.5;
        display: none;
    }   

    .error-message {
        color: #e64d43;
    }

    /* 移动端：提示框在下面 */
    @media (max-width: 767px) {
        .delivers-tooltip {
            z-index: 300;
            position: fixed;
            background: rgba(0,0,0,.6);
            box-shadow: none;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            margin: auto;
            padding: 0;
            width: 100vw;
            display:flex;            
            justify-content: center;
            align-items: center;
            white-space:normal;
        }
        .delivers-tooltip::before {
            display:none;
        }
        .delivers-tooltip.show{
            visibility: visible;
            opacity: 1;
        }
        .delivers-tooltip-cen{
            background-color: #fff;
            border-radius: 16px;
            padding: 9.333vw 4.667vw 6.667vw 5.333vw;
            font-size: 3.2vw;
            width: 320px;
        }
        .delivers-tooltip-cen p{
            font-size: 3.2vw;
            color: #333;
            line-height: 5.333vw;
            margin-bottom: 2.667vw;
            >span {
                display: inline-block;
            }
        }
        .delivers-tooltip .got-it{
            display:block;
            width: 33.333vw;
            height: 10.667vw;
            line-height: 10.667vw;
            text-align: center;
            color: #fff;
            font-size: 3.467vw;
            margin: 5.333vw auto 0;
            background: #222;
            border-radius: 5.333vw;
            padding: 0;
        }
        .zip-input-container {        
            max-width:none;
        }
    }  
    
</style>

<div class="shipping-container">
    <div class="shipping-header" >
        <div class="delivery-info">
            <span class="delivery-date" id="deliveryDate">Lieferung in 2-5 Werktagen</span>
            <span class="info-icon">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1077_1106)">
                    <path d="M7 11.9C4.29393 11.9 2.1 9.70607 2.1 7C2.1 4.29393 4.29393 2.1 7 2.1C9.70607 2.1 11.9 4.29393 11.9 7C11.9 9.70607 9.70607 11.9 7 11.9ZM7 13.125C10.3827 13.125 13.125 10.3827 13.125 7C13.125 3.61725 10.3827 0.875 7 0.875C3.61725 0.875 0.875 3.61725 0.875 7C0.875 10.3827 3.61725 13.125 7 13.125Z" fill="#7A7A7A"/>
                    <path d="M7.61245 6.08086V9.14336C7.61245 9.55169 7.40828 9.75586 6.99995 9.75586C6.59162 9.75586 6.38745 9.55169 6.38745 9.14336V6.08086C6.38745 5.67253 6.59162 5.46836 6.99995 5.46836C7.40828 5.46836 7.61245 5.67253 7.61245 6.08086ZM7.61245 4.24336C7.61245 4.65169 7.40828 4.85586 6.99995 4.85586C6.59162 4.85586 6.38745 4.65169 6.38745 4.24336C6.38745 3.83503 6.59162 3.63086 6.99995 3.63086C7.40828 3.63086 7.61245 3.83503 7.61245 4.24336Z" fill="#7A7A7A"/>
                    </g>
                    <defs>
                    <clipPath id="clip0_1077_1106">
                    <rect width="14" height="14" fill="white"/>
                    </clipPath>
                    </defs>
                </svg>
                <div class="delivers-tooltip">
                    <div class="delivers-tooltip-cen">
                        <p><span>Verzögerungen im Versand sind möglich. </span><span>Verfolgen Sie die Sendung in Echtzeit.</span></p>
                        <button type="button" class="got-it" id="got-it">OK!</button>
                    </div>
                </div>
            </span>
        </div>
        <div class="shipping-to-line">
            <div class="shipping-to">
                Schneller Versand nach: <span class="address" id="currentAddress">22143</span>
            </div>
            <div class="expand-arrow" id="expandArrow">
                <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.8432 0.211203L6.00022 5.37611L1.15676 0.211203C1.09738 0.147863 1.0259 0.096658 0.946411 0.06051C0.866921 0.0243621 0.780978 0.0039795 0.693486 0.000526465C0.605994 -0.00292657 0.518668 0.0106175 0.436494 0.0403851C0.35432 0.0701526 0.278907 0.115561 0.214561 0.174017C0.150214 0.232473 0.0981951 0.302833 0.0614719 0.381078C0.0247497 0.459324 0.0040426 0.543923 0.000534982 0.630046C-0.00297359 0.716169 0.010786 0.802128 0.041027 0.883017C0.071268 0.963905 0.117397 1.03814 0.176783 1.10148L5.51001 6.78874C5.57244 6.85535 5.6482 6.90851 5.73253 6.94487C5.81687 6.98123 5.90793 7 6 7C6.09207 7 6.18313 6.98123 6.26747 6.94487C6.3518 6.90851 6.42756 6.85535 6.48999 6.78874L11.8232 1.10148C11.8826 1.03814 11.9287 0.963905 11.959 0.883017C11.9892 0.802129 12.003 0.716169 11.9995 0.630047C11.996 0.543924 11.9753 0.459324 11.9385 0.381079C11.9018 0.302833 11.8498 0.232474 11.7854 0.174018C11.7211 0.115561 11.6457 0.0701531 11.5635 0.0403855C11.4813 0.010618 11.394 -0.00292612 11.3065 0.000526907C11.219 0.00397994 11.1331 0.0243625 11.0536 0.0605105C10.9741 0.0966584 10.9026 0.147864 10.8432 0.211203Z" fill="#222222"/>
                </svg>
            </div>
        </div>
    </div>

    <div class="form-section" id="formSection">
        <div class="form-content">
            <div class="zip-input-container">
                <input type="text" 
                        class="zip-input" 
                        id="zipCode" 
                        placeholder="Postleitzahl" 
                        maxlength="10">
                <button class="update-btn" id="updateBtn"><span>Aktualisieren</span></button>
            </div>
            <div class="message error-message" id="errorMessage"></div>
        </div>
    </div>
</div>



<style>
    .tips-out-of-stock{
        display:inline-block;
        background:#F3F3F3;
        padding: 4px 15px;
        border-radius:4px;
        font-size:16px;
        line-height:1.5;
    }
    .catalog-product-view  .amxnotif-block{
        display: flex;
        align-items: flex-end;
        flex-wrap: nowrap;
        justify-content: space-between; /* 两端对齐 */
    }
    .catalog-product-view  .amxnotif-block form{
        flex: 1;
    }
    .catalog-product-view .amxnotif-block .product-addto-links{
        width: 40px;
        margin:2.5px 0 0 10px;
    }

    .catalog-product-view .product-addto-links a,
    .catalog-product-view .amxnotif-block .notification-container .submit{
        margin:0 !important;
    }
    .product-info-main .action.alert {
        height: auto;
        width: auto;
        display: inline-block;
        border: 1px solid #ccc;
        line-height: 1.5;
        border-radius: 50px;
        font-size: 14px;
        text-align: center;
        min-width: 420px;
        cursor: pointer;
        padding: 8px 20px;
        box-sizing: border-box;
    }
    .amstockstatus-stockalert{
        margin-bottom: 10px;
    }
    .product-info-main .action.alert.success {
        pointer-events: none;
    }

    .product-info-main .oos-subscribe-button.disabled {
        pointer-events: none;
        opacity: 0.6;
    }

    @media screen and (min-width: 768px) {
        .product-info-main .product.alert.link-stock-alert .product-addto-links {
            margin: 0 10px 0 0;
         }
    }

    @media screen and (max-width: 767px) {
        .product-info-main .action.alert {
            height: auto;
            width: auto;
            display: block;          
            line-height: 1.5;
            border-radius: 50px;
            font-size: 14px;
            text-align: center;
            min-width: 100%;
            cursor: pointer;
            padding: 8px 20px;
            box-sizing: border-box;
        }
        .catalog-product-view .amxnotif-block .product-addto-links{
            display:none;
        }
        .catalog-product-view .amxnotif-block .product-addto-links{
        width: auto;
        margin:0;
    }
    }
</style>



<style>
     .bottom-to-cart{
        display:none;
    }
    @media (max-width: 750px) {
        .bottom-to-cart{
            display:block;
            position:fixed;
            bottom: 0;
            left: 0;
            z-index: 99;
            width: 100vw;
        }
        .bottom-to-cart >div{
            display:flex;
            align-items: center;
            justify-content: space-between;
            background-color: #fff;
            height:16vw;
            padding:0 4.2666vw 0 4vw;
            gap:2.66vw;
        }
        .bottom-to-cart .to-cart-price{
          font-size: 4.8vw;
          line-height: 1.5;
          text-align: left;
          color:#333;
        }
        .bottom-to-cart .cart-btn{
          width: 50vw;
          height: 10.6666vw;
          background: #ff5f44;
          border-radius: 5.3333vw;
          border: 0;
          color:#fff;
          font-size:3.7333vw
        }
        .box-tocart button[type="submit"] {
            display:none;
        }
        .bottom-to-cart .add-to-cart-btn{
            margin-left:auto;
        }
        .bottom-to-cart .add-to-cart-btn .cart-btn.oos{
            background:#D9D9D9;
            opacity: 1;
        }
        .bottom-to-cart .product-addto-links-box{
            width: 40px;
        }
    }
</style>

<div class="bottom-to-cart" id="bottom-to-cart">
    <div>
        <div class="to-cart-price"><span id="bottom-cart-price" data-price="96.99"><span class="price">96,99</span></span><span> €</span></div>
        <div class="add-to-cart-btn">
            <button class="cart-btn oos" id="add-to-cart-button" type="button">
            <span>
                                    Nicht auf Lager                            </span>
            </button>
        </div>
        <div class="product-addto-links-box"></div>
    </div>
</div>


<div class="product-add-form">
    <form data-product-sku="CM23511DE"
        action="https://www.costway.de/checkout/cart/add/uenc/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C/product/4961/" method="post" id="product_addtocart_form"
        >
        <input type="hidden" name="parent_sku" value="CM23511DE" />
        <input type="hidden" name="product" value="4961" />
        <input type="hidden" name="selected_configurable_option" value="" />
        <input type="hidden" name="related_product" id="related-products-field" value="" />
        <input type="hidden" name="item" value="4961" />
        <input type="hidden" name="piid" value="" />
        <input type="hidden" name="sku" value="CM23511DE" />
        <input type="hidden" name="oos" value="0" />
        <input type="hidden" name="child_item" value="4961" />
        <input name="form_key" type="hidden" value="VP4V4HFjyivtMHHv" />                <!--pdp显示-->
        
                    
        
                <!---->
       <div class="box-tocart" style="display:none">
            <div class="fieldset">
                <div class="field qty">
                    <div class="control">
                        <input type="number" disabled id="qty" maxlength="12" value="1" title="Qty"
                            class="input-text qty">
                        <a class="inc_qty qty-main">
                            <div class="qty-inner">
                                <i class="fa fa-caret-up"></i>
                            </div>
                        </a>
                        <a class="dec_qty qty-main">
                            <div class="qty-inner">
                                <i class="fa fa-caret-down"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="actions">
                    <button type="submit" title="Add to Cart" class="action primary tocart" id="product-addtocart-button" onclick="if (!window.__cfRLUnblockHandlers) return false; return false;" data-cf-modified-b582c3d0dfb6bd35c494053c-="">
                        <span>Nicht auf Lager</span>
                    </button>
                    <!--部署RTB代码-->

<!--    只推送简单产品,复杂产品前端处理-->
    <!--/**********2021-5-12--google跟踪代码(zdj)---start************/-->
    
    <!--/**********2021-5-12--google跟踪代码(zdj)---end************/-->



<div class="product-addto-links" data-role="add-to-links">
                        <a href="javascript:;"
               class="towishlist " title="Zur Wunschliste hinzufügen"><span>Zur Wunschliste hinzufügen</span></a>
                <!-- <a href="javascript:;" data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"4961","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
           data-role="add-to-links"
           class="tocompare"><span>Zum vergleichen hinzufügen</span></a> -->
    </div>

    
    
<!-- google Composite card mark 移到form.phtml 底部 -->
                     <div id="instant-purchase" data-bind="scope:'instant-purchase'">
                    </div>
                </div>
            </div>
        </div>
        <!---->
        
                <div class="product-options-wrapper" id="product-options-wrapper">
    <div class="fieldset" tabindex="0">
        

    </div>
</div>
<div class="product-options-bottom">
        
</div>
    </form>
</div>
<!-- RJM简单OOS 引入 -->
    <div class="amstockstatus-stockalert">
        <div class="tips-out-of-stock">Nicht auf Lager</div>

<div class="product alert stock link-stock-alert">
            <!--部署RTB代码-->

<!--    只推送简单产品,复杂产品前端处理-->
    <!--/**********2021-5-12--google跟踪代码(zdj)---start************/-->
    
    <!--/**********2021-5-12--google跟踪代码(zdj)---end************/-->



<div class="product-addto-links" data-role="add-to-links">
                        <a href="javascript:;"
               class="towishlist " title="Zur Wunschliste hinzufügen"><span>Zur Wunschliste hinzufügen</span></a>
                <!-- <a href="javascript:;" data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"4961","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
           data-role="add-to-links"
           class="tocompare"><span>Zum vergleichen hinzufügen</span></a> -->
    </div>

    
    
<!-- google Composite card mark 移到form.phtml 底部 -->
         <a role="button" tabindex="0" class="action alert oos-subscribe-button" style="display:none">Bei Verfügbarkeit benachrichtigen</a>
</div>
    </div>
<!-- 优化 DOM 可用时，点击回购 按钮后 完成自己回购动作 -->
<script type="b582c3d0dfb6bd35c494053c-text/javascript" data-no-defer="true">
    let isCatalogAddToCartJsLoaded = false;
    const isMobile = window.innerWidth < 768;
    const button = isMobile
        ? document.getElementById("add-to-cart-button")
        : document.getElementById("product-addtocart-button");

    const state = {
        isCatalogAddToCartJsLoaded: false,
        addToCartClicked: false // 只有用户点击后才变 true
    };

    const stateProxy = new Proxy(state, {
        set(target, key, value) {
            target[key] = value;
            if (key === 'isCatalogAddToCartJsLoaded' && value === true) {
                //console.log("catalogAddToCart.js 已加载");

                const isConfigurableProduct = document.body.classList.contains('page-product-configurable');

                if (isConfigurableProduct) {
                    const wrapper = document.getElementById("product-options-wrapper");
                    if (wrapper) {
                        const swatchAttributes = wrapper.querySelectorAll('.swatch-attribute');
                    // 确保所有 swatch-attribute 元素都有非空的 data-option-selected
                        const allSelected = swatchAttributes.length > 0 && Array.from(swatchAttributes).every(attr =>
                            attr.hasAttribute('data-option-selected') && attr.getAttribute('data-option-selected').trim() !== ""
                        );

                        if (allSelected) {
                            handleButtonSubmitForm()
                        }
                    }

                }else{
                    handleButtonSubmitForm()
                }


            }
            return true;
        }
    });

    function handleButtonSubmitForm(){
        // 仅在用户点击后才提交
        if (stateProxy.addToCartClicked) {
            //console.log("用户点击过, catalogAddToCart 加载完成后自动提交...");
            onCatalogAddToCartLoaded();
        }
        // 解绑 `click` 事件，避免重复绑定
        if (button) {
            button.removeEventListener("click", handleAddToCartClick);
            button.removeEventListener("touchstart", handleAddToCartClick);
        }

        // 移除 `onclick="return false;"` 属性
        if (button) {
            button.removeAttribute('onclick');
        }
        if(isMobile){
            document.getElementById("product-addtocart-button").removeAttribute('onclick');
        }
    }

    // catalogAddToCart 加载完成后执行的逻辑
    function onCatalogAddToCartLoaded() {
        //console.log("执行加入购物车逻辑...");
        require([
            'jquery',
            'mage/translate',
            'mage/mage',
            'Magento_Catalog/product/view/validation',
            'Magento_Catalog/js/catalog-add-to-cart',
            'underscore',
            'Magento_Catalog/js/product/view/product-ids-resolver',
            'Magento_Catalog/js/product/view/product-info-resolver',
            'jquery-ui-modules/widget',
            'mage/cookies'
        ], function ($,$t) {
            var form = '#product_addtocart_form';
            var widget = $(form).catalogAddToCart({
                bindSubmit: false
            });
            widget.catalogAddToCart('disableAddToCartButton',$(form));
            widget.catalogAddToCart('submitForm', $(form));
            button.disabled = false;
            button.classList.remove('no-js-click');

            const isConfigurableProduct = document.body.classList.contains('page-product-configurable');
            if (isConfigurableProduct) {
                button.classList.add('clicked');
            }
        });
    }

    // 处理点击事件
    function handleAddToCartClick(event) {
        event.preventDefault(); // 阻止默认提交行为
        //console.log("触发加入购物车点击事件");
        if (!stateProxy.isCatalogAddToCartJsLoaded ) {
            button.disabled = true;
            const _span = button.querySelector('span');
            if (_span) {
                _span.textContent = "Hinzufügen…";
            }else{
                button.textContent = "Hinzufügen…";
            }
            button.classList.add('no-js-click');
            stateProxy.addToCartClicked = true; // 记录用户点击状态
            //console.log("catalogAddToCart.js 未加载，等待加载...");
        } else {
            onCatalogAddToCartLoaded(); // 直接执行
        }
    }

    // 监听 `catalogAddToCart` 是否已加载
    const loadingCatalogAddToCartTimer = setInterval(() => {
        let isCatalogAddToCartLoaded = false;
        if (typeof requirejs !== 'undefined') {
            isCatalogAddToCartLoaded = requirejs.defined('catalogAddToCart');
        }

        if (!isCatalogAddToCartLoaded) return;

        const isConfigurableProduct = document.body.classList.contains('page-product-configurable');

        if (!isConfigurableProduct) {
            //console.log("简单产品 catalogAddToCart.js 已准备就位");
            clearInterval(loadingCatalogAddToCartTimer);
            stateProxy.isCatalogAddToCartJsLoaded = true;
            return;
        }

        const wrapper = document.getElementById("product-options-wrapper");
        if (wrapper) {
            const swatchAttributes = wrapper.querySelectorAll('.swatch-attribute');
           // 确保所有 swatch-attribute 元素都有非空的 data-option-selected
            const allSelected = swatchAttributes.length > 0 && Array.from(swatchAttributes).every(attr =>
                attr.hasAttribute('data-option-selected') && attr.getAttribute('data-option-selected').trim() !== ""
            );

            if (allSelected) {
                //console.log("复杂产品 选中了子产品 已准备就位");
                clearInterval(loadingCatalogAddToCartTimer);
                stateProxy.isCatalogAddToCartJsLoaded = true;
            }
        }
    }, 50);

    if (button){
            //console.log("绑定加入购物车事件");
            button.addEventListener("click", handleAddToCartClick);
            button.addEventListener("touchstart", handleAddToCartClick, { passive: true });

            // 绑定 `onclick="return false;"` 防止提交表单
            button.setAttribute('onclick', 'return false;');
    }

    // 优化 DOM 可用时，点击回购 按钮后 完成自己回购动作  END
</script>



<style>
    .product-img{
        font-size: 0;
    }
    .product-img .img-row{
        display: block;
        margin-bottom: 5px;

    }
    .product-img .img-row .mb {
        display: none;
    }
    .bf24-rules {
        cursor: pointer;
    }
    @media screen and (max-width: 750px) {
        .product-img .img-row{
            margin-bottom: 3px;
        }
        .product-img .img-row .pc {
            display: none;
        }
        .product-img .img-row .mb {
            display: block;
        }
    }
    .common-pop.free-gift-pop .common-pop-con .close {
        left: 50%;
        margin-left: -27px;
        color: #fff;
        top: auto;
        bottom: -50px;
    }
    .common-pop.free-gift-pop .common-pop-con .close::before {
        font-size: 35px;
    }
    .common-pop.free-gift-pop .common-pop-con {
        padding: 30px 40px 15px 50px;
        background-color: #FFC842;
        width: 720px;
        font-size: 17px;
    }
    .common-pop.free-gift-pop .common-pop-con h4 {
        font-size: 24px;
        text-align: center;
    }
    .common-pop.free-gift-pop .common-pop-con ol {
        margin-bottom: 20px;
    }
    .common-pop.free-gift-pop .common-pop-con .rules-title {
        margin-top: 0;
        border-bottom: 2px solid #f3f3f3;
        padding-bottom: 20px;
    }
    .common-pop.free-gift-pop p {
        color: #000;
    }
    .common-pop.free-gift-pop .common-pop-con ol li {
        list-style: auto !important;
    }
    .common-pop.free-gift-pop .common-pop-con ol li span {
        text-decoration: underline;
        font-weight: 600;
    }
    .free-gift-pop {
        display: none;
    }
    @media screen and (max-width: 767px) {
        .common-pop.free-gift-pop .common-pop-con {
        width: 83vw;
        padding: 15px;
        }
        .common-pop.free-gift-pop .common-pop-con .rules-title {
        border-bottom: 1px solid #f3f3f3;
        margin-bottom: 10px;
        padding-bottom: 10px;
        }
        .free-gift-pop .rules-desc {
        font-size: 13px;
        }
        .common-pop.free-gift-pop .common-pop-con h4 {
        font-size: 16px;
        }
        .free-gift-pop .how-play {
        margin: 12px 0 10px;
        }
        .common-pop.free-gift-pop .common-pop-con ol {
        margin-bottom: 5px;
        }
        .common-pop.free-gift-pop .common-pop-con ol li {
        margin-bottom: 3px;
        margin-left: 20px;
        font-size: 13px;
        }
        .common-pop.free-gift-pop .free-gift-tips p {
            font-size: 12px;
            margin-bottom: 4px;
        }
        .free-gift-con {
        overflow-y: auto;
        max-height: 450px;
        }
    }
</style>




<!-- 从addto.phtml 移入此处 防止页面重复 -->
<!-- google Composite card mark -->
    <mate x-itemprop="name" content="180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern"></mate>
    <meta x-itemprop="gtin" content="0661706101578" />
    <link x-itemprop="image" href="https://www.costway.de/media/catalog/product/cache/bbfaed54adcd969869090b8940d0426e/k/_/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_2_.jpg" />
    <div x-itemprop="aggregateRating" x-itemtype="https://schema.org/AggregateRating" x-itemscope>
        <meta x-itemprop="reviewCount" content="3" />
        <meta x-itemprop="ratingValue" content="4.8" />
    </div>
    <div x-itemprop="brand" x-itemtype="https://schema.org/Brand" x-itemscope>
        <meta x-itemprop="name" content="COSTWAY" />
    </div>
    <div x-itemprop="review" x-itemtype="https://schema.org/Review" x-itemscope>
        <div x-itemprop="author" x-itemtype="https://schema.org/Person" x-itemscope>
            <meta x-itemprop="name" content="Tanno" />
        </div>
        <div x-itemprop="reviewRating" x-itemtype="https://schema.org/Rating" x-itemscope>
            <meta x-itemprop="ratingValue" content="4.8" />
            <meta x-itemprop="bestRating" content="5" />
        </div>
    </div>
    
    <!-- google Composite card mark  end -->

<!-- 到货提醒按钮 -->
 
<div class="product-social-links">    <a href="https://www.costway.de/sendfriend/product/send/id/4961/"
       class="mailto friend"><span>E-Mail</span></a>
</div>        <div data-aw-reward-points-block-name="aw_reward_points.product.view.share"></div>

    <div>
    <div class="detail-wfd">
        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none" class="icon-safe">
        <path d="M29.3371 4.65333L29.3424 18.1067C29.3424 24.8587 20.6744 32 16.0091 32C11.3424 32 2.67578 24.8587 2.67578 18.1053V4.65333L4.00111 4.632C4.02911 4.632 6.98778 4.56933 10.0411 3.328C13.1744 2.05467 15.1944 0.590667 15.2144 0.577333L16.0038 0L16.8024 0.577333C16.8198 0.590667 18.8398 2.05467 21.9731 3.328C25.0264 4.568 27.9864 4.632 28.0158 4.632L29.3358 4.65333H29.3371ZM26.6491 18.1067V7.232C24.6985 7.02311 22.7855 6.54989 20.9624 5.82533C19.2395 5.1279 17.5818 4.27879 16.0091 3.288C14.437 4.27814 12.7803 5.12723 11.0584 5.82533C8.83178 6.73067 6.69045 7.08933 5.36778 7.232V18.1053C5.36778 23.3267 12.9198 29.3053 16.0091 29.3053C19.0971 29.3053 26.6491 23.3267 26.6491 18.1053V18.1067ZM15.1144 21.696L9.45311 16.8693L11.1931 14.8173L14.8251 17.9133L21.7184 9.964L23.7531 11.732L15.1131 21.696H15.1144Z" fill="#333333"/>
        </svg>Jetzt sorgenfrei liefern lassen - mit 
        <img src="/pub/images/seel.svg" class="icon-seel" />!
    </div>
</div>
</div>        <style>
        .amrelated-grid-wrapper {
            margin-top: 40px;
        }
        .amrelated-grid-wrapper > h2 {
            margin: 0;
        }
        .amrelated-grid-wrapper .widget-product-grid {
            position: relative;
            padding: 0;
            z-index: 1;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .block-title {
            margin-bottom: 2vw;
        }
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .block-title strong {
            line-height: 1;
            font-size: 4.266666vw !important;
        }
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .block-content {
            margin: 0 -16px;
            padding: 0;
        }
        }
        .amrelated-grid-wrapper .slick-arrow {
            margin-top: -25px;
            width: 50px;
            height: 50px;
            border-radius: 25px;
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid #CCCCCC;
        }
        .amrelated-grid-wrapper .slick-arrow.slick-prev {
            left: 20px;
        }
        .amrelated-grid-wrapper .slick-arrow.slick-next {
            right: 10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-list {
            padding: 2vw 0 2vw 4.2666vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide {
            flex: 0 0 240px;
            margin: 0;
            display: inline-flex !important;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide {
            flex: none;
            flex-shrink: 0;
            width: 42.666vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide .product-item {
            max-width: none !important;
        }
        @media (min-width: 767px) {
            .amrelated-grid-wrapper .slick-slide .product-item-name {
            max-width: 180px;
            margin-bottom: 10px;
        }
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide .product-item-name {
            font-size: 3.2vw !important;
            margin-bottom: 2.6666vw;
            max-width: 34vw;
        }
        }
        .amrelated-grid-wrapper .slick-slide .product-item-name a {
            line-height: 1.5;
            text-align: left;
        }
        .amrelated-grid-wrapper .slick-slide .product-item-info .product-item-photo a {
            display: block;
            font-size: 0;
        }
        .amrelated-grid-wrapper .slick-slide > div {
            margin: 0 10px 10px;
            background: #FFFFFF;
            box-shadow: 0px 5px 19px rgba(0, 0, 0, 0.08);
            border-radius: 8px;
            padding: 20px 20px 10px;
            width: 100%;
            box-sizing: border-box;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div {
            margin: 0 2.666vw 2.666vw 0;
            border: 1px solid rgba(204, 204, 204, 0.4);
            box-shadow: 1px 1px 1.5vw 2px rgba(102, 102, 102, 0.1);
            padding: 2.666666vw;
            border-radius: 8px;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box {
            text-align: left;
            margin-bottom: 10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box {
            margin-bottom: 1.33333vw;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .price {
            font-weight: normal;
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .normal-price {
            display: inline-block;
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .normal-price {
            margin-bottom: 10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price, .amrelated-grid-wrapper .slick-slide > div .price-box .old-price, .amrelated-grid-wrapper .slick-slide > div .price-box .normal-price {
            margin-bottom: 1.3333vw;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price {
            text-decoration: none;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price, .amrelated-grid-wrapper .slick-slide > div .price-box .old-price {
            padding-left: 0;
            padding-right: 0;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price {
            margin-right: 5px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price {
            margin-right: 1.333vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price .price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .price-final_price .price {
            font-size: 18px !important;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price .price, .amrelated-grid-wrapper .slick-slide > div .price-box .price-final_price .price {
            font-size: 4vw !important;
        }
        }
        @media (max-width: 380px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price .price, .amrelated-grid-wrapper .slick-slide > div .price-box .price-final_price .price {
            font-size: 3.755vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price > span {
            text-decoration: none;
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price .price {
            font-size: 14px !important;
            text-decoration: line-through;
            color: #999;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .old-price .price {
            font-size: 3.2vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div :hover .towishlist {
            position: absolute;
            background: #f9f9f9;
            width: 40px;
            height: 40px;
            text-align: center;
            line-height: 40px;
            border-radius: 50%;
            right: -10px;
            top: -10px;
            z-index: 1;
        }
        .amrelated-grid-wrapper .slick-slide > div :hover .towishlist::before {
            content: "";
            display: inline-block;
            width: 24px;
            height: 24px;
            background-size: 20px 20px;
            background: url(/pub/images/home/towish.png) no-repeat;
            background-position: center;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .towishlist {
            position: absolute;
            background: #f9f9f9;
            text-align: center;
            border-radius: 50%;
            z-index: 1;
            width: 35px !important;
            height: 35px !important;
            line-height: 35px !important;
            right: 0 !important;
            top: 0 !important;
        }
        .amrelated-grid-wrapper .slick-slide > div .towishlist::before {
            content: "";
            display: inline-block;
            width: 24px;
            height: 24px;
            background-size: 20px 20px;
            background: url(/pub/images/home/towish.png) no-repeat;
            background-position: center;
        }
        }
        .amrelated-grid-wrapper .slick-slide .product-image-container {
            width: 100% !important;
        }
        .amrelated-grid-wrapper .slick-slide .product-image-wrapper {
            padding-bottom: 100% !important;
        }
        .amrelated-grid-wrapper .slick-slide .product-item-actions > .actions-primary {
            display: none;
        }
        .amrelated-grid-wrapper .slick-slide .product-item-actions .tocompare {
            display: none;
        }
        .amrelated-grid-wrapper .product-item-info .on-sale-tips {
            top: -10px;
            left: -10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .product-item-info .on-sale-tips {
            top: -1vw;
            left: -1vw;
        }
        }
    </style>
    <div class="block widget amrelated-grid-wrapper block-products-list grid"
         id="amrelated-block-4"
    >
                <h2 class="block-title">Ähnliche Produkte</h2>
                <div class="block-content">
            <div class="products-grid grid">
                <div class="product-items widget-product-grid" data-amrelated-js="slider">
                                                                <div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/180-cm-hohe-aufblasbare-weihnachtsdekoration-nachstellung-der-geburt-jesu-mit-led-lichter.html?entrypoint=relatedproducts" class="product-item-photo">
                                <span class="product-image-container product-image-container-7860">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/w/e/weihnachtskrippendekoration-cm24297de_7_.jpg"
            width="240"
            height="300"
            alt="nachbildung&#x20;der&#x20;geburt&#x20;jesu"/></span>
</span>
<style>.product-image-container-7860 {
    width: 240px;
}
.product-image-container-7860 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="180 cm hohe Aufblasbare Weihnachtsdekoration Nachstellung der Geburt Jesu mit LED-Lichter"
                                        href="https://www.costway.de/180-cm-hohe-aufblasbare-weihnachtsdekoration-nachstellung-der-geburt-jesu-mit-led-lichter.html?entrypoint=relatedproducts"
                                        class="product-item-link">
                                        180 cm hohe Aufblasbare Weihnachtsdekoration Nachstellung der Geburt Jesu mit LED-Lichter                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="7860">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-7860"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">86,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-7860"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/7860\/","data":{"product":"7860","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":7860,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"7860","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/costway-2-in-1-ganzkorper-spiegel-ganzkorperspiegel-mit-holzrahmen-37-x-155-cm-weiss.html?entrypoint=relatedproducts" class="product-item-photo">
                                <span class="product-image-container product-image-container-3885">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/_/6/_6_3_25.jpg"
            width="240"
            height="300"
            alt="ankleidespiegel"/></span>
</span>
<style>.product-image-container-3885 {
    width: 240px;
}
.product-image-container-3885 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="2 in 1 Ganzkörper-Spiegel Ganzkörperspiegel mit Holzrahmen 37 x 155 cm Weiß"
                                        href="https://www.costway.de/costway-2-in-1-ganzkorper-spiegel-ganzkorperspiegel-mit-holzrahmen-37-x-155-cm-weiss.html?entrypoint=relatedproducts"
                                        class="product-item-link">
                                        2 in 1 Ganzkörper-Spiegel Ganzkörperspiegel mit Holzrahmen 37 x 155 cm Weiß                                    </a>
                                </h3>
                                                                            <div class="product-reviews-summary short">
                <div class="rating-summary">
            <span class="label"><span>Bewertung:</span></span>
            <div class="rating-result"
                 id="rating-result_3885"
                 title="95%">
                <span style="width: 95%"><span>95%</span></span>
            </div>
                    </div>
                <div class="reviews-actions">
            <a class="action view"
               href="https://www.costway.de/costway-2-in-1-ganzkorper-spiegel-ganzkorperspiegel-mit-holzrahmen-37-x-155-cm-weiss.html#reviews">4&nbsp;<span>Bewertungen                </span>
            </a>
        </div>
    </div>
                                                                                                
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="3885">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-3885"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">64,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-3885"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/3885\/","data":{"product":"3885","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":3885,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"3885","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/160-x-40-cm-ganzkorperspiegel-2-in-1-standspiegel-wandspiegel-aus-bruchsicherem-glas-silber.html?entrypoint=relatedproducts" class="product-item-photo">
                                <span class="product-image-container product-image-container-8977">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/a/n/ankleidespiegel-jv10048sl_1_.jpg"
            width="240"
            height="300"
            alt="Ganzk&#xF6;rperspiegel&#x20;"/></span>
</span>
<style>.product-image-container-8977 {
    width: 240px;
}
.product-image-container-8977 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                            <span class="on-sale-tips mega sale -10%">Mega Sale -10%</span>
                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="160 x 40 cm Ganzkörperspiegel 2 in 1 Standspiegel &amp; Wandspiegel aus bruchsicherem Glas Silber"
                                        href="https://www.costway.de/160-x-40-cm-ganzkorperspiegel-2-in-1-standspiegel-wandspiegel-aus-bruchsicherem-glas-silber.html?entrypoint=relatedproducts"
                                        class="product-item-link">
                                        160 x 40 cm Ganzkörperspiegel 2 in 1 Standspiegel &amp; Wandspiegel aus bruchsicherem Glas Silber                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="8977">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-8977"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">84,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-8977"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/8977\/","data":{"product":"8977","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":8977,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"8977","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/handlauf-seitliche-montage-treppengelander-eingangsgelander-mit-flexiblem-winkelverstellung-138-cm.html?entrypoint=relatedproducts" class="product-item-photo">
                                <span class="product-image-container product-image-container-14026">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/h/a/handlaufseitlichemontagetreppengelndereingangsgelndermitflexiblemwinkelverstellung138cm_image_2.jpg"
            width="240"
            height="300"
            alt="Handlauf"/></span>
</span>
<style>.product-image-container-14026 {
    width: 240px;
}
.product-image-container-14026 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                            <div class="price-drop-list">
                                    <div class="drop-txt">Flash Sale</div>
                                    <div class="price-drop-con">
                                        <img class="icon-time" title="Endet in" src="/pub/images/decline/icon-time.png">
                                        <span class="end-in">Endet in</span>
                                        <span class="end-days" data-now="2026-05-18 02:03:43" data-time="2026-06-09 00:00:00" from-time="2026-05-13 00:00:00"></span>
                                    </div>
                                </div>
                                                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Handlauf Seitliche Montage Treppengeländer Eingangsgeländer mit Flexiblem Winkelverstellung"
                                        href="https://www.costway.de/handlauf-seitliche-montage-treppengelander-eingangsgelander-mit-flexiblem-winkelverstellung-138-cm.html?entrypoint=relatedproducts"
                                        class="product-item-link">
                                        Handlauf Seitliche Montage Treppengeländer Eingangsgeländer mit Flexiblem Winkelverstellung                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="14026">
    <span class="special-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-14026"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">53,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-14026"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">62,99 €</span></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/14026\/","data":{"product":"14026","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":14026,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"14026","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/costway-210-cm-kunstlicher-schneebedeckter-bleistift-weihnachtsbaum-mit-kiefernzapfen-grun-weiss.html?entrypoint=relatedproducts" class="product-item-photo">
                                <span class="product-image-container product-image-container-4113">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/c/m/cm22806_1_.jpg"
            width="240"
            height="300"
            alt="schneeweihnachtsbaum"/></span>
</span>
<style>.product-image-container-4113 {
    width: 240px;
}
.product-image-container-4113 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="210 cm Künstlicher Schneebedeckter Bleistift Weihnachtsbaum mit Kiefernzapfen Grün + Weiß"
                                        href="https://www.costway.de/costway-210-cm-kunstlicher-schneebedeckter-bleistift-weihnachtsbaum-mit-kiefernzapfen-grun-weiss.html?entrypoint=relatedproducts"
                                        class="product-item-link">
                                        210 cm Künstlicher Schneebedeckter Bleistift Weihnachtsbaum mit Kiefernzapfen Grün + Weiß                                    </a>
                                </h3>
                                                                            <div class="product-reviews-summary short">
                <div class="rating-summary">
            <span class="label"><span>Bewertung:</span></span>
            <div class="rating-result"
                 id="rating-result_4113"
                 title="100%">
                <span style="width: 100%"><span>100%</span></span>
            </div>
                    </div>
                <div class="reviews-actions">
            <a class="action view"
               href="https://www.costway.de/costway-210-cm-kunstlicher-schneebedeckter-bleistift-weihnachtsbaum-mit-kiefernzapfen-grun-weiss.html#reviews">5&nbsp;<span>Bewertungen                </span>
            </a>
        </div>
    </div>
                                                                                                
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="4113">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-4113"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">109,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-4113"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/4113\/","data":{"product":"4113","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":4113,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"4113","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/2er-set-kunstliche-olivenbaume-180-cm-hohe-kunstliche-olivenpflanzen-mit-kunststoff-pflanzgefass-grun.html?entrypoint=relatedproducts" class="product-item-photo">
                                <span class="product-image-container product-image-container-16640">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/k/_/k_nstliche-olivenb_ume-0672669163022_8_.jpg"
            width="240"
            height="300"
            alt="2er&#x20;set&#x20;k&#xFC;nstliche&#x20;olivenb&#xE4;ume"/></span>
</span>
<style>.product-image-container-16640 {
    width: 240px;
}
.product-image-container-16640 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="2er Set künstliche Olivenbäume 180 cm hohe künstliche Olivenpflanzen mit Kunststoff-Pflanzgefäß Grün"
                                        href="https://www.costway.de/2er-set-kunstliche-olivenbaume-180-cm-hohe-kunstliche-olivenpflanzen-mit-kunststoff-pflanzgefass-grun.html?entrypoint=relatedproducts"
                                        class="product-item-link">
                                        2er Set künstliche Olivenbäume 180 cm hohe künstliche Olivenpflanzen mit Kunststoff-Pflanzgefäß Grün                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="16640">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16640"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">125,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16640"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/16640\/","data":{"product":"16640","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":16640,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"16640","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        </div>
                                    </div>
            </div>
        </div>
    </div>
            
    
<div class="product info detailed">
        <div class="product data items" id="detailed-tabs">
                                <div class="data item title" data-role="collapsible" id="tab-label-description">
            <a class="data switch" data-toggle="trigger" href="#description"
                id="tab-label-description-title">
                <h2 style="margin: 0;">Einzelheiten</h2>

            </a>
        </div>
        <div class="data item content" aria-labelledby="tab-label-description-title"
            id="description" data-role="content">
            

<div class="product attribute description" >
        <div class="value">
                    <p><img data-src="https://www.costway.de/media/catalog/k_nstlicher-weihnachtsbaum-CM23511DE-A.jpg" alt="künstlicher-weihnachtsbaum-CM23511DE-A" /></p>
<p></p>
<p><img data-src="https://www.costway.de/media/catalog/verschneiter-beleuchteter-weihnachtsbaum-CM23511DE-A.jpg" alt="verschneiter-beleuchteter-weihnachtsbaum-CM23511DE-A" /></p>
<p></p>
<p><img data-src="https://www.costway.de/media/catalog/klappbarer-weihnachtsbaum-weihnachtsbaum-f_r-innen--und-au_endekoration-CM23511DE-A.jpg" alt="klappbarer-weihnachtsbaum-weihnachtsbaum-für-innen--und-außendekoration-CM23511DE-A" /></p>
<p></p>
<p><img data-src="https://www.costway.de/media/catalog/verschneiter-weihnachtsbaum-weihnachtsbaum-mit-LED-lichtern-CM23511DE-A.jpg" alt="verschneiter-weihnachtsbaum-weihnachtsbaum-mit-LED-lichtern-CM23511DE-A" /></p>
<p></p>
<p><img data-src="https://www.costway.de/media/catalog/metallst_nder-dichter-weihnachtsbaum-CM23511DE-A.jpg" alt="metallständer-dichter-weihnachtsbaum-CM23511DE-A" /></p>
<p>Für eine festliche Atmosphäre!<br />Unser 180cm hoher Weihnachtsbaum ist eine tolle Wahl. Er hat 423 verschneite Zweige, die ihm ein dichtes und üppiges Aussehen verleihen. Er besteht aus zu 100% neuem PVC, und ist dadurch geruchlos, feuerfest und ungiftig. Die 200 LED-Lichter mit 9 Modi garantieren eine einzigartige Beleuchtung. Egal was für eine Atmosphäre Sie gerne hätten, mit der Fernbedienung können Sie die Einstellung ganz einfach vornehmen. Das Klappdesign erleichtert Ihnen den Aufbau. Stellen Sie den Baum zuhause, im Büro und auf Feiern auf und genießen Sie die Stimmung!</p>
<p><br />Attribute:<br /><strong>Dichtes &amp; charmantes Aussehen:</strong> Durch die 423 verschneiten Zweige ist der 180cm hohe Weihnachtsbaum winterlich und sehr elegant. Abgesehen von den Lichtern ist er nicht dekoriert, sie haben also viel Platz für Baumschmuck.</p>
<p><strong>9 Modi &amp; Fernbedienung:</strong> Ausgestattet mit 200 LED-Lichtern ist der Weihnachtsbaum nachts besonders schön. Sie können aus 9 verschiedenen Beleuchtungsmodi auswählen und diese über die Fernbedienung einstellen. Dadurch entsteht eine wundervolle Atmosphäre.</p>
<p><strong>Hochwertiges PVC:</strong> Aus umweltfreundlichem und feuerfestem PVC gefertigt gesundheitlich unbedenklich und sehr sicher. Durch die hochwertigen Materialien und die exzellente Verarbeitung ist er robust und sehr langlebig.</p>
<p><strong>Praktische Klappstruktur:</strong> Durch die klappbare Struktur ist der Aufbau des Baumes sehr einfach und gelingt schnell. Außerdem sorgt der robuste Metallständer dafür, dass er aufrecht und stabil steht.</p>
<p><strong>Hübscher Weihnachtsdekor:</strong> Mit unserem verschneiten Weihnachtsbaum erhalten Sie einen absoluten Hingucker. Durch seine Beleuchtung glitzert er in verschiedensten Farben und ist eine tolle Dekoration für Ihr Zuhause oder jegliche Außenbereiche.</p>
<p><br />Eigenschaften:<br />9 Beleuchtungsmodi sorgen für eine festliche Atmosphäre<br />Einfache Einstellung der Beleuchtungsmodi mit der Fernbedienung<br />Ausgestattet mit 200 LED-Leuchten <br />100% neue PVC-Zweige sind geruchlos und nicht brennbar <br />Verschneite Zweige für eine sehr winterliche Stimmung<br />Klappbares Design für einfache Montage und Lagerung<br />Klappbarer, stabiler Metallständer für eine hohe Stabilität und dauerhafte Haltbarkeit</p>                            <div class="product add-attribute">
                <h3>Spezifikationen</h3>
                <p>Technische Daten:<br />Farbe: Weiß<br />Material: Neues PVC, Metall<br />Gesamtmaße: 76 x 180cm(Ø x H)<br />Anzahl der Zweige: 423<br />Anzahl der LED-Lichter: 200<br />Gewicht: 5,7kg</p>
<p><br />Lieferungsumfang: <br />1 x Beleuchteter Weihnachtsbaum<br />1 x Fernsteuerung<br />1 x Metallständer</p>            </div>
                        </div>
</div>




        </div>
                                <div class="data item title" data-role="collapsible" id="tab-label-reviews">
            <a class="data switch" data-toggle="trigger" href="#reviews"
                id="tab-label-reviews-title">
                <h2 style="margin: 0;">Bewertungen (<span class="counter">3</span>)</h2>

            </a>
        </div>
        <div class="data item content" aria-labelledby="tab-label-reviews-title"
            id="reviews" data-role="content">
                <style>
        .overall-rating {
            display: flex;
            margin-bottom: 20px;
        }
        .overall-rating .swiper-container {
            margin-left: 0;
        }
        .overall-rating .swiper-container .swiper-button-prev, .overall-rating .swiper-container .swiper-button-next {
            width: 40px;
            height: 40px;
            top: 70% !important;
        }
        .star-percent {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .percent-wrap {
            width: 200px;
            height: 10px;
            background-color: #F4F4F4;
            border-radius: 20px;
            margin-right: 10px;
        }
        .percent-con {
            background-color: #FFC842;
            height: 100%;
            border-radius: 20px;
        }
        .stars {
            width: 80px;
            display: flex;
            justify-content: space-between;
        }
        .rating-box {
            display: inline-block;
            vertical-align: middle;
            width: 140px;
            background: url('/pub/images/star/star_empty.png') repeat-x;
            background-size: 28px 19px;
            height: 19px;
            margin: 8px 0 12px 8px;
        }
        .rating-box .rating {
            background: url('/pub/images/star/star_solid.png') repeat-x;
            background-size: 28px 19px;
            height: 19px;
        }
        .grade {
            font-size: 28px;
            font-weight: 500;
            margin-bottom: 0;
        }
        .grade-left {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-right: 60px;
        }
        .total {
            font-size: 14px;
        }
        .star {
            margin-right: 60px;
        }

        .main-slide-photos .swiper-wrapper .swiper-slide {
        width: 100px;
        margin-right: 10px;
        }

        .swiper-container .cus-img, .main-slide-photos .swiper-container video {
        width: 100px;
        height: 100px;
        display: block;
        cursor: pointer;
        }

        .customer-photos {
            display: none;
        }
        .video-wrap {
            position: relative;
            width: 100px;
            height: 100px;
            box-sizing: border-box;
        }
        .swiper-container .video-wrap {
            border: 1px solid #ccc;
            overflow: hidden;
            cursor: pointer;
        }
        .play-icon-w {
            position: absolute;
            top: 50%;
            transform: translate(-50%, -50%);
            max-width: 100%;
            left: 50%;
            z-index: 1;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: rgba(0, 0, 0, 0.45);
            cursor: pointer;
            border: 1px solid transparent;
        }
        .video-wrap:hover .play-icon-w {
            border: 1px solid rgba(255, 255, 255, 0.6);
        }
        .play-icon {
            width: 15px;
            height: 16px;
            margin-left: 2px;
        }
        @media (max-width: 767px) {
            .swiper-container .cus-img, .swiper-container .video-wrap, .swiper-container .video-wrap video {
                width: 23.5vw;
                height: 23.5vw;
            }
            .play-icon-w {
                width: 8.67vw;
                height: 8.67vw;
            }
            .play-icon {
                width: 3.2vw;
                height: 3.55vw;
                margin-left: 2px;
            }
            .play-icon-w {
                border: 1px solid rgba(255, 255, 255, 0.6);
            }
            .main-slide-photos .swiper-wrapper .swiper-slide {
                width: 23.5vw;
                margin-right: 2.6vw;
            }
            .grade-left .grade {
                margin-right: 10px;
                font-size: 22px;
            }
            .overall-rating {
                display: block;
            }
            .grade-left {
                margin-right: 0;
                flex-direction: row;
                justify-content: center;
                margin-bottom: 12px;
            }
            .grade-left p {
                margin-bottom: 0;
            }
            .star {
                margin-right: 0;
                margin-bottom: 10px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            .customer-photos {
                display: block;
                align-self: flex-start;
            }
        }
    </style>
    <div class="overall-rating">
        <div class="grade-left">
            <p class="grade">4.8</p>
            <div class="rating-box">
                <div class="rating" style="width: 96%;"></div>
            </div>
            <p class="total">3 bewertungen</p>
        </div>
        <div class="star">
            <div class="star-percent">
                <div class="percent-wrap">
                    <div class="percent-con" style="width: 100.0%;"></div>
                </div>
                <div class="stars">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                </div>
            </div>
            <div class="star-percent">
                <div class="percent-wrap">
                    <div class="percent-con" style="width: 0.0%;"></div>
                </div>
                <div class="stars">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                </div>
            </div>
            <div class="star-percent">
                <div class="percent-wrap">
                    <div class="percent-con" style="width: 0.0%;"></div>
                </div>
                <div class="stars">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                </div>
            </div>
            <div class="star-percent">
                <div class="percent-wrap">
                    <div class="percent-con" style="width: 0.0%;"></div>
                </div>
                <div class="stars">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                </div>
            </div>
            <div class="star-percent">
                <div class="percent-wrap">
                    <div class="percent-con" style="width: 0.0%;"></div>
                </div>
                <div class="stars">
                    <img src="/pub/images/star/star1_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                    <img src="/pub/images/star/star2_small.png" alt="">
                </div>
            </div>
        </div>
                <div id="review-image-modal" style="display:none;">
            <img id="review-image-lg" src=""/>
        </div>
    </div>

    

<!-- 1599 详情页评论按钮位置改变  -->
<!-- 1599 详情页评论按钮位置改变  end-->
<div id="product-review-container" data-role="product-review">
        <div class="block review-list" id="customer-reviews">
        <div class="block-title">
            <strong>Kundenbewertungen</strong>
        </div>

        <!-- 1599 详情页评论按钮位置改变  -->
        <div style="display: inline-block;width: 100%;margin-top: 20px;">
            <div class="action primary" style="display: inline-block;float: left">
                <a id="reviews-skip" class="action add" onclick="if (!window.__cfRLUnblockHandlers) return false; reviewLogin()" data-cf-modified-b582c3d0dfb6bd35c494053c-="">
                    <svg style="display: inline-block;margin-right:5px;vertical-align: text-bottom;" width="16" height="16" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12.4801 0.813289C12.5263 0.765534 12.5814 0.727442 12.6424 0.701238C12.7035 0.675033 12.7691 0.66124 12.8355 0.660663C12.9018 0.660087 12.9677 0.672737 13.0291 0.697878C13.0906 0.723018 13.1464 0.760145 13.1933 0.807091C13.2403 0.854038 13.2774 0.909863 13.3026 0.971312C13.3277 1.03276 13.3404 1.0986 13.3398 1.16499C13.3392 1.23138 13.3254 1.29699 13.2992 1.35799C13.273 1.41899 13.2349 1.47417 13.1872 1.52029L6.11665 8.59094C6.02287 8.68472 5.89569 8.7374 5.76307 8.7374C5.63045 8.7374 5.50326 8.68472 5.40948 8.59094C5.31571 8.49717 5.26302 8.36998 5.26302 8.23736C5.26302 8.10474 5.31571 7.97755 5.40948 7.88378L12.4801 0.813445V0.813289ZM12.3336 6.00012C12.3336 5.86751 12.3863 5.74033 12.4801 5.64656C12.5739 5.5528 12.701 5.50012 12.8337 5.50012C12.9663 5.50012 13.0934 5.5528 13.1872 5.64656C13.281 5.74033 13.3337 5.86751 13.3337 6.00012V11.5001C13.3337 12.5126 12.5128 13.3334 11.5003 13.3334H2.50032C1.48782 13.3334 0.666992 12.5126 0.666992 11.5001V2.50012C0.666992 1.48762 1.48783 0.666789 2.50032 0.666789H7.83365C7.96626 0.666789 8.09343 0.719467 8.1872 0.813235C8.28097 0.907003 8.33365 1.03418 8.33365 1.16679C8.33365 1.2994 8.28097 1.42657 8.1872 1.52034C8.09343 1.61411 7.96626 1.66679 7.83365 1.66679H2.50032C2.27931 1.66679 2.06735 1.75459 1.91107 1.91087C1.75478 2.06715 1.66699 2.27911 1.66699 2.50012V11.5001C1.66699 11.7211 1.75478 11.9331 1.91107 12.0894C2.06735 12.2457 2.27931 12.3335 2.50032 12.3335H11.5003C11.7213 12.3335 11.9333 12.2457 12.0896 12.0894C12.2459 11.9331 12.3337 11.7211 12.3337 11.5001V6.00012H12.3336Z" fill="#ffffff"></path>
                    </svg>
                    <span style="color:#f0f0f0;">Bewertung hinzufügen                </span>
                </a>
            </div>
                            <div style="display: inline-block;float: left;height: 34px;line-height: 34px;padding-left: 10px;">
                    Bitte melden Sie sich an, um eine Bewertung hinzuzufügen.                </div>
                    </div>

        
        <!-- 1599 详情页评论按钮位置改变333333  end-->
        <div class="block-content">
            <div class="toolbar review-toolbar">
                            </div>
            <ol class="items review-items">
                                    <li class="item review-item" x-itemscope x-itemprop="review" x-itemtype="http://schema.org/Review">
                        <div class="review-title"
                             x-itemprop="name">Sehr schöner Baum.</div>
                                                    <div class="review-ratings">
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Benutzerfreundlichkeit</span></span>
                                        <div class="rating-result" title="100%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:100%">
                                                <span x-itemprop="ratingValue">100%</span>
                                            </span>
                                        </div>
                                    </div>
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Preis-Leistung</span></span>
                                        <div class="rating-result" title="100%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:100%">
                                                <span x-itemprop="ratingValue">100%</span>
                                            </span>
                                        </div>
                                    </div>
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Qualität &amp; Haltbarkeit</span></span>
                                        <div class="rating-result" title="100%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:100%">
                                                <span x-itemprop="ratingValue">100%</span>
                                            </span>
                                        </div>
                                    </div>
                                                            </div>
                                                <div class="review-content" x-itemprop="description">
                            Mir persönlich gefällt sehr gut. Die eingebaute led-s mit Fernbedienung sehen wunderschön aus. Der Nachteil ist, dass die weißen Flocken anfangs etwas Staub auf Boden hinterlassen da habe ich extra eine weiße Unterlage nachgekauft.                        </div>
                        <div class="review-details">
                            <p class="review-author">
                                <span class="review-details-label">Bewertung durch</span>
                                <strong class="review-details-value"
                                        x-itemprop="author">Tanno</strong>
                            </p>
                            <p class="review-date">
                                <span class="review-details-label">Veröffentlicht am</span>
                                <time class="review-details-value" x-itemprop="datePublished"
                                      datetime=""></time>
                            </p>
                        </div>

                        <div class="review-attachments">
                            <p class="review-attachments-label">Attachments</p>
                            <div class="review-media-value">
                                                            </div>
                            <span class="review_images" style="display: none;">[]</span>
                        </div>
                    </li>
                                    <li class="item review-item" x-itemscope x-itemprop="review" x-itemtype="http://schema.org/Review">
                        <div class="review-title"
                             x-itemprop="name">Sehr schöner Baum mit sehr schöner Beleuchtung. Habe den Kauf nicht bereut.</div>
                                                    <div class="review-ratings">
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Benutzerfreundlichkeit</span></span>
                                        <div class="rating-result" title="100%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:100%">
                                                <span x-itemprop="ratingValue">100%</span>
                                            </span>
                                        </div>
                                    </div>
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Preis-Leistung</span></span>
                                        <div class="rating-result" title="100%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:100%">
                                                <span x-itemprop="ratingValue">100%</span>
                                            </span>
                                        </div>
                                    </div>
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Qualität &amp; Haltbarkeit</span></span>
                                        <div class="rating-result" title="100%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:100%">
                                                <span x-itemprop="ratingValue">100%</span>
                                            </span>
                                        </div>
                                    </div>
                                                            </div>
                                                <div class="review-content" x-itemprop="description">
                            Qualität ist okay, der Baum riecht etwas, lässt aber mit der Zeit nach.                        </div>
                        <div class="review-details">
                            <p class="review-author">
                                <span class="review-details-label">Bewertung durch</span>
                                <strong class="review-details-value"
                                        x-itemprop="author">Sonnenschein</strong>
                            </p>
                            <p class="review-date">
                                <span class="review-details-label">Veröffentlicht am</span>
                                <time class="review-details-value" x-itemprop="datePublished"
                                      datetime=""></time>
                            </p>
                        </div>

                        <div class="review-attachments">
                            <p class="review-attachments-label">Attachments</p>
                            <div class="review-media-value">
                                                            </div>
                            <span class="review_images" style="display: none;">[]</span>
                        </div>
                    </li>
                                    <li class="item review-item" x-itemscope x-itemprop="review" x-itemtype="http://schema.org/Review">
                        <div class="review-title"
                             x-itemprop="name">Schick</div>
                                                    <div class="review-ratings">
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Benutzerfreundlichkeit</span></span>
                                        <div class="rating-result" title="80%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:80%">
                                                <span x-itemprop="ratingValue">80%</span>
                                            </span>
                                        </div>
                                    </div>
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Preis-Leistung</span></span>
                                        <div class="rating-result" title="80%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:80%">
                                                <span x-itemprop="ratingValue">80%</span>
                                            </span>
                                        </div>
                                    </div>
                                                                    <div class="rating-summary item" x-itemprop="reviewRating" x-itemscope
                                         x-itemtype="http://schema.org/Rating">
                                        <span class="label rating-label"><span>Qualität &amp; Haltbarkeit</span></span>
                                        <div class="rating-result" title="100%">
                                            <meta x-itemprop="worstRating" content="1"/>
                                            <meta x-itemprop="bestRating" content="100"/>
                                            <span style="width:100%">
                                                <span x-itemprop="ratingValue">100%</span>
                                            </span>
                                        </div>
                                    </div>
                                                            </div>
                                                <div class="review-content" x-itemprop="description">
                            Bevor er aufgebaut wird, sollte er ordentlich abgeschüttelt werden. Ansonsten schöne schlanke Gestalt und wirkt nicht zu dünn.                        </div>
                        <div class="review-details">
                            <p class="review-author">
                                <span class="review-details-label">Bewertung durch</span>
                                <strong class="review-details-value"
                                        x-itemprop="author">Kati</strong>
                            </p>
                            <p class="review-date">
                                <span class="review-details-label">Veröffentlicht am</span>
                                <time class="review-details-value" x-itemprop="datePublished"
                                      datetime=""></time>
                            </p>
                        </div>

                        <div class="review-attachments">
                            <p class="review-attachments-label">Attachments</p>
                            <div class="review-media-value">
                                                            </div>
                            <span class="review_images" style="display: none;">[]</span>
                        </div>
                    </li>
                            </ol>

            <div id="review-image-modal" style="display:none;">
                <img id="review-image-lg" src=""/>
            </div>
            <div class="mb-hooya-overlay mb-hooya-overlay-review" style="z-index: 10000;"></div>
            <div class="mb-hooya-image-preview mb-hooya-image-preview-review" style="z-index: 10001;">
                <div class="mb-hooya-image-preview__close-icon-wrap">
                    <i role="button" class="mb-hooya-icon mb-hooya-icon-clear mb-hooya-image-preview__close-icon mb-hooya-image-preview__close-icon--top-right"></i>
                </div>
                <div class="swiper-container mb-hooya-swiper-container mb-hooya-swiper-container-review">
                    <div class="swiper-wrapper"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>

            


            <div class="toolbar review-toolbar">
                            </div>
        </div>
    </div>
</div>

<div class="block review-add">
    <div class="block-title"><strong>Schreibe deine eigene Bewertung</strong></div>
    <div class="block-content">
                    <div class="message info notlogged" id="review-form">
                <div>
                    Nur registrierte Benutzer können Bewertungen schreiben. Bitte <a href="https://www.costway.de/customer/account/login/referer/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jYXRhbG9nL3Byb2R1Y3Qvdmlldy9pZC80OTYxLyNyZXZpZXctZm9ybQ%2C%2C/">melden Sie sich an</a> oder <a href="https://www.costway.de/customer/account/create/">erstellen Sie ein Konto</a>                </div>
            </div>
            </div>
</div>






        </div>
                        <div class="data item title" data-role="collapsible" id="tab-label-questions">
            <a class="data switch" data-toggle="trigger" href="#questions"
                id="tab-label-questions-title">
                <h2 style="margin: 0;">FAQs</h2>

            </a>
        </div>
        <div class="data item content" aria-labelledby="tab-label-questions-title"
            id="questions" data-role="content">
            

<style>
        .search-icon {
            margin: auto;
            width: 16px;
            height: 16px;
            border: 0;
            background: url(/pub/images/catalog/icon-search.png) no-repeat center;
            display: block;
        }
        textarea {
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #c2c2c2;
            border-radius: 1px;
            font-size: 14px;
            height: auto;
            line-height: 1.42857143;
            margin: 0;
            padding: 10px;
            vertical-align: baseline;
            width: 100%;
            box-sizing: border-box;
            resize: vertical;
        }
        input[type=text], input[type=password], input[type=url], input[type=tel], input[type=search], input[type=number], input[type*=date], input[type=email] {
            background: #fff;
            background-clip: padding-box;
            border: 1px solid #c2c2c2;
            border-radius: 1px;
            font-size: 14px;
            height: 36px;
            line-height: 1.42857143;
            padding: 0 9px;
            vertical-align: baseline;
            width: 100%;
            box-sizing: border-box;
        }

        .product-faq-contaniner {
            padding: 20px;
        }

        .product-faq-contaniner .faq-action-gorup {
            margin-bottom: 20px;
        }

        .product-faq-contaniner .input-faq-search {
            float: right;
            display: flex;
            height: 40px;
        }

        .product-faq-contaniner .faq-search-btn {
            width: 200px;
            height: 40px;
            font-size: 16px;
            cursor: pointer;
        }

        .product-faq-contaniner #faqsearch {
            width: 293px;
            height: 40px;
            background: #FFFFFF;
            border: 1px solid #CCCCCC;
            border-radius: 4px 0 0 4px;
            padding-left: 14px;
            outline: none;
            border-right: none;
        }

        .product-faq-contaniner input[type=text], .product-faq-contaniner textarea {
            outline: none;
        }

        .product-faq-contaniner .faq-search-icon {
            width: 46px;
            border: none;
            height: 100%;
            border-radius: 0px 4px 4px 0px;
            background: #fdac0e;
            border: 1px solid #fdac0e;
            cursor: pointer;
        }

        .action.primary {
            border: none;
            color: #fff;
            transition: all .2s;
            background: #fdac0e;
            border-radius: 3px;

        }

        .fieldset {
            border: 0;
            margin: 0 0 20px;
            padding: 0;
            /* letter-spacing: -.31em; */
        }
        .product-faq-contaniner .required-icon {
            color: #BE4141;
        }
        .fieldset>.field {
            margin-bottom: 20px;
        }
        .faq-form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;

        }
        .faq-form-actions button {
            width: 100%;
            height: 45px;
            cursor: pointer;
        }
        .faq-form-actions .faq-cancel-btn {
            background: #FFFFFF;
            border: 1px solid #CCCCCC;
            border-radius: 4px;
        }
        .faq-btn-group {
            width: 100%;
            height: 43px;
            line-height: 43px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            margin-right: 10px;
        }
        .faq-list-contaniner {
            margin-top: 20px;
        }
        .faq-list-contaniner .items {
            margin: 0;
            padding: 0;
            list-style: none none;
        }
        .faq-list-contaniner .item {
            padding: 20px 0;
            border-bottom: 1px solid #CCCCCC;
            margin: 0;
        }
        .faq-list-contaniner .item:last-child {
            padding-bottom: 10px;
            border: none;
        }
        .faq-list-contaniner .item .question {
            margin-bottom: 6px;
        }
        .faq-list-contaniner .item .question, .faq-list-contaniner .item .answer {
            display: flex;
        }
        .product-faq-contaniner .faq-ask-contaniner {
            display: none;
        }
        .product-faq-contaniner .seemore-btn {
            line-height: 28px;
            text-decoration-line: underline;
            color: #fdac0e;
            border: none;
            background-color: #fff;
            cursor: pointer;
        }
        .product-faq-contaniner .actions-toolbar > .actions-primary {
            width: 100%;
            margin-right: 0;
        }
        .product-faq-contaniner .actions-toolbar > .actions-primary .action.submit{
            width: 100%;
            font-size: 16px;
        }
        @media screen and (min-width: 767px) {
            .product-faq-contaniner .field{
                max-width: 500px;
            }
            .fieldset>.field input {
                border-radius: 3px;
            }
            .fieldset>.field:not(.choice)>.label {
                float: none;
                display: block;
                text-align: left;
                margin-bottom: 10px;
            }
            .question{
                font-size: 16px;
            }
            .faq-list-contaniner .item .question, .faq-list-contaniner .item .answer {
                line-height: 32px;
            }
        }
        .question{
            font-weight: bold;
        }
        .under_review{
            display: inline-block;
            background: #FFF8E7;
            margin: 0.3125rem auto;
            border-radius: 0.25rem;
            line-height: 1.3125rem;
            padding: 0.5rem 0.75rem;
            color: #ffc842;
            line-height: 20px;
        }

        @media screen and (max-width: 767px) {
            .product-faq-contaniner {
                padding: 0;
            }
            .product-faq-contaniner .faq-action-gorup {
                width: calc(100% - 40px);
                display: flex;
            }
            .product-faq-contaniner .faq-search-btn {
                font-size: 13px;
                width: auto;
                flex-shrink: 0;
                padding-left: 8px;
                padding-right: 8px;
            }
            .product-faq-contaniner .input-faq-search {
                flex: 1;
            }
            .product-faq-contaniner .search-input-wrap {
                width: 100%;
            }
            .product-faq-contaniner #faqsearch {
                margin-left: 6px;
                width: 100%;
            }
        }
        .faq_message {
            margin: 0 0 10px;
            padding: 10px 20px;
            display: block;
            line-height: 1.2em;
            font-size: 1.3rem;
            background: #e5efe5;
            color: #006400;
            padding-left: 40px;
            display: none;
        }
        .searchdel{
            width: 16px;
            height: 16px;
            margin-right: 0px;
            float: right;
            position: absolute;
            z-index: 999;
            right: 5%;
            top: 30%;
            color: grey;
            border: 1px grey solid;
            border-radius: 50%;
            line-height: 100%;
            cursor:pointer;
            display: none;
        }
    </style>
<div class="faq_message"></div>
<div class="product-faq-contaniner">
    <div class="faq-action-gorup">
        <button type="button" class="action submit primary faq-search-btn" onclick="if (!window.__cfRLUnblockHandlers) return false; Askquestion()" data-cf-modified-b582c3d0dfb6bd35c494053c-=""><span>Haben Sie Fragen?</span></button>
        <div class="input-faq-search">
            <div class="control search-input-wrap" style="position: relative">
                <input name="search_where"  type="text" id="faqsearch"  all_count="0"  placeholder="Suchen">
                <div class="searchdel" onclick="if (!window.__cfRLUnblockHandlers) return false; seemorebtn(2)" data-cf-modified-b582c3d0dfb6bd35c494053c-="">
                    <svg width="16" height="16" viewBox="0 0 35 35" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M24.5581 22.4244C25.1473 23.0137 25.1473 23.9689 24.5581 24.5581C23.9689 25.1473 23.0136 25.1473 22.4244 24.5581L17.5001 19.6337L12.5756 24.5581C11.9864 25.1473 11.0312 25.1473 10.442 24.5581C9.85266 23.9689 9.85266 23.0137 10.442 22.4244L15.3663 17.5L10.442 12.5756C9.85266 11.9864 9.85266 11.0311 10.442 10.4419C11.0312 9.8527 11.9864 9.8527 12.5755 10.4419L17.5001 15.3663L22.4244 10.4419C23.0136 9.8527 23.9689 9.8527 24.5581 10.4419C25.1473 11.0311 25.1473 11.9864 24.5581 12.5756L19.6338 17.5L24.5581 22.4244Z" fill="#666666"/>
                    </svg>
                </div>
            </div>
            <span class="input-group-btn">
                    <button class="faq-search-icon btn" title="faqsearch" onclick="if (!window.__cfRLUnblockHandlers) return false; seemorebtn(1)" type="button" data-cf-modified-b582c3d0dfb6bd35c494053c-="">
                        <span><i class="search-icon"></i></span>
                    </button>
                </span>
        </div>
    </div>
    <div class="faq-ask-contaniner">
        <form enctype="" action="" class="faq-form" method="" id="faq-form"
              data-role="product-faq-form" data-bind="scope: 'faq-form'" novalidate="novalidate">
            <input name="form_key" type="hidden" value="VP4V4HFjyivtMHHv" />            <fieldset class="fieldset faq-fieldset">
                <div class="field faq-field-name required">
                    <label for="name_field" class="label"><span>Ihr Name</span></label>
                    <div class="control">
                        <input type="text" name="faq_nickname" id="faq_nickname" maxlength="50" class="input-text" aria-required="true">
                        <p class='faq_msg1' style="color: #E64D43;display: none">Dies ist ein Pflichtfeld!</p>
                    </div>
                </div>
                                <div class="field faq-field-name required">
                    <label for="name_field" class="label"><span>E-Mail</span></label>
                    <div class="control">
                        <input type="text" name="faq_email" id="faq_email" value="" class="input-text" aria-required="true">
                        <p class='faq_msg2' style="color: #E64D43;display: none">Dies ist ein Pflichtfeld!</p>
                    </div>
                </div>

                <div class="field faq-field-question required">
                    <label for="question_field" class="label"><span>Ihre Frage</span></label>
                    <div class="control">
                        <textarea oninput="if (!window.__cfRLUnblockHandlers) return false; numLimit(5000,true)" name="faq_content" id="faq_content" style="resize;width: 99.5%;resize: none;" cols="5" rows="3" data-validate="{required:true}" aria-required="true" maxlength="5000" data-cf-modified-b582c3d0dfb6bd35c494053c-=""></textarea>
                        <span id="DJZYLimit" style="float: right;position: relative;left: -5px;top: -5px;">0/5000</span>
                        <p class='faq_msg3' style="color: #E64D43;display: none">Dies ist ein Pflichtfeld!</p>
                    </div>
                </div>
            </fieldset>
        </form>
        <form enctype="" action=""  method="" id="faq-field-recaptcha-form">
            <div class="field faq-field-recaptcha required">
                <div
    class="field-recaptcha"
    id="recaptcha-8bcc0f8a1913e7cdd90403abe408039d21bd32d6-container"
    data-bind="scope:'recaptcha-8bcc0f8a1913e7cdd90403abe408039d21bd32d6'"
>
    <!-- ko template: getTemplate() --><!-- /ko -->
</div>




            </div>
        </form>
        <div class="field actions-toolbar faq-form-actions">
            <div class="faq-btn-group">
                <div class="faq-cancel-btn" onclick="if (!window.__cfRLUnblockHandlers) return false; cancelAsk()" data-cf-modified-b582c3d0dfb6bd35c494053c-="">Stornieren</div>
            </div>
            <div class="primary actions-primary faq-btn-group">
                <button type="button" onclick="if (!window.__cfRLUnblockHandlers) return false; questionsPost()" class="action submit primary" data-cf-modified-b582c3d0dfb6bd35c494053c-=""><span>Einreichen</span></button>
            </div>
        </div>
    </div>
    <div class="faq-list-contaniner">
        <ol class="items faq-items">
                    </ol>
        <button class="seemore-btn" onclick="if (!window.__cfRLUnblockHandlers) return false; seemorebtn()" style="display: none  " count="5" data-cf-modified-b582c3d0dfb6bd35c494053c-="">Mehr sehen</button>
    </div>
</div>



        </div>
                        <div class="data item title" data-role="collapsible" id="tab-label-instructions_tab">
            <a class="data switch" data-toggle="trigger" href="#instructions_tab"
                id="tab-label-instructions_tab-title">
                <h2 style="margin: 0;">Handbücher</h2>

            </a>
        </div>
        <div class="data item content" aria-labelledby="tab-label-instructions_tab-title"
            id="instructions_tab" data-role="content">
            
    <style>
        .pdf-files {
            display: block;
            color: #ff5f44;
            font-size: 1.6rem;
            margin-bottom: 2.2rem;
        }

        .pdf-files:first-of-type {
            margin-top: 15px;
        }

        .pdf-files .icon-pdf {
            display: inline-block;
            vertical-align: middle;
            margin-right: 8px;
            margin-bottom: 0;
            width: 18px;
            height: 18px;
            background: url("/pub/images/icon-download.png") no-repeat top left;
            background-size: 100% 100%;
        }

        .pdf-files a {
            font-size: 1.6rem;
            text-decoration: underline;
        }

        @media screen and (max-width:750px) {
            .pdf-files {
                display: block;
                margin-top: 4.5333vw;
                font-size: 3.2vw;
                margin-bottom: 4.5333vw;
            }

            .pdf-files .icon-pdf {
                display: inline-block;
                vertical-align: middle;
                width: 3.4666vw;
                height: 4.2666vw;
                background: url("/pub/images/icon-download-m.png") no-repeat top left;
                background-size: 100% 100%;
                margin-right: 2.9333vw;
                margin-bottom: 0;
            }

            .pdf-files a {
                font-size: 3.2vw;
                text-decoration: underline;
            }
        }
    </style>
                        <div class="pdf-files"><a href="javascript:;" id="download-instructions"><span class="icon-pdf"></span>Druckbare Broschüre PDF</a></div>
            
    
        </div>
            </div>
</div>
<style>
@media only screen and (min-width : 768px) {
    .product.data.items>.item.title>.switch {
        background: none !important;
        border: none !important;
        padding: 0 20px 0 !important;
    }

    .product.data.items>.item.title:not(.disabled)>.switch:active,
    .product.data.items>.item.title.active>.switch,
    .product.data.items>.item.title.active>.switch:focus,
    .product.data.items>.item.title.active>.switch:hover {
        background: #fff;
        color: #333;
        font-weight: 700;
        border: none;
        border-bottom: 4px solid #fdac0e !important;
        padding-bottom: 0 !important;
    }

    .product.data.items>.item.content {
        border: none !important;
        border-top: 1px solid #ddd !important;
        padding: 30px 0 !important;
        display: none;
    }

    .product.data.items>.item.content#description {
        display: block;
    }

    .product.media {
        margin-bottom: 70px !important;
    }
}

.product .add-attribute>h4 {
    font-size: 16px !important;
}

.data.item.title a h2 {
    margin: 0;
    line-height: 40px;
    font-size: 16px;
    color: #333333;
}

.data.item.title a h2:hover {
    font-weight: bold;
}

.data.item.title.active a h2 {
    font-weight: bold;
}
</style>

<input name="form_key" type="hidden" value="VP4V4HFjyivtMHHv" /><div id="authenticationPopup" data-bind="scope:'authenticationPopup', style: {display: 'none'}">
            <!-- ko template: getTemplate() --><!-- /ko -->
        
</div>








<div data-mage-init='{"Mirasvit_Feed\/js\/report":[]}'></div>


<style>
    .custom-image-preview-mask {
        position: fixed;
        top: 0;
        inset-inline-end: 0;
        bottom: 0;
        inset-inline-start: 0;
        z-index: 1000;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.45);
        display: none;
    }
    .custom-image-preview-wrap {
        position: fixed;
        top: 0;
        inset-inline-end: 0;
        bottom: 0;
        inset-inline-start: 0;
        overflow: auto;
        outline: 0;
        z-index: 1080;
        display: none;
    }
    .custom-image-preview {
        height: 100%;
        text-align: center;
        display: none;
        /* pointer-events: none; */
    }
    .custom-image-preview-body {
        position: absolute;
        inset: 0;
        overflow: hidden;
    }
    .custom-image-preview-operations-wrapper {
        position: fixed;
        inset-block-start: 0;
        inset-inline-end: 0;
        z-index: 1081;
        width: 100%;
    }
    .custom-image-preview-operations {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        color: rgb(255, 255, 255);
        font-size: 14px;
        line-height: 1.5714285714285714;
        list-style: none;
        font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji';
        display: flex;
        flex-direction: row-reverse;
        align-items: center;
        background: rgba(0, 0, 0, 0.1);
        pointer-events: auto;
    }
    .custom-image-preview-operations-operation {
        margin-inline-start: 12px;
        padding: 12px;
        cursor: pointer;
        transition: all 0.3s;
        user-select: none;
        margin-bottom: 0;
    }
    .custom-image-preview-operations-operation-disabled {
        color: rgba(255, 255, 255, 0.25);
        pointer-events: none;
    }
    .custom-image-preview-operations-icon {
        font-size: 18px;
    }
    .anticon {
        display: inline-flex;
        align-items: center;
        color: inherit;
        font-style: normal;
        line-height: 0;
        text-align: center;
        text-transform: none;
        vertical-align: -0.125em;
        text-rendering: optimizeLegibility;
        -webkit-font-smoothing: antialiased;
    }
    .anticon svg {
        display: inline-block;
    }
    .custom-image-preview-img-wrapper {
        position: absolute;
        inset: 0;
        transition: transform 0.3s cubic-bezier(0.215, 0.61, 0.355, 1) 0s;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .custom-image-preview-img-wrapper::before {
        display: inline-block;
        width: 1px;
        height: 50%;
        margin-inline-end: -1px;
        content: "";
    }
    .custom-image-preview-img-wrapper video {
        height: 75%;
    }
    .custom-image-preview-img {
        max-width: 100%;
        max-height: 600px;
        vertical-align: middle;
        transform: scale3d(1, 1, 1);
        cursor: grab;
        transition: transform 0.3s cubic-bezier(0.215, 0.61, 0.355, 1) 0s;
        user-select: none;
        z-index: 1081;
    }
    .custom-image-preview-switch-left, .custom-image-preview-switch-right {
        position: fixed;
        inset-block-start: 50%;
        z-index: 1081;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        margin-top: -20px;
        color: rgb(255, 255, 255);
        background: rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        transition: all 0.3s;
        pointer-events: auto;
        user-select: none;
    }
    .custom-image-preview-switch-left {
        inset-inline-start: 12px;
    }
    .custom-image-preview-switch-right {
        inset-inline-end: 12px;
    }
    .custom-image-preview-switch-left-disabled {
        color: rgba(255, 255, 255, 0.25);
        background: transparent;
        cursor: not-allowed;
    }
    .custom-image-preview-switch-left >.anticon, .custom-image-preview-switch-right >.anticon {
        font-size: 18px;
    }
    .custom-image-preview-switch-left-disabled >.anticon {
        cursor: not-allowed;
    }
</style>

<div class="custom-image-preview-root css-eq3tly">
    <div class="custom-image-preview-mask"></div>
    <div tabindex="-1" class="custom-image-preview-wrap" role="dialog">
        <div class="custom-image-preview" role="document">
            <div tabindex="0" aria-hidden="true" style="width: 0px; height: 0px; overflow: hidden; outline: none;">
            </div>
            <div class="custom-image-preview-content">
                <div class="custom-image-preview-body">
                    <div class="custom-image-preview-operations-wrapper css-eq3tly">
                        <ul class="custom-image-preview-operations">
                            <li class="custom-image-preview-operations-operation operation-close"><span role="img" aria-label="close"
                                    class="anticon anticon-close custom-image-preview-operations-icon"><svg
                                        focusable="false" class="" data-icon="close" width="1em" height="1em"
                                        fill="currentColor" aria-hidden="true" viewBox="64 64 896 896">
                                        <path
                                            d="M563.8 512l262.5-312.9c4.4-5.2.7-13.1-6.1-13.1h-79.8c-4.7 0-9.2 2.1-12.3 5.7L511.6 449.8 295.1 191.7c-3-3.6-7.5-5.7-12.3-5.7H203c-6.8 0-10.5 7.9-6.1 13.1L459.4 512 196.9 824.9A7.95 7.95 0 00203 838h79.8c4.7 0 9.2-2.1 12.3-5.7l216.5-258.1 216.5 258.1c3 3.6 7.5 5.7 12.3 5.7h79.8c6.8 0 10.5-7.9 6.1-13.1L563.8 512z">
                                        </path>
                                    </svg></span></li>
                            <li class="custom-image-preview-operations-operation operation-zoom-in"><span role="img" aria-label="zoom-in"
                                    class="anticon anticon-zoom-in custom-image-preview-operations-icon"><svg
                                        focusable="false" class="" data-icon="zoom-in" width="1em" height="1em"
                                        fill="currentColor" aria-hidden="true" viewBox="64 64 896 896">
                                        <path
                                            d="M637 443H519V309c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v134H325c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h118v134c0 4.4 3.6 8 8 8h60c4.4 0 8-3.6 8-8V519h118c4.4 0 8-3.6 8-8v-60c0-4.4-3.6-8-8-8zm284 424L775 721c122.1-148.9 113.6-369.5-26-509-148-148.1-388.4-148.1-537 0-148.1 148.6-148.1 389 0 537 139.5 139.6 360.1 148.1 509 26l146 146c3.2 2.8 8.3 2.8 11 0l43-43c2.8-2.7 2.8-7.8 0-11zM696 696c-118.8 118.7-311.2 118.7-430 0-118.7-118.8-118.7-311.2 0-430 118.8-118.7 311.2-118.7 430 0 118.7 118.8 118.7 311.2 0 430z">
                                        </path>
                                    </svg></span></li>
                            <li
                                class="custom-image-preview-operations-operation operation-zoom-out custom-image-preview-operations-operation-disabled">
                                <span role="img" aria-label="zoom-out"
                                    class="anticon anticon-zoom-out custom-image-preview-operations-icon"><svg
                                        focusable="false" class="" data-icon="zoom-out" width="1em" height="1em"
                                        fill="currentColor" aria-hidden="true" viewBox="64 64 896 896">
                                        <path
                                            d="M637 443H325c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h312c4.4 0 8-3.6 8-8v-60c0-4.4-3.6-8-8-8zm284 424L775 721c122.1-148.9 113.6-369.5-26-509-148-148.1-388.4-148.1-537 0-148.1 148.6-148.1 389 0 537 139.5 139.6 360.1 148.1 509 26l146 146c3.2 2.8 8.3 2.8 11 0l43-43c2.8-2.7 2.8-7.8 0-11zM696 696c-118.8 118.7-311.2 118.7-430 0-118.7-118.8-118.7-311.2 0-430 118.8-118.7 311.2-118.7 430 0 118.7 118.8 118.7 311.2 0 430z">
                                        </path>
                                    </svg></span></li>
                            <li class="custom-image-preview-operations-operation operation-rotate-right"><span role="img"
                                    aria-label="rotate-right"
                                    class="anticon anticon-rotate-right custom-image-preview-operations-icon"><svg
                                        focusable="false" class="" data-icon="rotate-right" width="1em" height="1em"
                                        fill="currentColor" aria-hidden="true" viewBox="64 64 896 896">
                                        <defs>
                                            <style></style>
                                        </defs>
                                        <path
                                            d="M480.5 251.2c13-1.6 25.9-2.4 38.8-2.5v63.9c0 6.5 7.5 10.1 12.6 6.1L660 217.6c4-3.2 4-9.2 0-12.3l-128-101c-5.1-4-12.6-.4-12.6 6.1l-.2 64c-118.6.5-235.8 53.4-314.6 154.2A399.75 399.75 0 00123.5 631h74.9c-.9-5.3-1.7-10.7-2.4-16.1-5.1-42.1-2.1-84.1 8.9-124.8 11.4-42.2 31-81.1 58.1-115.8 27.2-34.7 60.3-63.2 98.4-84.3 37-20.6 76.9-33.6 119.1-38.8z">
                                        </path>
                                        <path
                                            d="M880 418H352c-17.7 0-32 14.3-32 32v414c0 17.7 14.3 32 32 32h528c17.7 0 32-14.3 32-32V450c0-17.7-14.3-32-32-32zm-44 402H396V494h440v326z">
                                        </path>
                                    </svg></span></li>
                            <li class="custom-image-preview-operations-operation operation-rotate-left"><span role="img" aria-label="rotate-left"
                                    class="anticon anticon-rotate-left custom-image-preview-operations-icon"><svg
                                        focusable="false" class="" data-icon="rotate-left" width="1em" height="1em"
                                        fill="currentColor" aria-hidden="true" viewBox="64 64 896 896">
                                        <defs>
                                            <style></style>
                                        </defs>
                                        <path
                                            d="M672 418H144c-17.7 0-32 14.3-32 32v414c0 17.7 14.3 32 32 32h528c17.7 0 32-14.3 32-32V450c0-17.7-14.3-32-32-32zm-44 402H188V494h440v326z">
                                        </path>
                                        <path
                                            d="M819.3 328.5c-78.8-100.7-196-153.6-314.6-154.2l-.2-64c0-6.5-7.6-10.1-12.6-6.1l-128 101c-4 3.1-3.9 9.1 0 12.3L492 318.6c5.1 4 12.7.4 12.6-6.1v-63.9c12.9.1 25.9.9 38.8 2.5 42.1 5.2 82.1 18.2 119 38.7 38.1 21.2 71.2 49.7 98.4 84.3 27.1 34.7 46.7 73.7 58.1 115.8a325.95 325.95 0 016.5 140.9h74.9c14.8-103.6-11.3-213-81-302.3z">
                                        </path>
                                    </svg></span></li>
                        </ul>
                    </div>
                    <div class="custom-image-preview-img-wrapper" style="transform: translate3d(0px, 0px, 0px);"></div>
                    <div class="custom-image-preview-switch-left"><span role="img"
                            aria-label="left" class="anticon anticon-left"><svg focusable="false" class=""
                                data-icon="left" width="1em" height="1em" fill="currentColor" aria-hidden="true"
                                viewBox="64 64 896 896">
                                <path
                                    d="M724 218.3V141c0-6.7-7.7-10.4-12.9-6.3L260.3 486.8a31.86 31.86 0 000 50.3l450.8 352.1c5.3 4.1 12.9.4 12.9-6.3v-77.3c0-4.9-2.3-9.6-6.1-12.6l-360-281 360-281.1c3.8-3 6.1-7.7 6.1-12.6z">
                                </path>
                            </svg></span></div>
                    <div class="custom-image-preview-switch-right"><span role="img" aria-label="right"
                            class="anticon anticon-right"><svg focusable="false" class="" data-icon="right" width="1em"
                                height="1em" fill="currentColor" aria-hidden="true" viewBox="64 64 896 896">
                                <path
                                    d="M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z">
                                </path>
                            </svg></span></div>
                </div>
            </div>
            <div tabindex="0" aria-hidden="true" style="width: 0px; height: 0px; overflow: hidden; outline: none;">
            </div>
        </div>
    </div>
</div>


<style>
    .prodetail-coupons-wrapper .coupons-wrap {
        padding: 0 30px;
        margin-bottom: 16px;
    }
    .prodetail-coupons-wrapper .coupons-wrap.coupons-wrap2 {
        border-bottom: 1px solid #f2f2f2;
    }
    .prodetail-coupons-wrapper .coupons-wrap .dis {
        font-weight: 600;
        font-size: 14px;
        text-align: center;
        margin: 20px -10px 5px;
    }
    .prodetail-coupons-wrapper .coupons-wrap .dis .extra {
        font-weight: bold;
    }
    .prodetail-coupons-wrapper .coupons-list, .prodetail-coupons-wrapper .coupons-list a {
        color: #fff;
    }
    .prodetail-coupons-wrapper .coupons-list .coupons-item {
        width: 320px;
        background: url(pub/images/coupon/detail_copon_bg.png) no-repeat top left;
        background-size: 100% auto;
        display: flex;
        padding-left: 9px;
        cursor: pointer;
        height: 104px;
        align-items: center;
        margin-bottom: 0;
    }
    .prodetail-coupons-wrapper .coupons-list .left {
        width: 104px;
        height: 100%;
        flex-shrink: 0;
        text-align: center;
        line-height: 108px;
    }

    .prodetail-coupons-wrapper .coupons-list .left .t-off {
        display: block;
        margin-top: -5px;
    }
    .prodetail-coupons-wrapper .coupons-list .t1 {
        font-size: 18px;
    }
    .prodetail-coupons-wrapper .coupons-list .t2 {
        font-size: 34px;
    }
    .prodetail-coupons-wrapper .coupons-list .t3 {
        color: #222;
        font-weight: 500;
    }
    .prodetail-coupons-wrapper .coupons-list .t4 {
        /* width: 156px;
        height: 30px;
        line-height: 30px;
        background: #FFFFFF;
        box-shadow: 0px 0px 8px rgba(110, 29, 28, 0.35);
        border-radius: 14.5px;
        margin: 8px auto 0;
        color: #E8554F; */
        color: #666666;
        font-size: 12px;
    }
    .prodetail-coupons-wrapper .coupons-list .off {
        font-size: 14px;
    }
    .prodetail-coupons-wrapper .coupons-list .right {
        flex: 1;
        margin-left: 16px;
    }
    .prodetail-coupons-wrapper .coupons-list .left .off-con {
        line-height: 22px;
        
    }
    .prodetail-coupons-wrapper .coupons-list .percent-off {
        line-height: 22px;
        float: right;
        margin-top: 35px;
        text-align: left;
        margin-right: 10px;
        margin-left: -10px;
    }
    .prodetail-coupons-wrapper .coupons-list .percent-off .percent {
        font-size: 16px;
    }
    .prodetail-coupons-wrapper .coupons-wrap .top-t {
        border-bottom: 1px solid #f2f2f2;
        padding: 20px 0;
        margin: 0 -10px;
    }
    .coupon-tips {
        margin-bottom: 15px;
        text-align: center;
    }
    @media screen and (max-width:767px) {
        .prodetail-coupons-wrapper .coupons-list .coupons-item {
            margin: 0 auto;
            height: 80px;
            background: url(/pub/images/coupon/detail_copon_bg.png) no-repeat top center;
            background-size: 100% 100%;
        }
        .prodetail-coupons-wrapper .coupons-wrap .dis {
            margin: 10px -20px 0;
        }
        .prodetail-coupons-wrapper .coupons-wrap .top-t {
            padding: 10px 0;
        }
        .prodetail-coupons-wrapper .title .txt {
            height: 50px !important;
            line-height: 50px !important;
        }
        .prodetail-coupons-wrapper .coupons-wrap {
            margin-bottom: 8px;
        }
        .prodetail-coupons-wrapper .coupons-wrap.coupons-wrap2 {
            padding-bottom: 8px;
        }
        .prodetail-coupons-wrapper .coupons-list .left {
            line-height: 85px;
        }
        .prodetail-coupons-wrapper .coupons-list .t2 {
            font-size: 28px;
        }
        .prodetail-coupons-wrapper .coupons-list .percent-off {
            margin-top: 22px;
        }
        .prodetail-coupons-wrapper ul {
            margin: 0;
        }
        .prodetail-coupons-wrapper .title .close {
            top: 13px;
            right: 15px;
        }
    }
</style>

<div class="sidebar-popup-wrapper prodetail-coupons-wrapper">
    <div class="sidebar-popup-main prodetail-coupons-main">
        <div class="title">
            <div class="txt">Mehr Coupons</div>
            <button type="button" id="pro-coupons-close" class="action close"></button>
        </div>
        <div class="coupons-wrap">
            <p class="dis">Monatliche Deals mit <span class="extra">Extra 10%</span> Rabatt genießen</p>
            <ul class="coupons-list">
                <a href="/mega-woche?entrypoint=sidebar_deal_ads">
                    <li class="coupons-item">
                        <div class="left ">
                            <span class="t2">10</span>
                            <span class="percent-off"><span class="percent">%</span><span class="t-off off">Rabatt</span></span>
                        </div>
                        <div class="right">
                            <div class="t3">für ausgewählte Artikel</div>
                        </div>
                    </li>
                </a>
            </ul>
        </div>
        <p class="coupon-tips">*Normalerweise kann nur ein Coupon auf jede Bestellung angewendet werden.</p>
    </div>
    <div id="cmpbox2" class="cmpboxBG cmpstyleroot"></div>
</div>
<style>
    .sidebar-popup-wrapper .cmpboxBG {
        background-color: rgba(0, 0, 0, .45);
        opacity: 0.5;
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        z-index: 999;
        display: none;
    }

    .sidebar-popup-wrapper ul {
        margin: 0;
        padding: 0;
    }

    .sidebar-popup-wrapper .sidebar-popup-main {
        background-color: #FFFFFF;
        top: 0;
        right: -380px;
        position: fixed;
        z-index: 1000000001;
        height: 100%;
        width: 380px;
        /* overflow-x: scroll; */
    }

    .sidebar-popup-wrapper .title {
        position: relative;
        text-align: center;
    }

    .prodetail-coupons-wrapper .title .txt {
        border-bottom: 1px solid #f2f2f2;
        height: 68px;
        line-height: 68px;
        margin: 0;
        font-weight: 600;
    }

    .sidebar-popup-wrapper .title .close {
        position: absolute;
        top: 15px;
        right: 15px;
        border: 0;
        width: 28px;
        height: 28px;
        text-indent: 0;
        overflow: hidden;
        background: none;
        padding: 0;
        line-height: 28px;
        color: #000;
    }

    .sidebar-popup-wrapper .title .close:before {
        margin-left: -4px;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        font-size: 36px;
        color: inherit;
        content: '\e616';
        font-family: 'icons-blank-theme';
        font-weight: normal;
        overflow: hidden;
        speak: none;
    }

    .attributes-popup-wraper .attributes-top {
        height: 60px;
        border-bottom: 1px solid #f4f4f4;
    }

    .attributes-popup-wraper .product-info {
        display: flex;
        margin-left: 10px;
    }

    .product-info-r {
        margin-left: 10px;
    }

    .attributes-popup-wraper .product-img {
        width: 170px;
        height: 170px;
        flex-shrink: 0;
    }

    .attributes-popup-main .product-attr {
        margin: 0 18px 20px;
    }
    .attributes-popup-main .product-attr .attr-option, .attributes-popup-main .product-attr .attr-item {
        margin-bottom: 10px;
        overflow: hidden;
    }
    .attributes-popup-main .product-info {
        margin: 15px 15px 30px;
    }

    .attributes-popup-main .product-info .title {
        font-size: 18px;
        font-weight: 500;
        overflow: hidden;
        word-wrap: break-word;
        word-break: break-word;
        height: auto;
        text-transform: none !important;
        text-overflow: -o-ellipsis-lastline;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        line-clamp: 3;
        -webkit-box-orient: vertical;
        min-height: auto;
        text-align: left;
    }

    .attributes-popup-main .product-info .price {
        color: #E64D43;
        font-size: 24px;
        font-weight: bold;
        line-height: 36px;
        margin: 1px 0 5px;
    }

    .attributes-popup-main .old-price {
        font-size: 16px;
        text-decoration: line-through !important;
        color: #7A7A7A !important;
        font-weight: 400 !important;
    }

    .attributes-popup-main .product-info .off {
        color: #E64D43;
        font-size: 16px;
        margin-left: 10px;
    }

    .attributes-popup-main .product-info .tag {
        font-size: 20px;
        font-weight: bold;
        line-height: 30px;
        color: #E64D43;
    }

    .attributes-popup-main .product-attr {
        color: #555;
    }

    .attributes-popup-main .product-attr input {
        display: none;
    }

    .attributes-popup-main .attribute-option {
        border: 1.2px solid #ccc;
        border-radius: 4px;
        display: block;
        cursor: pointer;
        margin: 0 10px 10px 0;
        float: left;
    }
    .attributes-popup-main .attribute-option.color-option {
        width: 62px;
        height: 62px;
        padding: 3px;
    }
    .attributes-popup-main .attribute-option.text-option {
        height: 40px;
        line-height: 40px;
        padding: 0 15px;
    }

    .attributes-popup-main .attribute-option.select, .attributes-popup-main .attribute-option:hover {
        border-color: #222;
    }

    .attributes-popup-main .attribute-option.out-of-stock {
        border: 1.2px dashed #ccc;
    }

    .attributes-popup-main .attr-img {
        width: 100%;
        height: 100%;
    }
    .attributes-popup-main .confirm-w {
        height: 80px;
        box-shadow: 0px -2px 11px -2px rgb(0 0 0 / 20%);
        position: absolute;
        bottom: 0;
        width: 100%;
        background-color: #fff;
    }
    .attributes-popup-main .confirm-btn {
        height: 45px;
        border-radius: 50px;
        background: #222222;
        font-size: 18px;
        color: #fff;
        margin: 15px 30px;
        text-align: center;
        line-height: 45px;
        cursor: pointer;
    }
    .attributes-popup-main .attributes-con {
        position: relative;
        height: 100%;
    }
    .product-info-wraper {
        height: calc(100% - 130px);
    }
    @media screen and (max-width:767px) {
        .sidebar-popup-wrapper .sidebar-popup-main {
            width: 100%;
            bottom: -550px;
            right: 0;
            top: auto;
            height: auto;
            border-radius: 8px 8px 0px 0px;
        }
        .sidebar-popup-wrapper .attributes-top .close {
            top: 13px;
            right: 13px;
        }
        .product-info-wraper {
            padding-bottom: 100px;
        }
        .attributes-popup-main .product-info {
            margin: 15px 15px 20px;
        }
        .attributes-popup-wraper .attributes-top {
            height: 50px;
        }
        .attributes-popup-main .product-info .title {
            font-size: 4vw;
        }
        .attributes-popup-main .product-info .price {
            margin: 0;
            display: inline-block;
            font-size: 21px;
            line-height: 30px;
        }
        .attributes-popup-main .initial-price {
            display: inline-block;
            margin-left: 3px;
        }
        .attributes-popup-main .product-info .off {
            margin-left: 8px;
        }
        .attributes-popup-main .product-info .tag {
            line-height: 25px;
            font-size: 16px;
        }
        .attributes-popup-wraper .product-img {
            width: 30vw;
            height: 30vw;
        }
        .product-info-wraper {
            overflow-y: scroll;
        }
    }
</style>

<div class="sidebar-popup-wrapper attributes-popup-wraper">
    <div class="sidebar-popup-main attributes-popup-main">
        <div class="attributes-con">
            <div class="title attributes-top">
                <button type="button" id="pro-coupons-close" class="action close"></button>
            </div>
            <div class="product-info-wraper">
                <div class="product-info">
                </div>
                <div class="product-attr" id="filters-container">
                </div>
            </div>
            <div class="confirm-w">
                <div class="confirm-btn">Bestätigen</div>
            </div>
        </div>
    </div>
    <div id="cmpbox2" class="cmpboxBG cmpstyleroot"></div>
</div>



            
                    <style>
        .amrelated-grid-wrapper {
            margin-top: 40px;
        }
        .amrelated-grid-wrapper > h2 {
            margin: 0;
        }
        .amrelated-grid-wrapper .widget-product-grid {
            position: relative;
            padding: 0;
            z-index: 1;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .block-title {
            margin-bottom: 2vw;
        }
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .block-title strong {
            line-height: 1;
            font-size: 4.266666vw !important;
        }
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .block-content {
            margin: 0 -16px;
            padding: 0;
        }
        }
        .amrelated-grid-wrapper .slick-arrow {
            margin-top: -25px;
            width: 50px;
            height: 50px;
            border-radius: 25px;
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid #CCCCCC;
        }
        .amrelated-grid-wrapper .slick-arrow.slick-prev {
            left: 20px;
        }
        .amrelated-grid-wrapper .slick-arrow.slick-next {
            right: 10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-list {
            padding: 2vw 0 2vw 4.2666vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide {
            flex: 0 0 240px;
            margin: 0;
            display: inline-flex !important;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide {
            flex: none;
            flex-shrink: 0;
            width: 42.666vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide .product-item {
            max-width: none !important;
        }
        @media (min-width: 767px) {
            .amrelated-grid-wrapper .slick-slide .product-item-name {
            max-width: 180px;
            margin-bottom: 10px;
        }
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide .product-item-name {
            font-size: 3.2vw !important;
            margin-bottom: 2.6666vw;
            max-width: 34vw;
        }
        }
        .amrelated-grid-wrapper .slick-slide .product-item-name a {
            line-height: 1.5;
            text-align: left;
        }
        .amrelated-grid-wrapper .slick-slide .product-item-info .product-item-photo a {
            display: block;
            font-size: 0;
        }
        .amrelated-grid-wrapper .slick-slide > div {
            margin: 0 10px 10px;
            background: #FFFFFF;
            box-shadow: 0px 5px 19px rgba(0, 0, 0, 0.08);
            border-radius: 8px;
            padding: 20px 20px 10px;
            width: 100%;
            box-sizing: border-box;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div {
            margin: 0 2.666vw 2.666vw 0;
            border: 1px solid rgba(204, 204, 204, 0.4);
            box-shadow: 1px 1px 1.5vw 2px rgba(102, 102, 102, 0.1);
            padding: 2.666666vw;
            border-radius: 8px;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box {
            text-align: left;
            margin-bottom: 10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box {
            margin-bottom: 1.33333vw;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .price {
            font-weight: normal;
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .normal-price {
            display: inline-block;
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .normal-price {
            margin-bottom: 10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price, .amrelated-grid-wrapper .slick-slide > div .price-box .old-price, .amrelated-grid-wrapper .slick-slide > div .price-box .normal-price {
            margin-bottom: 1.3333vw;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price {
            text-decoration: none;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price, .amrelated-grid-wrapper .slick-slide > div .price-box .old-price {
            padding-left: 0;
            padding-right: 0;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price {
            margin-right: 5px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price {
            margin-right: 1.333vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .special-price .price,
        .amrelated-grid-wrapper .slick-slide > div .price-box .price-final_price .price {
            font-size: 18px !important;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price .price, .amrelated-grid-wrapper .slick-slide > div .price-box .price-final_price .price {
            font-size: 4vw !important;
        }
        }
        @media (max-width: 380px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .special-price .price, .amrelated-grid-wrapper .slick-slide > div .price-box .price-final_price .price {
            font-size: 3.755vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price > span {
            text-decoration: none;
        }
        .amrelated-grid-wrapper .slick-slide > div .price-box .old-price .price {
            font-size: 14px !important;
            text-decoration: line-through;
            color: #999;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .price-box .old-price .price {
            font-size: 3.2vw !important;
        }
        }
        .amrelated-grid-wrapper .slick-slide > div :hover .towishlist {
            position: absolute;
            background: #f9f9f9;
            width: 40px;
            height: 40px;
            text-align: center;
            line-height: 40px;
            border-radius: 50%;
            right: -10px;
            top: -10px;
            z-index: 1;
        }
        .amrelated-grid-wrapper .slick-slide > div :hover .towishlist::before {
            content: "";
            display: inline-block;
            width: 24px;
            height: 24px;
            background-size: 20px 20px;
            background: url(/pub/images/home/towish.png) no-repeat;
            background-position: center;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .slick-slide > div .towishlist {
            position: absolute;
            background: #f9f9f9;
            text-align: center;
            border-radius: 50%;
            z-index: 1;
            width: 35px !important;
            height: 35px !important;
            line-height: 35px !important;
            right: 0 !important;
            top: 0 !important;
        }
        .amrelated-grid-wrapper .slick-slide > div .towishlist::before {
            content: "";
            display: inline-block;
            width: 24px;
            height: 24px;
            background-size: 20px 20px;
            background: url(/pub/images/home/towish.png) no-repeat;
            background-position: center;
        }
        }
        .amrelated-grid-wrapper .slick-slide .product-image-container {
            width: 100% !important;
        }
        .amrelated-grid-wrapper .slick-slide .product-image-wrapper {
            padding-bottom: 100% !important;
        }
        .amrelated-grid-wrapper .slick-slide .product-item-actions > .actions-primary {
            display: none;
        }
        .amrelated-grid-wrapper .slick-slide .product-item-actions .tocompare {
            display: none;
        }
        .amrelated-grid-wrapper .product-item-info .on-sale-tips {
            top: -10px;
            left: -10px;
        }
        @media (max-width: 767px) {
            .amrelated-grid-wrapper .product-item-info .on-sale-tips {
            top: -1vw;
            left: -1vw;
        }
        }
    </style>
    <div class="block widget amrelated-grid-wrapper block-products-list grid"
         id="amrelated-block-3"
    >
                <h2 class="block-title">Das könnte Dir auch gefallen</h2>
                <div class="block-content">
            <div class="products-grid grid">
                <div class="product-items widget-product-grid" data-amrelated-js="slider">
                                                                <div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/trampolin-outdoor-mit-leiter-gartentrampolin-rund-mit-sicherheitsnetz-randabdeckung-metallrahmen-o366cm-orange.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-16958">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/t/r/trampolinoutdoormitleitergartentrampolinrundmitsicherheitsnetzrandabdeckungmetallrahmen366cmorange_1766667643117_image_9.jpg"
            width="240"
            height="300"
            alt="Outdoortrampolin"/></span>
</span>
<style>.product-image-container-16958 {
    width: 240px;
}
.product-image-container-16958 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Trampolin outdoor mit Leiter Gartentrampolin rund mit Sicherheitsnetz Randabdeckung &amp; Metallrahmen Ø366cm Orange"
                                        href="https://www.costway.de/trampolin-outdoor-mit-leiter-gartentrampolin-rund-mit-sicherheitsnetz-randabdeckung-metallrahmen-o366cm-orange.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Trampolin outdoor mit Leiter Gartentrampolin rund mit Sicherheitsnetz Randabdeckung &amp; Metallrahmen Ø366cm Orange                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="16958">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16958"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">299,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16958"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/16958\/","data":{"product":"16958","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":16958,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"16958","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/sonnenschirmstander-60-l-68-kg-befullbar-mit-wasser-oder-sand-schwarz-50-x-50-cm.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-17959">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/s/o/sonnenschirmstnder60l68kgbefllbarmitwasserodersandschwarz50x50cm_1773638957805_image_8.jpg"
            width="240"
            height="300"
            alt="Ampelschirm&#x20;St&#xE4;nder"/></span>
</span>
<style>.product-image-container-17959 {
    width: 240px;
}
.product-image-container-17959 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                            <div class="price-drop-list">
                                    <div class="drop-txt">Flash Sale</div>
                                    <div class="price-drop-con">
                                        <img class="icon-time" title="Endet in" src="/pub/images/decline/icon-time.png">
                                        <span class="end-in">Endet in</span>
                                        <span class="end-days" data-now="2026-05-18 02:03:44" data-time="2026-06-09 00:00:00" from-time="2026-05-13 00:00:00"></span>
                                    </div>
                                </div>
                                                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Sonnenschirmständer 60 L / 68 kg befüllbar mit Wasser oder Sand Schwarz 50 x 50 cm"
                                        href="https://www.costway.de/sonnenschirmstander-60-l-68-kg-befullbar-mit-wasser-oder-sand-schwarz-50-x-50-cm.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Sonnenschirmständer 60 L / 68 kg befüllbar mit Wasser oder Sand Schwarz 50 x 50 cm                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="17959">
    <span class="special-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-17959"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">52,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-17959"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">59,99 €</span></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/17959\/","data":{"product":"17959","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":17959,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"17959","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/270-cm-sonnenschirm-beidseitig-um-30-knickbar-holz-gartenschirm-beige-khaki-tan-blau-weiss-gestreift.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-18724">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/n/p/np12796be-1_1_.jpg"
            width="240"
            height="300"
            alt="Sonnenschirm"/></span>
</span>
<style>.product-image-container-18724 {
    width: 240px;
}
.product-image-container-18724 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="270 cm Sonnenschirm Beidseitig um 30° Knickbar Holz Gartenschirm Beige/Khaki Tan/Blau + Weiß Gestreift"
                                        href="https://www.costway.de/270-cm-sonnenschirm-beidseitig-um-30-knickbar-holz-gartenschirm-beige-khaki-tan-blau-weiss-gestreift.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        270 cm Sonnenschirm Beidseitig um 30° Knickbar Holz Gartenschirm Beige/Khaki Tan/Blau + Weiß Gestreift                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="18724">
    <span class="special-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-18724"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">67,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-18724"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">74,99 €</span></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/18724\/","data":{"product":"18724","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":18724,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"18724","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/balkonmobel-set-gartenmobel-set-2-schaukelstuhlen-mit-tisch-und-kissen-armlehnen-aus-wpc-grau.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-16983">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/9/f/9f9db10a55be43eab2493dbc9949b21f.jpg"
            width="240"
            height="300"
            alt="Drau&#xDF;en&#x20;Garten&#x20;Schaukelstuhl"/></span>
</span>
<style>.product-image-container-16983 {
    width: 240px;
}
.product-image-container-16983 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Balkonmöbel Set Gartenmöbel Set 2 Schaukelstühlen mit Tisch und Kissen Armlehnen aus WPC Grau"
                                        href="https://www.costway.de/balkonmobel-set-gartenmobel-set-2-schaukelstuhlen-mit-tisch-und-kissen-armlehnen-aus-wpc-grau.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Balkonmöbel Set Gartenmöbel Set 2 Schaukelstühlen mit Tisch und Kissen Armlehnen aus WPC Grau                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="16983">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16983"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">102,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16983"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/16983\/","data":{"product":"16983","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":16983,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"16983","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/163-cm-hoher-kletterbaum-moderner-kratzbaum-aus-holz-natur.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-6324">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/1/6/163_cm-hoher-_kletterbaum-pv10071bn-1_1_.jpg"
            width="240"
            height="300"
            alt="163&#x20;cm&#x20;Hoher&#x20;Kletterbaum&#x20;Moderner&#x20;Kratzbaum&#x20;aus&#x20;Holz&#x20;Natur"/></span>
</span>
<style>.product-image-container-6324 {
    width: 240px;
}
.product-image-container-6324 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="163 cm Hoher Kletterbaum Moderner Kratzbaum aus Holz Natur"
                                        href="https://www.costway.de/163-cm-hoher-kletterbaum-moderner-kratzbaum-aus-holz-natur.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        163 cm Hoher Kletterbaum Moderner Kratzbaum aus Holz Natur                                    </a>
                                </h3>
                                                                            <div class="product-reviews-summary short">
                <div class="rating-summary">
            <span class="label"><span>Bewertung:</span></span>
            <div class="rating-result"
                 id="rating-result_6324"
                 title="91%">
                <span style="width: 91%"><span>91%</span></span>
            </div>
                    </div>
                <div class="reviews-actions">
            <a class="action view"
               href="https://www.costway.de/163-cm-hoher-kletterbaum-moderner-kratzbaum-aus-holz-natur.html#reviews">3&nbsp;<span>Bewertungen                </span>
            </a>
        </div>
    </div>
                                                                                                
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="6324">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-6324"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">114,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-6324"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/6324\/","data":{"product":"6324","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":6324,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"6324","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/klappbarer-billardtisch-mit-2-queues-2-kreiden-dreieck-burste-billiard-tisch-mit-zubehorset-blau.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-14555">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/k/l/klappbarerbillardtischmit2queues2kreidendreieckbrstebilliardtischmitzubehrsetblau_1752820607090_image_2.jpg"
            width="240"
            height="300"
            alt="Billardtisch"/></span>
</span>
<style>.product-image-container-14555 {
    width: 240px;
}
.product-image-container-14555 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Klappbarer Billardtisch mit 2 Queues &amp; 2 Kreiden &amp; Dreieck &amp; Bürste Billiard Tisch mit Zubehörset Blau"
                                        href="https://www.costway.de/klappbarer-billardtisch-mit-2-queues-2-kreiden-dreieck-burste-billiard-tisch-mit-zubehorset-blau.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Klappbarer Billardtisch mit 2 Queues &amp; 2 Kreiden &amp; Dreieck &amp; Bürste Billiard Tisch mit Zubehörset Blau                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="14555">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-14555"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">116,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-14555"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/14555\/","data":{"product":"14555","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":14555,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"14555","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/3-teiliges-gartenmobel-set-2-sessel-glastisch-metallrahmen-kissen-fur-balkon-garten-pool-schwarz.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-18381">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/s/e/sessel-0672669347545_1_.jpg"
            width="240"
            height="300"
            alt="3&#x20;teiliges&#x20;Gartenm&#xF6;bel&#x20;Set"/></span>
</span>
<style>.product-image-container-18381 {
    width: 240px;
}
.product-image-container-18381 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                            <div class="price-drop-list">
                                    <div class="drop-txt">Flash Sale</div>
                                    <div class="price-drop-con">
                                        <img class="icon-time" title="Endet in" src="/pub/images/decline/icon-time.png">
                                        <span class="end-in">Endet in</span>
                                        <span class="end-days" data-now="2026-05-18 02:03:44" data-time="2026-06-09 00:00:00" from-time="2026-05-13 00:00:00"></span>
                                    </div>
                                </div>
                                                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Rattan Balkonset inkl. 2 Stühle mit Kissen &amp; Tisch aus Glas Outdoor Sitzgruppe Balkonmöbel Braun-Schwarz"
                                        href="https://www.costway.de/3-teiliges-gartenmobel-set-2-sessel-glastisch-metallrahmen-kissen-fur-balkon-garten-pool-schwarz.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Rattan Balkonset inkl. 2 Stühle mit Kissen &amp; Tisch aus Glas Outdoor Sitzgruppe Balkonmöbel Braun-Schwarz                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="18381">
    <span class="special-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-18381"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">147,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-18381"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">149,99 €</span></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/18381\/","data":{"product":"18381","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":18381,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"18381","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/175cm-katzenbaum-6-stufiger-katzenkratzbaum-holz-kratzbaum-spielhaus-mit-hohle-matten.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-11625">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/k/a/katzenbaum-katzenhaus-32890165-4.jpg"
            width="240"
            height="300"
            alt="kratzbaum"/></span>
</span>
<style>.product-image-container-11625 {
    width: 240px;
}
.product-image-container-11625 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                            <div class="price-drop-list">
                                    <div class="drop-txt">Flash Sale</div>
                                    <div class="price-drop-con">
                                        <img class="icon-time" title="Endet in" src="/pub/images/decline/icon-time.png">
                                        <span class="end-in">Endet in</span>
                                        <span class="end-days" data-now="2026-05-18 02:03:44" data-time="2026-06-09 00:00:00" from-time="2026-05-13 00:00:00"></span>
                                    </div>
                                </div>
                                                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="175cm Katzenbaum 6-stufiger Katzenkratzbaum Holz Kratzbaum Spielhaus mit Höhle &amp; Matten"
                                        href="https://www.costway.de/175cm-katzenbaum-6-stufiger-katzenkratzbaum-holz-kratzbaum-spielhaus-mit-hohle-matten.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        175cm Katzenbaum 6-stufiger Katzenkratzbaum Holz Kratzbaum Spielhaus mit Höhle &amp; Matten                                    </a>
                                </h3>
                                                                            <div class="product-reviews-summary short">
                <div class="rating-summary">
            <span class="label"><span>Bewertung:</span></span>
            <div class="rating-result"
                 id="rating-result_11625"
                 title="100%">
                <span style="width: 100%"><span>100%</span></span>
            </div>
                    </div>
                <div class="reviews-actions">
            <a class="action view"
               href="https://www.costway.de/175cm-katzenbaum-6-stufiger-katzenkratzbaum-holz-kratzbaum-spielhaus-mit-hohle-matten.html#reviews">1&nbsp;<span>Bewertung                </span>
            </a>
        </div>
    </div>
                                                                                                
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="11625">
    <span class="special-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-11625"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">132,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-11625"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">146,99 €</span></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/11625\/","data":{"product":"11625","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":11625,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"11625","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/arztpraxis-spielset-holz-medizinisches-zentrum-mit-tafel-tierwaage-wasserhahn-spule-rosa.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-16903">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/a/r/arztpraxisspielsetholzmedizinischeszentrummittafeltierwaagewasserhahnsplerosa_1766574673536_image_7.jpg"
            width="240"
            height="300"
            alt="Holz&#x20;Arzteset"/></span>
</span>
<style>.product-image-container-16903 {
    width: 240px;
}
.product-image-container-16903 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Arztpraxis-Spielset Holz-Medizinisches Zentrum mit Tafel Tierwaage Wasserhahn Spüle Rosa"
                                        href="https://www.costway.de/arztpraxis-spielset-holz-medizinisches-zentrum-mit-tafel-tierwaage-wasserhahn-spule-rosa.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Arztpraxis-Spielset Holz-Medizinisches Zentrum mit Tafel Tierwaage Wasserhahn Spüle Rosa                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="16903">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16903"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">79,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16903"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/16903\/","data":{"product":"16903","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":16903,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"16903","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/runder-sonnenschirm-mit-fransen-terrassenschirm-mit-einstellbarem-winkel-stabiler-metallstange.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-19097">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/r/u/rundersonnenschirmmitfransenterrassenschirmmiteinstellbaremwinkelstabilermetallstange_1778555872938_image_1.jpg"
            width="240"
            height="300"
            alt="Runder&#x20;Sonnenschirm&#x20;mit&#x20;Fransen&#x20;Terrassenschirm&#x20;mit&#x20;Einstellbarem&#x20;Winkel&#x20;Stabiler&#x20;Metallstange"/></span>
</span>
<style>.product-image-container-19097 {
    width: 240px;
}
.product-image-container-19097 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                            <span class="on-sale-tips new">Neu</span>
                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Runder Sonnenschirm mit Fransen Terrassenschirm mit Einstellbarem Winkel Stabiler Metallstange"
                                        href="https://www.costway.de/runder-sonnenschirm-mit-fransen-terrassenschirm-mit-einstellbarem-winkel-stabiler-metallstange.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Runder Sonnenschirm mit Fransen Terrassenschirm mit Einstellbarem Winkel Stabiler Metallstange                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="19097">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-19097"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">37,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-19097"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/19097\/","data":{"product":"19097","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":19097,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"19097","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/kinderkuche-mit-54-zubehor-spielkuche-puppenkuche-spielzeugkuche-fur-kinder-ab-3-jahren-blau.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-15771">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/k/i/kinderkchemit95zubehrspielkchepuppenkchespielzeugkchefrkinderab3jahrenblau_1761026470746_image_2.jpg"
            width="240"
            height="300"
            alt="kinder&#x20;k&#xFC;chen&#x20;spielset"/></span>
</span>
<style>.product-image-container-15771 {
    width: 240px;
}
.product-image-container-15771 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Kinderküche mit 54 Zubehör Spielküche Puppenküche  Spielzeugküche für Kinder ab 3 Jahren Blau"
                                        href="https://www.costway.de/kinderkuche-mit-54-zubehor-spielkuche-puppenkuche-spielzeugkuche-fur-kinder-ab-3-jahren-blau.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Kinderküche mit 54 Zubehör Spielküche Puppenküche  Spielzeugküche für Kinder ab 3 Jahren Blau                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="15771">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-15771"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">36,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-15771"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/15771\/","data":{"product":"15771","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":15771,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"15771","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/3-teiliges-bistro-set-geflochtenes-seil-mit-kissen-fur-balkon-terrasse-garten-beige.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-18292">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/3/t/3teiligesbistrosetgeflochtenesseilmitkissenfrbalkonterrassegartenbeige_1774491071886_image_2.jpg"
            width="240"
            height="300"
            alt="Terrassenset&#x20;"/></span>
</span>
<style>.product-image-container-18292 {
    width: 240px;
}
.product-image-container-18292 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                            <div class="price-drop-list">
                                    <div class="drop-txt">Flash Sale</div>
                                    <div class="price-drop-con">
                                        <img class="icon-time" title="Endet in" src="/pub/images/decline/icon-time.png">
                                        <span class="end-in">Endet in</span>
                                        <span class="end-days" data-now="2026-05-18 02:03:44" data-time="2026-06-09 00:00:00" from-time="2026-05-13 00:00:00"></span>
                                    </div>
                                </div>
                                                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="3 Teiliges Bistro Set Geflochtenes Seil mit Kissen für Balkon Terrasse Garten Beige"
                                        href="https://www.costway.de/3-teiliges-bistro-set-geflochtenes-seil-mit-kissen-fur-balkon-terrasse-garten-beige.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        3 Teiliges Bistro Set Geflochtenes Seil mit Kissen für Balkon Terrasse Garten Beige                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="18292">
    <span class="special-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-18292"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">215,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-18292"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">219,99 €</span></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/18292\/","data":{"product":"18292","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":18292,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"18292","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/2er-pflanzkubel-pflanzgefasse-mit-entwasserungslochern-dekorative-blumentopfe-ubertopf-grau.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-14155">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/9/7/97152086_5_.jpg"
            width="240"
            height="300"
            alt="pflanzgef&#xE4;&#xDF;e"/></span>
</span>
<style>.product-image-container-14155 {
    width: 240px;
}
.product-image-container-14155 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="2er Pflanzkübel Pflanzgefäße mit Entwässerungslöchern Dekorative Blumentöpfe Grau"
                                        href="https://www.costway.de/2er-pflanzkubel-pflanzgefasse-mit-entwasserungslochern-dekorative-blumentopfe-ubertopf-grau.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        2er Pflanzkübel Pflanzgefäße mit Entwässerungslöchern Dekorative Blumentöpfe Grau                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="14155">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-14155"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">41,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-14155"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/14155\/","data":{"product":"14155","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":14155,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"14155","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/180-cm-kunstlicher-weihnachtsbaum-mit-schnee-250-warmweissen-led-lichtern-grun.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-7727">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/t/a/tannenbaum-cm24319de_1_.jpg"
            width="240"
            height="300"
            alt="Weihnachtsbaum&#x20;mit&#x20;LED&#x20;Lichtern"/></span>
</span>
<style>.product-image-container-7727 {
    width: 240px;
}
.product-image-container-7727 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="180 cm Künstlicher Weihnachtsbaum mit Schnee &amp; 250 Warmweißen LED-Lichtern Grün"
                                        href="https://www.costway.de/180-cm-kunstlicher-weihnachtsbaum-mit-schnee-250-warmweissen-led-lichtern-grun.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        180 cm Künstlicher Weihnachtsbaum mit Schnee &amp; 250 Warmweißen LED-Lichtern Grün                                    </a>
                                </h3>
                                                                            <div class="product-reviews-summary short">
                <div class="rating-summary">
            <span class="label"><span>Bewertung:</span></span>
            <div class="rating-result"
                 id="rating-result_7727"
                 title="100%">
                <span style="width: 100%"><span>100%</span></span>
            </div>
                    </div>
                <div class="reviews-actions">
            <a class="action view"
               href="https://www.costway.de/180-cm-kunstlicher-weihnachtsbaum-mit-schnee-250-warmweissen-led-lichtern-grun.html#reviews">3&nbsp;<span>Bewertungen                </span>
            </a>
        </div>
    </div>
                                                                                                
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="7727">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-7727"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">124,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-7727"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/7727\/","data":{"product":"7727","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":7727,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"7727","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/schminktisch-mit-led-beleuchtung-3-farben-mit-einstellbarer-helligkeit-frisiertisch-weiss.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-12624">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/s/c/schminktisch-kosmetiktisch-12658_5_.jpg"
            width="240"
            height="300"
            alt="schminktisch&#x20;mit&#x20;spiegel&#x20;und&#x20;beleuchtung"/></span>
</span>
<style>.product-image-container-12624 {
    width: 240px;
}
.product-image-container-12624 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Schminktisch mit LED-Beleuchtung 3 Farben mit Einstellbarer Helligkeit Frisiertisch Weiß"
                                        href="https://www.costway.de/schminktisch-mit-led-beleuchtung-3-farben-mit-einstellbarer-helligkeit-frisiertisch-weiss.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Schminktisch mit LED-Beleuchtung 3 Farben mit Einstellbarer Helligkeit Frisiertisch Weiß                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="12624">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-12624"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">164,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-12624"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/12624\/","data":{"product":"12624","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":12624,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"12624","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/32-tonen-xylophon-glockenspiel-mit-verstellbarem-stander-schlageln-und-tragetasche.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-8342">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/p/e/percussion-schlaginstrument-alu-mu10064_8_.jpg"
            width="240"
            height="300"
            alt="xylophon"/></span>
</span>
<style>.product-image-container-8342 {
    width: 240px;
}
.product-image-container-8342 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="32 Tönen Xylophon Glockenspiel mit Verstellbarem Ständer &amp; Schlägeln und Tragetasche Alu"
                                        href="https://www.costway.de/32-tonen-xylophon-glockenspiel-mit-verstellbarem-stander-schlageln-und-tragetasche.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        32 Tönen Xylophon Glockenspiel mit Verstellbarem Ständer &amp; Schlägeln und Tragetasche Alu                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="8342">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-8342"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">99,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-8342"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/8342\/","data":{"product":"8342","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":8342,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"8342","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/grosser-baby-laufstall-sicherer-spielbereich-mit-basketballkorb-fussballnetzen-greifringen-dunkelgrau.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-16753">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/b/b/bb6428gr-1_1_.jpg"
            width="240"
            height="300"
            alt="Faltbarer&#x20;Baby&#x20;Laufstall"/></span>
</span>
<style>.product-image-container-16753 {
    width: 240px;
}
.product-image-container-16753 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                            <span class="on-sale-tips bestseller">Bestseller</span>
                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Großer Baby-Laufstall sicherer Spielbereich mit Basketballkorb &amp; Fußballnetzen Greifringen Dunkelgrau"
                                        href="https://www.costway.de/grosser-baby-laufstall-sicherer-spielbereich-mit-basketballkorb-fussballnetzen-greifringen-dunkelgrau.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Großer Baby-Laufstall sicherer Spielbereich mit Basketballkorb &amp; Fußballnetzen Greifringen Dunkelgrau                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="16753">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16753"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">99,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-16753"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/16753\/","data":{"product":"16753","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":16753,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"16753","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/gepolsterter-kindersofa-schaukelstuhl-mit-massivholzbeinen-kindersessel-rosa.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-7275">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/k/i/kinderstuhl-hy10172pi_8_.jpg"
            width="240"
            height="300"
            alt="kindersofa"/></span>
</span>
<style>.product-image-container-7275 {
    width: 240px;
}
.product-image-container-7275 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Kinder Gepolsterter Schaukelstuhl mit Massivholzbeinen Rosa"
                                        href="https://www.costway.de/gepolsterter-kindersofa-schaukelstuhl-mit-massivholzbeinen-kindersessel-rosa.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Kinder Gepolsterter Schaukelstuhl mit Massivholzbeinen Rosa                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="7275">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-7275"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">78,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-7275"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/7275\/","data":{"product":"7275","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":7275,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"7275","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/kinder-spielkuche-mit-komplettem-zubehor-puppenkuhe-mit-uhr-herd-gewurzregal-grau.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-17139">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/k/i/kinderspielkchemitkomplettemzubehrpuppenkhemituhrherdgewrzregalgrau_1767767849559_image_2.jpg"
            width="240"
            height="300"
            alt="Holz&#x20;Kinder&#x20;Spielk&#xFC;che&#x20;Set"/></span>
</span>
<style>.product-image-container-17139 {
    width: 240px;
}
.product-image-container-17139 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                                                    </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Kinder Spielküche mit Komplettem Zubehör Puppenkühe mit Uhr &amp; Herd &amp; Gewürzregal Grau"
                                        href="https://www.costway.de/kinder-spielkuche-mit-komplettem-zubehor-puppenkuhe-mit-uhr-herd-gewurzregal-grau.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Kinder Spielküche mit Komplettem Zubehör Puppenkühe mit Uhr &amp; Herd &amp; Gewürzregal Grau                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="17139">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-17139"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">62,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-17139"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/17139\/","data":{"product":"17139","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":17139,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"17139","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        
                                            </div><div class="product-item">

                        <div class="product-item-info">
                            <a href="https://www.costway.de/kinder-schaukelboot-mit-nautischem-design-drehbarem-propeller-birkenholz-griffe-schaukelpferd.html?entrypoint=youmightlike" class="product-item-photo">
                                <span class="product-image-container product-image-container-17788">
    <span class="product-image-wrapper">
        <img class="product-image-photo lazy"
                        src="/pub/images/default-min.jpg" data-original="https://www.costway.de/media/catalog/product/cache/24d45724953bea38e9b8dc92630844fd/k/i/kinderschaukelbootmitnautischemdesigndrehbarempropellerbirkenholzgriffeschaukelpferd_1772515606352_image_2.jpg"
            width="240"
            height="300"
            alt="Schaukelpferd"/></span>
</span>
<style>.product-image-container-17788 {
    width: 240px;
}
.product-image-container-17788 span.product-image-wrapper {
    padding-bottom: 100%;
}</style>                                                            <span class="on-sale-tips bestseller">Bestseller</span>
                                                        </a>
                            <div class="product-item-details">
                                <h3 class="product-item-name">
                                    <a title="Kinder Schaukelboot mit Nautischem Design &amp; Drehbarem Propeller &amp; Birkenholz-Griffe Schaukelpferd"
                                        href="https://www.costway.de/kinder-schaukelboot-mit-nautischem-design-drehbarem-propeller-birkenholz-griffe-schaukelpferd.html?entrypoint=youmightlike"
                                        class="product-item-link">
                                        Kinder Schaukelboot mit Nautischem Design &amp; Drehbarem Propeller &amp; Birkenholz-Griffe Schaukelpferd                                    </a>
                                </h3>
                                                                                                                                                                    
<div class="price-box range second price-final_price" data-role="priceBox" data-product-id="17788">
    <span class="normal-price">
        <span class="price-container price-final_price">
                            <span class="price-label">special price</span>
                        <span  id="product-price-17788"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"><span class="price">53,99 €</span></span>
            </span>
        </span>
    </span>
    <span class="old-price">
        <span class="price-container price-final_price tax weee">
                            <span class="price-label">special price</span>
                        <span  id="product-price-17788"                data-price-amount=""
                data-price-type="finalPrice1"
                class="price-wrapper">
                <span class="price"></span>
            </span>
        </span>
    </span>
</div>
                                                                                                    <div class="product-item-actions">
                                                                                    <div class="actions-primary">
                                                                                                                                                        <button class="action tocart primary" data-post='{"action":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/product\/17788\/","data":{"product":"17788","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}' type="button" title="In den Warenkorb">
                                                        <span>In den Warenkorb</span>
                                                    </button>
                                                                                            </div>
                                                                                                                            <div class="actions-secondary" data-role="add-to-links">
                                                                                                    <a href="#"
                                                       data-post='{"action":"https:\/\/www.costway.de\/wishlist\/index\/add\/","data":{"product":17788,"uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       class="action towishlist"
                                                       data-action="add-to-wishlist"
                                                       title="Zur Wunschliste hinzufügen">
                                                        <span>Zur Wunschliste hinzufügen</span>
                                                    </a>
                                                                                                                                                                                                        <a href="#" class="action tocompare"
                                                       data-post='{"action":"https:\/\/www.costway.de\/catalog\/product_compare\/add\/","data":{"product":"17788","uenc":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"}}'
                                                       title="Zum vergleichen hinzufügen">
                                                        <span>Zum vergleichen hinzufügen</span>
                                                    </a>
                                                                                            </div>
                                                                            </div>
                                                            </div>
                        </div>

                        </div>
                                    </div>
            </div>
        </div>
    </div>
            
    
</div></div></main><div class="footer-top"><style>
    
.newsletter_v2 {
  clear: both;
  width: 100%;
  background-color: #F9F9F9;
  padding: 35px 0;
}
@media only screen and (max-width: 767px) {
  .newsletter_v2 {
    padding: 5.3vw 0 6vw;
    box-sizing: border-box;
  }
}
.newsletter_v2::after {
  content: '';
  clear: both;
  display: block;
  width: 100%;
}
.newsletter_v2 .news-block-title {
  width: 100%;
  font-size: 22px;
  font-weight: bold;
  line-height: 1;
  margin-bottom: 20px;
  max-width: 49%;
  float: left;
  margin: 0;
}
@media only screen and (max-width: 767px) {
  .newsletter_v2 .news-block-title {
    max-width: none;
  }
}
.newsletter_v2 .news-block-title .coupons-newsletter-tile {
  margin: 0;
  font-size: 22px;
  line-height: 1.5;
  font-weight: 600;
}
@media only screen and (max-width: 767px) {
  .newsletter_v2 .news-block-title .coupons-newsletter-tile {
    font-size: 3.8vw;
    font-weight: 700;
  }
  .newsletter_v2 .news-block-title .coupons-newsletter-tile > span {
    display: inline;
  }
}
.newsletter_v2 .news-block-title .coupons-newsletter-tile::after {
  content: '';
  display: block;
  clear: both;
}
.newsletter_v2 .news-block-title b {
  font-size: 24px;
}
.newsletter_v2 .news-block-title b span {
  font-size: 22px;
}
.newsletter_v2 .coupons-newsletter-tips {
  clear: both;
  float: left;
  width: 51%;
  font-size: 14px;
  line-height: 20px;
  margin-top: 15px;
  margin-bottom: 6px;
}
.newsletter_v2 .coupons-newsletter-tips a {
  color: #FDAC0E;
  text-decoration: underline !important;
}
.newsletter_v2 .coupons-newsletter-tips.coupons-register-tips {
  margin-top: 0;
  margin-bottom:0;
}
.newsletter_v2 .coupons-newsletter-tips.coupons-register-tips .black {
  color: #333;
}
.newsletter_v2 .coupons-newsletter-tips.coupons-register-tips .black:hover {
  color: #FDAC0E;
}
@media only screen and (max-width: 767px) {
  .newsletter_v2 .coupons-newsletter-tips {
    width: 100%;
    font-size: 13px;
    margin-top: 2.333vw;
  }
  .newsletter_v2 .coupons-newsletter-tips br {
    display: none;
  }
  .newsletter_v2 .news-block-title b {
    font-size: 4.267vw;
  }
}
@media only screen and (min-width: 768px) {
  .newsletter_v2 .form {
    float: right;
    width: 30%;
    min-width: 348px;
    margin-top: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .newsletter_v2 .form {
    float: right;
    width: 100%;
    min-width: auto;
    margin-top: 4.3vw;
  }
}
.newsletter_v2 .form input {
  height: 50px;
  /* background: #FFFFFF;
  border: 1px solid #CCCCCC;
  border-radius: 8px 0px 0px 8px; */
  background: #FFFFFF;
  border: none;
  font-size: 14px;
  color: #222;
  padding: 0 16px;
  height: 50px;
  box-shadow: none;
  border-color: #000000 !important;
  border-radius: 4px;
}
.newsletter_v2 .form button {
  height: 50px;
  background: #000000 !important;
  width: 72px;
  color: #fff;
}
.subscribe-placehoder {
  display: none;
  font-size: 12px;
  font-weight: 500;
  color: #666;
  padding: 4px 16px 0;
  margin-bottom: 0;
}
.subscribe-placehoder.error {
  color: #E64D43;
}
.newsletter_v2 .control {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
  transition: all .3s;
  border-radius: 4px;
  height: 50px;
  background: #fff;
  border-radius: 4px 0 0 4px;
  border: 1px solid #2a2629;
  border-right: none;
  transition: all .3s;
}
.newsletter_v2 .control.error {
  border-color: #E64D43;
}
.newsletter_v2 .newsletter-input #newsletter-error {
  display: none !important;
}
.newsletter_v2 .subscribe-close {
  display: none;
  position: absolute;
  top: 0;
  right: 18px;
  bottom: 0;
  margin: auto 0;
  width: 16px;
  height: 12px;
  cursor: pointer;
  filter: brightness(45%);
  background: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTEgMWwxMCAxMG0wLTEwTDEgMTEiIHN0cm9rZT0iI0IyQjJCMiIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==) no-repeat center;
}
.newsletter-errortips {
  margin-top: 6px;
  color: #E64D43;
}
.subscribe-messages {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100px;
  margin: 0 auto;
}
.subscribe-messages p {
  margin: 0 0 0 10px;
  font-size: 16px;
}
@media only screen and (max-width: 767px) {
  .newsletter_v2 .form input, .newsletter_v2 .form button {
    height: 44px;
  }
  .newsletter_v2 .control {
    height: 44px;
  }
  .newsletter-errortips {
    width: auto;
  }
  .subscribe-messages {
    width: 90%;
  }
  .subscribe-messages p {
    font-size: 14px;
  }
}
</style>

       
        <div class="newsletter_v2">
            <div class="cus-container">
                <div class="page-main">
                    <div class="newsletter-block">
                       
                            <div class="news-block-title">
                              <p class="coupons-newsletter-tile">Melden Sie sich für unseren Newsletter an <span>und erhalten Sie sofort <b>160 €</b>-Gutschein-Paket.</span></p>
                            </div>
                            <form class="form subscribe" novalidate method="post" data-mage-init='{"validation": {"errorClass": "mage-error"}}' id="newsletter-validate-detail">
                                <div class="block-content">
                                    <div class="newsletter-input">
                                        <div class="input-group">
                                            <div class="control">
                                              <i class="subscribe-close"></i>
                                              <p class="subscribe-placehoder">E-Mail</p>
                                                <input name="email" type="email" id="newsletter"
                                                       placeholder="E-Mail"
                                                       data-validate="{required:true, 'validate-email':true}"/>
                                            </div>
                                            <span class="input-group-btn">
                                                <button class="subscribe btn" title="Abonnieren" type="submit">
                                                <span><svg width="21" height="18" viewBox="0 0 21 18" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M10.7949 18L8.6275 16.0628L15.2201 10.3318H0V7.58744H15.2201L8.6275 1.8565L10.7949 0L21 8.95964L10.7949 18Z"
                                                                fill="white" />
                                                        </svg>
                                                    </span>
                                                </button>
                                            </span>
                                        </div>
                                        <p class="newsletter-errortips"></p>
                                    </div>
                                </div>
                            </form>

                            <p class="coupons-newsletter-tips"><a href="/subscribe-newsletter">Erfahren mehr</a> über besondere Angebote, Events, Neue Kollektionen und vieles mehr. Entdecken Sie die exklusiven Vorteile eines Abonnements jetzt!</p>
                            <p class="coupons-newsletter-tips coupons-register-tips">
                              *Mit der Anmeldung akzeptieren Sie unsere <a href="/agb" class="black">AGB</a> und <a href="/sicherheit-datenschutz" class="black">Datenschutzerklärung</a>.                    
    </p> 
                    </div>
                </div>
            </div>
        </div>


        
    


<style>
  #maincontent {
    background-color: transparent;
  }

  .footer-container {
    background: #fff;
  }

  .footer-container .footer-container-top {
    margin: 50px auto 0;
    display: flex;
    justify-content: space-between;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top {
      width: 100%;
      display: block;
      margin: 0 auto;
    }
  }

  .footer-container .footer-container-top .bottom-logo {
    width: 32%;
    padding-right: 11%;
    box-sizing: border-box;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .bottom-logo {
      width: 100%;
      padding-right: 0;
      margin-top: 10px;
    }
  }

  .footer-container .footer-container-top .bottom-logo a {
    display: block;
    font-size: 0;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .bottom-logo a {
      text-align: center;
    }
  }

  .footer-container .footer-container-top .bottom-logo svg {
    width: 120px;
    margin-top: -5px;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .bottom-logo svg {
      margin: 0 auto;
    }

    .footer-container .footer-container-top .bottom-logo p {
      text-align: center;
    }
  }

  .footer-container .footer-container-top .bottom-logo p {
    font-size: 12px;
    color: #5E5B5B;
    font-weight: 400;
    line-height: 1.5;
  }

  .footer-container .footer-container-top .bottom-logo .footer-slogan {
    margin-top: 10px;
    color: #1F1F1F;
    font-size: 16px;
    line-height: 1;
    font-weight: 500;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .bottom-logo .footer-slogan {
      text-align: center;
    }
  }

  .footer-container .footer-container-top .svg-footer-logo {
    width: 142px;
    height: 62px;
  }

  .footer-container .footer-container-top .footer-menu {
    width: 68%;
    display: flex;
    justify-content: space-betweens;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .footer-menu {
      display: block;
      width: 100%;
      margin-top: 0;
    }
  }

  .footer-container .footer-container-top .footer-menu dl {
    width: 25%;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .footer-menu dl {
      width: 100%;
      margin-bottom: 0;
    }
  }

  .footer-container .footer-container-top .footer-menu dt {
    font-size: 20px;
    color: #000;
    font-weight: 600;
    margin-bottom: 18px;
    line-height: 2;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .footer-menu dt {
      border-bottom: 1px solid #ccc;
      font-size: 16px;
      font-weight: normal;
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 0;
      height: 12vw;
    }

    .footer-container .footer-container-top .footer-menu dt::after {
      content: '';
      float: right;
      display: inline;
      width: 14px;
      height: 10px;
      background: url(/pub/images/footer/scale_icon.png) no-repeat;
      background-size: 100% auto !important;
    }
  }

  .footer-container .footer-container-top .footer-menu dd {
    line-height: 1.35;
    font-size: 14px;
    color: #0e0e0e;
    margin-bottom: 18px;
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .footer-menu dd {
      display: none;
      margin: 16px 0;
    }
  }

  .footer-container .footer-container-top .footer-menu dd a {
    transition: all 0.25s ease;
    -webkit-transition: all 0.25s ease;
    -moz-transition: all 0.25s ease;
    -o-transition: all 0.25s ease;
    color: #0e0e0e;
    display: inline-block;
    align-items: center;
    text-decoration: none;
  }

  .footer-container .footer-container-top .footer-menu dd a:before {
    content: "->";
    position: absolute;
    opacity: 0;
    display: block;
    -webkit-transform: translateX(-18px);
    -moz-transform: translateX(-18px);
    -o-transform: translateX(-18px);
    transform: translateX(-18px);
    transition: all 0.25s ease;
    -webkit-transition: all 0.25s ease;
    -moz-transition: all 0.25s ease;
    -o-transition: all 0.25s ease;
  }

  .footer-container .footer-container-top .footer-menu dd a:hover {
    padding-left: 25px;
    color: #FF5F44;
  }

  .footer-container .footer-container-top .footer-menu dd a:hover:before {
    opacity: 1;
    transform: translateX(-18px);
    -webkit-transform: translateX(-18px);
    -moz-transform: translateX(-18px);
    -o-transform: translateX(-18px);
  }

  @media (max-width: 980px) {
    .footer-container .footer-container-top .footer-menu dl.show dt::after {
      background: url(/pub/images/footer/scale_icon2.png) no-repeat;
    }
  }

  .footer-container .footer-container-top .footer-menu dl.show dd {
    display: block;
  }

  .footer-container .footer-bottom {
    margin-top: 25px;
    margin-bottom: 30px;
    display: flex;
    align-items: flex-end;
  }
  @media (min-width: 768px) {
    .share-sitajabber .trustpilot-widget {
      margin-left: -55px;
    }
    .footer-container .footer-bottom .share-sitajabber {
      width: 32%;
      display: flex;
      flex-wrap: wrap;
    }
    .footer-container .footer-bottom .share-sitajabber dl.follow-us dd {
      float: left;
    }
  }
  @media (min-width: 1000px) {
    .footer-container .footer-bottom .payment{
      margin-right: 5%;
    }
    .footer-bottom .contact-us .addrss {
      min-width: 364px;
    }
  }
  @media (max-width: 980px) {
    .footer-container .footer-bottom {
      display: block;
      width: 100%;
      margin: 30px 0;
    }
  }

  @media (max-width: 980px) {

    .footer-container .footer-bottom .contact-us,
    .footer-container .footer-bottom .payment,
    .footer-container .footer-bottom .share-sitajabber {
      margin-top: 15px;
    }
    .footer-bottom .share-sitajabber {
      margin-bottom: 20px;
      text-align: center;
    }
    .footer-container .footer-bottom .contact-us::after,
    .footer-container .footer-bottom .payment::after,
    .footer-container .footer-bottom .share-sitajabber::after {
      content: '';
      display: block;
      clear: both;
    }
    .footer-container .footer-bottom .payment .payment-list dt {
      margin-bottom: 0;
    }
  }

  .footer-container .footer-bottom .contact-us .address {
    max-width: 297px;
    padding-left: 30px;
    text-indent: -30px;
  }

  .footer-container .footer-bottom .contact-us .contact-btn {
    border: 1px solid #FDAC0E;
    border-radius: 20px;
    font-size: 18px;
    text-align: center;
    margin: 7px 0px 18px;
    width: 170px;
    height: 38px;
    line-height: 38px;
    overflow: hidden;
    color: #FDAC0E;
  }
  .footer-container .footer-bottom .contact-us .contact-btn:hover {
    background-color: #FFF9EE;
  }
  .footer-container .footer-bottom .contact-us .contact-btn a {
    display: block;
    color: #333;
    font-size: 16px;
  }

  .footer-container .footer-bottom .contact-us .contact-btn svg {
    vertical-align: -3px;
    margin-right: 8px;
  }

  .footer-container .footer-bottom .contact-us p svg {
    display: inline-block;
    vertical-align: middle;
    margin-right: 8px;
  }

  .footer-container .footer-bottom .payment .payment-list {
    margin-bottom: 0;
  }

  .footer-container .footer-bottom .payment dl,
  .footer-container .footer-bottom .share-sitajabber dl {
    display: block;
    width: 100%;
  }

  .footer-container .footer-bottom .payment dl::after,
  .footer-container .footer-bottom .share-sitajabber dl::after {
    content: '';
    display: block;
    width: 100%;
    clear: both;
  }
  .footer-container .footer-bottom .share-sitajabber dl.google-reviews {
    display: flex;
    align-items: center;
  }
  .footer-container .footer-bottom .share-sitajabber dl.google-reviews dd {
    margin-right: 10px;
  }
  .footer-container .footer-bottom .payment dt,
  .footer-container .footer-bottom .share-sitajabber dt {
    font-weight: 600;
    font-size: 20px;
    line-height: 30px;
    color: #000000;
    display: block;
    margin-bottom: 10px;
    width: 100%;
  }

  .footer-container .footer-bottom .payment .payment-list dd {
    float: left;
    width: 60px;
    height: 35px;
    border: #F4F4F4 solid 1px;
    border-radius: 4px;
    margin-right: 15px;
    margin-bottom: 0;
    margin-top: 10px;
  }
  .footer-container .footer-bottom .payment .payment-list dd.applepay {
    border: none;
  }
  .footer-container .footer-bottom .payment .payment-list dd:last-child {
    margin-right: 0;
  }

  .footer-container .footer-bottom .payment .payment-list dd:nth-of-type(1) {
    background-image: url(/pub/images/footer/footer5.jpg) !important;
  }

  .footer-container .footer-bottom .payment .payment-list dd:nth-of-type(2) {
    background-image: url(/pub/images/footer/footer6.jpg) !important;
  }

  .footer-container .footer-bottom .payment .payment-list dd:nth-of-type(3) {
    background-image: url(/pub/images/footer/footer7.jpg) !important;
  }

  .footer-container .footer-bottom .payment .payment-list dd:nth-of-type(4) {
    background-image: url(/pub/images/footer/footer10.jpg) !important;
  }

  .footer-container .footer-bottom .payment .payment-list dd:nth-of-type(5) {
    width: 64px;
    background-image: url(/pub/images/footer/vorkasse.jpg) !important;
  }

  .footer-container .footer-bottom .share-sitajabber dl {
    display: block;
    margin-bottom: 0;
  }
  .footer-container .footer-bottom .share-sitajabber dl.follow-us {
    margin-top: 15px;
  }
  .footer-container .footer-bottom .share-sitajabber dl.follow-us dt {
    display: block;
  }

  .footer-container .footer-bottom .share-sitajabber dl.follow-us dd {
    margin-right: 15px;
    line-height: 0;
    margin-bottom: 0;
    display: inline-block;
  }

  .footer-container .footer-bottom .share-sitajabber dl.follow-us dd:last-child {
    margin-right: 0;
  }

  .footer-container .footer-bottom .share-sitajabber dl.follow-us dd a {
    display:inline-block;
    line-height:0;
  }
  .footer-container .footer-bottom .share-sitajabber dl.follow-us dd a:hover svg path {
    fill: #fdac0e;
  }

  .footer-container .footer-bottom .share-sitajabber .platform {
    margin-top: 8px !important;
  }

  .footer-container .footer-bottom .share-sitajabber #___ratingbadge_0 {
    overflow: hidden;
  }
  .pop-costway-cmp {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100vw;
    height: 100vh;
    z-index: 999999;
    background: rgba(0,0,0,.5);
  }

  @media (max-width: 980px) {
    .footer-container .footer-bottom .share-sitajabber #___ratingbadge_0 {
      position: static !important;
      border: 0 !important;
      box-shadow: none !important;
      width: 100% !important;
    }

    .footer-container .footer-bottom .share-sitajabber #___ratingbadge_0 iframe {
      position: static !important;
      width: 100% !important;
    }
    .footer-container .footer-bottom .share-sitajabber dl.follow-us {
      text-align: center;
      margin-top: 20px;
    }
    .footer-container .footer-bottom .payment dl, .footer-container .footer-bottom .share-sitajabber dl {
      margin-bottom: 0;
    }
  }
</style>

<div class="footer-container page-main">

  <div class="footer-container-top">
    <div class="bottom-logo">
      <a href="/">
        <svg class="svg-footer-logo" viewBox="0 0 182 80" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 21.0362C0 10.3216 7.3535 2.84155 17.629 2.84155C26.3414 2.84155 32.5368 7.5909 34.5517 15.427H26.9974C25.3339 12.0413 22.1107 10.0193 17.9302 10.0193C11.8854 10.0193 7.70494 14.416 7.70494 21.0362C7.70494 27.6564 11.8352 32.0027 17.9302 32.0027C22.4119 32.0027 25.7858 29.7288 27.1982 25.9367H34.7526C32.9887 34.2262 26.5924 39.2308 17.629 39.2308C7.25309 39.2308 0 31.7004 0 21.0362Z" fill="black" />
          <path d="M38.2803 21.0362C38.2803 10.3216 45.8848 2.84155 56.5619 2.84155C67.2391 2.84155 74.8436 10.3216 74.8436 21.0362C74.8436 31.7508 67.2391 39.2308 56.5619 39.2308C45.7844 39.2308 38.2803 31.7004 38.2803 21.0362ZM67.0885 21.0362C67.0885 14.4664 62.908 10.0193 56.5619 10.0193C50.2661 10.0193 45.9852 14.416 45.9852 21.0362C45.9852 27.6564 50.2159 32.0027 56.5619 32.0027C62.908 32.0027 67.0885 27.606 67.0885 21.0362Z" fill="black" />
          <path d="M79.0781 27.7068H86.4818C86.5822 30.7398 89.0992 32.5099 93.3835 32.5099C97.5138 32.5099 99.9805 30.9413 99.9805 28.3147C99.9805 25.7889 97.564 24.7275 92.4764 24.17C83.4594 23.159 79.5835 19.2157 79.5835 13.2538C79.5835 7.08708 84.9723 2.84155 93.0822 2.84155C101.142 2.84155 106.38 7.28861 106.631 13.9122H99.3747C99.1237 11.1815 97.0084 9.51549 93.0789 9.51549C89.2499 9.51549 87.0843 11.0841 87.0843 13.4083C87.0843 15.9342 88.9486 16.9956 93.7818 17.5531C103.552 18.6145 107.632 22.3058 107.632 28.3685C107.632 34.8879 102.042 39.2342 93.4806 39.2342C84.7179 39.2308 79.2789 34.7838 79.0781 27.7068Z" fill="black" />
          <path d="M136.343 3.34537V10.1705H127.024V38.727H119.47V10.1705H110.102V3.34537H136.343Z" fill="black" />
          <path d="M108.917 44.3161H116.926V44.8199L105.442 79.9966H102.269L92.5997 58.7186L82.9301 79.9966H79.757L68.1729 44.8199V44.3161H76.0786L79.4525 55.081L82.2238 65.1877L90.9864 45.3237H94.059L103.076 65.0869L105.693 55.081L108.917 44.3161Z" fill="black" />
          <path d="M135.864 44.0104L152.535 79.1872V79.691H144.375L141.758 73.8769H126.9L124.283 79.691H116.173V79.1872L132.845 44.0104H135.864ZM134.304 56.1928L129.872 67.2097H138.735L134.304 56.1928Z" fill="black" />
          <path d="M173.689 44.3161H182V44.8736L169.609 65.5471V79.6977H162.055V65.5471L149.563 44.8232V44.3194H158.025L162.306 51.5979L165.88 58.6246L169.505 51.4972L173.689 44.3161Z" fill="black" />
          <path d="M162.202 0L142.407 11.3528V38.727H182V11.3528L162.202 0Z" fill="#FFC842" />
          <path d="M18.1478 44.3161C8.32748 44.3161 0.368164 52.3033 0.368164 62.158C0.368164 72.0128 8.32748 80 18.1478 80H61.6663V44.3161H18.1478Z" fill="#FF5F44" />
        </svg>
      </a>
      <p class="footer-slogan">Mehr als einfache Möbel</p>
      <p>Costway ist der Meinung, dass jedes Haus vielseitig ist - mit Möglichkeit für jeden
        Einrichtungsstil. Unsere Philosophie der Neuerfindung geht über das Möbel selbst hinaus. Wir
        lassen uns von unserem Wunsch leiten, unsere Hausliebhaber nicht nur mit erfrischendem Raum,
        sondern auch mit blühendem Leben zu erfreuen.</p>
    </div>
    <div class="footer-menu">
      <dl>
        <dt>Information</dt>
        <dd>
          <a href="/ueber-costway">Über Costway</a>
        </dd>
        <dd>
          <a href="/warum-costway">Warum Costway</a>
        </dd>
        <dd>
          <a href="/agb">AGB</a>
        </dd>
        <dd>
          <a href="/sicherheit-datenschutz">Datenschutz</a>
        </dd>
        <dd>
          <a href="/impressum">Impressum</a>
        </dd>
        <dd>
          <a href="/recall">Rückruf</a>
        </dd>
        <dd>
          <a href="/blog/?entrypoint=footer">Blog</a>
        </dd>
      </dl>
      <dl>
        <dt>Kundenservice</dt>
        <dd>
          <a href="/zahlungsarten">Zahlungsarten</a>
        </dd>
        <dd>
          <a href="/versand-tipps">Versand Tipps</a>
        </dd>
        <dd>
          <a href="/widerrufsbelehrung">Rückgabe & Widerruf</a>
        </dd>
        <dd>
          <a href="/kontakt">Kontakt</a>
        </dd>
        <dd>
          <a href="/site-map">Sitemap</a>
        </dd>
        <dd></dd>
      </dl>
      <dl>
        <dt>Mein Konto</dt>
        <dd>
          <a href="/costway-punkt">Prämienpunkte</a>
        </dd>
        <dd>
          <a href="/aw_rewardpoints/info/coupon">Meine Gutscheine</a>
        </dd>
        <dd>
          <a href="/review/customer">Meine Bewertungen</a>
        </dd>
        <dd>
          <a href="/shipments">Bestellung Verfolgen</a>
        </dd>
        <dd>
          <a href="/loyalty-cashback?entrypoint=accountmenu">Mein Treuebonus</a>
        </dd>
      </dl>
      <dl>
        <dt>Partner & Programm</dt>
        <dd>
          <a href="/costway-de-dropshipping">Dropshipping</a>
        </dd>
        <dd>
          <a href="/partnerprogramm">Affiliate Programm</a>
        </dd>
      </dl>
    </div>
  </div>


  <div class="footer-bottom">

    <div class="share-sitajabber">
      <dl class="google-reviews">
        <dd id="MyCustomTrustbadge">
          

        </dd>
        <dd class="platform">
          
          <g:ratingbadge merchant_id=118536444></g:ratingbadge>
          
        </dd>
      </dl>
      <dl class="follow-us">
        <dd><a href="https://www.facebook.com/costway.de" target="_blank"><svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M20.9836 4C20.9836 4 18.7382 4 17.2477 4C15.0307 4 12.5648 4.87756 12.5648 7.90205C12.5756 8.9559 12.5648 9.96517 12.5648 11.101H10V14.9421H12.6441V26H17.5029V14.8692H20.7098L21 11.0903H17.4192C17.4192 11.0903 17.4272 9.40926 17.4192 8.92108C17.4192 7.72587 18.7406 7.79432 18.8201 7.79432C19.4489 7.79432 20.6716 7.79604 20.9855 7.79432V4H20.9836Z" fill="#333333"/>
        </svg></a></dd>
          <dd><a href="https://twitter.com/CostwayDE" target="_blank">
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
              <path d="M16.905 13.4695L24.3512 5H22.5869L16.1184 12.3524L10.9558 5H5L12.8086 16.1192L5 25H6.76429L13.591 17.2338L19.0442 25H25L16.905 13.4695ZM14.4877 16.2168L13.6954 15.1089L7.40053 6.30146H10.1108L15.1925 13.412L15.9815 14.5199L22.5861 23.7619H19.8758L14.4877 16.2168Z" fill="#333333"></path>
            </svg>
          </a></dd>
          <dd><a href="https://www.pinterest.de/costwayde" target="_blank"><svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M14.8631 4C8.83816 4 4 8.87865 4 14.954C4 19.4644 6.6473 23.2385 10.4813 24.9874C10.4813 24.251 10.4813 23.3305 10.6639 22.5021C10.8465 21.5816 12.0332 16.5188 12.0332 16.5188C12.0332 16.5188 11.6681 15.7824 11.6681 14.7699C11.6681 13.113 12.5809 11.9163 13.7676 11.9163C14.7718 11.9163 15.2282 12.6527 15.2282 13.5732C15.2282 14.5858 14.5892 16.0586 14.3154 17.4393C14.0415 18.636 14.9543 19.5565 16.0498 19.5565C18.1494 19.5565 19.5187 16.887 19.5187 13.7573C19.5187 11.364 17.8755 9.61508 15.0456 9.61508C11.7593 9.61508 9.75102 12.1004 9.75102 14.8619C9.75102 15.7824 10.0249 16.5188 10.4813 16.9791C10.6639 17.2553 10.7552 17.3473 10.6639 17.6234C10.5726 17.8076 10.4813 18.2678 10.4813 18.544C10.39 18.8201 10.2075 18.9122 9.9336 18.8201C8.38173 18.1758 7.74273 16.5189 7.74273 14.6778C7.74273 11.5482 10.2987 7.86613 15.5021 7.86613C19.61 7.86613 22.3485 10.9038 22.3485 14.1255C22.3485 18.4519 19.9751 21.5816 16.5062 21.5816C15.3195 21.5816 14.2241 20.9373 13.8589 20.2009C13.8589 20.2009 13.2199 22.6862 13.1286 23.2385C12.8548 24.0669 12.4896 24.8954 12.0332 25.5398C13.0373 25.8159 14.0415 26 15.1369 26C21.1618 26 26 21.1214 26 15.046C25.7261 8.87867 20.888 4 14.8631 4Z" fill="#333333"/>
        </svg></a></dd>
          <dd><a href="https://www.youtube.com/channel/UC1IOnDQICrP3_hxHuygAA6g/" target="_blank"><svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8.47808 14.4666C6.55712 14.4666 5 16.1105 5 18.1296V21.3281C5 23.3561 6.55712 25 8.47808 25H21.5143C23.4395 25 25 23.3561 25 21.3281V18.1296C25 16.1105 23.4395 14.4666 21.5143 14.4666H8.47808ZM6.87177 15.8782H10.5305V16.8699H9.30243V23.4723H8.04724V16.8699H6.87177V15.8782ZM15.1959 15.8782H16.3748V18.3441C16.8328 17.9152 17.1466 17.7455 17.5028 17.7455C17.7657 17.7455 18.0625 17.8795 18.1982 18.0671C18.3424 18.2636 18.3848 18.4691 18.3848 19.0856V22.2215C18.3848 22.8111 18.3424 23.0166 18.1982 23.2221C18.0625 23.4097 17.7657 23.5527 17.4773 23.5527C17.1296 23.5527 16.8328 23.374 16.3748 22.9362V23.4723H15.1959V15.8782ZM21.2429 17.7455C22.2267 17.7455 22.8289 18.2726 22.8289 19.1571V20.8188H20.7934V22.0517C20.7934 22.4716 20.9121 22.6414 21.2259 22.6414C21.3701 22.6414 21.5058 22.5699 21.5737 22.4716C21.633 22.3644 21.6585 22.2393 21.6585 21.8284V21.4889H22.8289V21.6944C22.8373 21.8373 22.8373 21.9445 22.8373 22.0071C22.8373 23.0077 22.2606 23.5527 21.192 23.5527C20.1828 23.5527 19.6145 22.9809 19.6145 21.9535V19.3268C19.6145 18.2547 20.1573 17.7455 21.2429 17.7455ZM10.7468 17.808H11.9214V22.2215C11.9214 22.4984 12.0147 22.6414 12.2318 22.6414C12.3844 22.6414 12.5117 22.5788 12.7534 22.4091V17.808H13.9322V23.4723H12.8551L12.7534 22.9809C12.2716 23.4008 11.9884 23.5527 11.6508 23.5527C11.3676 23.5527 11.0707 23.4097 10.935 23.231C10.7875 23.0345 10.7468 22.829 10.7468 22.2483V17.808ZM16.9006 18.6567C16.7564 18.6567 16.6207 18.7104 16.3748 18.889V22.4091C16.6207 22.5788 16.7564 22.6414 16.9006 22.6414C17.1211 22.6414 17.2144 22.4984 17.2144 22.2215V19.0856C17.2144 18.7818 17.1211 18.6567 16.9006 18.6567ZM21.2259 18.6567C20.9461 18.6567 20.7934 18.7997 20.7934 19.0677V20.0237H21.6585V19.0677C21.6585 18.7997 21.4888 18.6567 21.2259 18.6567ZM20.1488 13.3409L20.0471 12.8049C19.5128 13.2695 19.199 13.4303 18.8258 13.4303C18.5205 13.4303 18.1897 13.2784 18.0371 13.0818C17.8759 12.8674 17.8335 12.6351 17.8335 11.999V7.12633H19.1311V11.9677C19.1311 12.2778 19.2244 12.4296 19.4704 12.4296C19.623 12.4296 19.7757 12.3671 20.0471 12.1706V7.12633H21.3447V13.3409H20.1488ZM14.6955 7.04413C15.8744 7.04413 16.4681 7.632 16.4681 8.7988V11.6792C16.4681 12.8495 15.8744 13.4303 14.6955 13.4303C13.5336 13.4303 12.9315 12.8495 12.9315 11.6792V8.7988C12.9315 7.632 13.5336 7.04413 14.6955 7.04413ZM14.6955 8.04476C14.3817 8.04476 14.2291 8.25203 14.2291 8.62369V11.8543C14.2291 12.2152 14.4072 12.4296 14.6955 12.4296C15.0008 12.4296 15.179 12.2152 15.179 11.8543V8.62369C15.179 8.25203 15.0008 8.04476 14.6955 8.04476ZM8.3763 5H9.87575L10.0717 5.80497L10.2286 6.41428L10.366 7.00214L10.4932 7.61145L10.6009 8.12785H10.6594L10.7671 7.61145L10.885 7.00214L11.0317 6.41428L11.1793 5.80497L11.3845 5H12.8467L11.2963 9.87269V13.3409H9.91477V9.87269L8.3763 5Z" fill="#333333"/>
        </svg></a></dd>
          <dd><a href="https://www.instagram.com/costway.de/" target="_blank"><svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M15.2891 9.645C12.1658 9.645 9.64517 12.1657 9.64517 15.289C9.64517 18.4123 12.1658 20.9329 15.2891 20.9329C18.4124 20.9329 20.9331 18.4123 20.9331 15.289C20.9331 12.1657 18.4124 9.645 15.2891 9.645ZM15.2891 18.9571C13.2693 18.9571 11.621 17.3088 11.621 15.289C11.621 13.2691 13.2693 11.6208 15.2891 11.6208C17.309 11.6208 18.9573 13.2691 18.9573 15.289C18.9573 17.3088 17.309 18.9571 15.2891 18.9571ZM21.1642 8.09848C20.435 8.09848 19.8461 8.68737 19.8461 9.4166C19.8461 10.1458 20.435 10.7347 21.1642 10.7347C21.8935 10.7347 22.4824 10.1486 22.4824 9.4166C22.4796 8.68462 21.8935 8.09848 21.1642 8.09848Z" fill="#333333"/>
        <path d="M26.2908 15.289C26.2908 13.77 26.3045 12.2647 26.2192 10.7485C26.1339 8.98734 25.7321 7.42431 24.4443 6.13647C23.1537 4.84587 21.5934 4.44686 19.8323 4.36155C18.3133 4.27624 16.808 4.29 15.2918 4.29C13.7728 4.29 12.2676 4.27624 10.7513 4.36155C8.99015 4.44686 7.42712 4.84862 6.13927 6.13647C4.84868 7.42706 4.44966 8.98734 4.36436 10.7485C4.27905 12.2675 4.29281 13.7727 4.29281 15.289C4.29281 16.8052 4.27905 18.3132 4.36436 19.8295C4.44966 21.5906 4.85143 23.1536 6.13927 24.4415C7.42987 25.7321 8.99015 26.1311 10.7513 26.2164C12.2703 26.3017 13.7755 26.288 15.2918 26.288C16.8108 26.288 18.316 26.3017 19.8323 26.2164C21.5934 26.1311 23.1565 25.7293 24.4443 24.4415C25.7349 23.1509 26.1339 21.5906 26.2192 19.8295C26.3073 18.3132 26.2908 16.808 26.2908 15.289ZM23.8692 21.7777C23.6683 22.2786 23.4261 22.6528 23.0381 23.0381C22.6501 23.4261 22.2786 23.6682 21.7778 23.8691C20.3303 24.4442 16.8933 24.3149 15.289 24.3149C13.6847 24.3149 10.245 24.4442 8.79752 23.8719C8.29669 23.671 7.92245 23.4288 7.53719 23.0408C7.14919 22.6528 6.90703 22.2813 6.70615 21.7805C6.13377 20.3303 6.26311 16.8933 6.26311 15.289C6.26311 13.6847 6.13377 10.2449 6.70615 8.79746C6.90703 8.29664 7.14919 7.92239 7.53719 7.53714C7.9252 7.15188 8.29669 6.90697 8.79752 6.70609C10.245 6.13371 13.6847 6.26305 15.289 6.26305C16.8933 6.26305 20.3331 6.13371 21.7806 6.70609C22.2814 6.90697 22.6556 7.14913 23.0409 7.53714C23.4289 7.92514 23.671 8.29664 23.8719 8.79746C24.4443 10.2449 24.315 13.6847 24.315 15.289C24.315 16.8933 24.4443 20.3303 23.8692 21.7777Z" fill="#333333"/>
        </svg></a></dd>
      </dl>
    </div>

    <div class="payment">
      <dl class="payment-list">
        <dt>Zahlungsarten</dt>
        <dd></dd>
        <dd></dd>
        <dd></dd>
        <dd></dd>
        <dd></dd>
        <dd class="applepay"><img width="60" height="35" class="lazy"  data-original="/pub/images/footer/APPLEPAY.png" alt="KLARNA"></dd>
      </dl>

    </div>

    <div class="contact-us">
      <a href="/kontakt">
          <div class="contact-btn">Kontakt</div>
      </a>
      <p>
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M3 3C1.75736 3 0.75 4.00736 0.75 5.25V12.75C0.75 13.9926 1.75736 15 3 15H15C16.2426 15 17.25 13.9926 17.25 12.75V5.25C17.25 4.00736 16.2426 3 15 3H3ZM2.25 5.45015V12.75C2.25 13.1642 2.58579 13.5 3 13.5H15C15.4142 13.5 15.75 13.1642 15.75 12.75V5.45021L10.3814 9.62578C9.5689 10.2577 8.43117 10.2577 7.61867 9.62578L2.25 5.45015ZM14.5285 4.5H3.47161L8.53958 8.44176C8.81041 8.6524 9.18966 8.6524 9.46049 8.44176L14.5285 4.5Z" fill="#333333"></path>
        </svg>
        <a href="/cdn-cgi/l/email-protection#ea8999c48e8faa8985999e9d8b93c4898587"><span class="__cf_email__" data-cfemail="f29181dc9697b2919d818685938bdc919d9f">[email&#160;protected]</span></a>
      </p>
      <p class="addrss">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M9.54045 17.02C9.39906 17.167 9.20393 17.25 9 17.25C8.79607 17.25 8.60071 17.1667 8.45932 17.0198L8.39495 16.9519C8.39495 16.9519 8.29607 16.8464 8.22212 16.7659C8.07427 16.605 7.8643 16.3723 7.6129 16.0822C7.11081 15.5028 6.43984 14.6902 5.76719 13.7597C5.09623 12.8316 4.41304 11.7717 3.89491 10.6986C3.38245 9.63711 3 8.4992 3 7.43182C3 4.14655 5.69556 1.5 9 1.5C12.3044 1.5 15 4.14655 15 7.43182C15 8.4992 14.6176 9.63711 14.1051 10.6986C13.587 11.7717 12.9038 12.8316 12.2328 13.7597C11.5602 14.6902 10.8892 15.5028 10.3871 16.0822C10.1357 16.3723 9.92573 16.605 9.77788 16.7659C9.77788 16.7659 9.58087 16.9771 9.54045 17.02ZM4.5 7.43182C4.5 4.99341 6.50545 3 9 3C11.4946 3 13.5 4.99341 13.5 7.43182C13.5 8.17035 13.2262 9.06893 12.7543 10.0464C12.288 11.0121 11.6587 11.9935 11.0172 12.881C10.3773 13.766 9.73581 14.5433 9.25352 15.0998C9.1629 15.2044 9.07803 15.301 9 15.389C8.92196 15.301 8.8371 15.2044 8.74648 15.0998C8.26419 14.5433 7.62266 13.766 6.98281 12.881C6.34127 11.9935 5.71196 11.0121 5.24572 10.0464C4.7738 9.06893 4.5 8.17035 4.5 7.43182Z" fill="#333333"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M6.75 7.5C6.75 6.25736 7.75736 5.25 9 5.25C10.2426 5.25 11.25 6.25736 11.25 7.5C11.25 8.74264 10.2426 9.75 9 9.75C7.75736 9.75 6.75 8.74264 6.75 7.5ZM8.25 7.5C8.25 7.08579 8.58579 6.75 9 6.75C9.41421 6.75 9.75 7.08579 9.75 7.5C9.75 7.91421 9.41421 8.25 9 8.25C8.58579 8.25 8.25 7.91421 8.25 7.5Z" fill="#333333"></path>
        </svg>FDS GmbH Neuer Höltigbaum 30 22143 Hamburg
      </p>

    </div>
  </div>



</div>




    <div class="footer-copyright">
        <div class="page-main">
            <div class="cus-container">
                <div class="copyright-block">
                    <small class="copyright">
                                                <span>Copyright © 2015-2026 Costway.de, Alle Rechte vorbehalten</span>
                                            </small>
                </div>
                            </div>
        </div>
    </div>
</div>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WXMKW85"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    
    <!-- 客服 -->
    
    
    
    
    
    <!-- Emarsys footer  -->
    
    <!-- 首页Emarsys推荐产品 -->
    
    
    
    <!-- 首页 see moreEmarsys推荐产品 -->
    
    
    
    
    
    
    
     <!-- 产品详情页top推荐产品 -->   
    
    
    
    <!-- Emarsys global footer end  -->
      
        
    
    <!-- Emarsys Web Push  -->
        <style>
            .emarsys-permission-popup {
                position: fixed;
                /* width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5); */
                display: none;
                z-index: 999999;
            }
    
            .emarsys-permission-popup.not-bg {
                background: none;
            }
    
            .emarsys-permission-popup.hide {
                display: none;
            }
    
            .emarsys-permission-popup.flex {
                display: flex;
                left: 20px;
            }
    
            @media (min-width: 767px) {
                .emarsys-permission-popup {
                    align-items: flex-start;
                    justify-content: left;
                    top: 48px;
                    left: -400px;
                    transition: left 0.3s ease-in-out;
                    -webkit-transition: left 0.3s ease-in-out;
                    -moz-transition: left 0.3s ease-in-out;
                    -ms-transition: left 0.3s ease-in-out;
                    -o-transition: left 0.3s ease-in-out;
                }
    
                .emarsys-permission-popup.flex {
                    left: 20px;
                }
            }
    
            .emarsys-permission-popup .emarsys-permission-popup-content {
                margin-top: 0;
                background-color: #fff;
                padding: 30px;
                border-radius: 10px;
                text-align: center;
                max-width: 310px;
                position: relative;
                box-shadow: 2px 5px 16px 0px rgba(0, 0, 0, 0.17);
    
            }
    
            .emarsys-permission-popup .emarsys-permission-popup-content p {
                margin: 0;
                padding: 0;
                font-size: 14px;
                line-height: 21px;
                color: #333;
            }
    
            .emarsys-permission-popup .emarsys-permission-popup-icon {
                position: absolute;
                top: 15px;
                right: 15px;
                width: 16px;
                height: 16px;
                cursor: pointer;
            }
    
            .emarsys-permission-popup .button-group {
                margin-top: 30px;
            }
    
            .emarsys-permission-popup .button-group button {
                padding: 0;
                display: inline-block;
                width: 120px;
                height: 40px;
                border-radius: 20px;
                font-size: 14px;
                cursor: pointer;
            }
    
            .emarsys-permission-popup .emarsys-decline-button {
                background-color: #fff;
                border: 1px solid #ccc;
                color: #333;
                line-height: 38px;
            }
    
            .emarsys-permission-popup .emarsys-subscribe-button {
                margin: 0 0 0 10px;
                background-color: #fdac0e;
                border: none;
                color: #fff;
                line-height: 40px;
            }
    
            @media (max-width: 767px) {
                .emarsys-permission-popup {
                    width: 100vw;
                    top: auto;
                    left: auto;
                    bottom: -400px;
                    justify-content: center;
                    align-items: center;
                    transition: bottom 0.3s ease-in-out;
                    -webkit-transition: bottom 0.3s ease-in-out;
                    -moz-transition: bottom 0.3s ease-in-out;
                }
    
                .emarsys-permission-popup.flex {
                    bottom: 30px;
                    left: 0;
                }
    
                .emarsys-permission-popup .emarsys-permission-popup-content {
                    margin-top: 0;
                    padding: 5.3333vw;
                    border-radius: 2.6666666667vw;
                    width: 93.8666666667vw;
                    max-width: none;
                    box-sizing: border-box;
                    box-shadow: 2px 5px 16.1px 0px rgba(86, 86, 86, 0.25);
    
                }
    
                .emarsys-permission-popup .emarsys-permission-popup-content p {
                    font-size: 3.73333vw;
                    line-height: 5.6vw;
                    padding: 0 4vw 0 4vw;
                }
    
                .emarsys-permission-popup .emarsys-permission-popup-icon {
                    display: none;
                    top: 4.666vw;
                    right: 4.666vw;
                    width: 3.4666666667vw;
                    height: 3.4666666667vw;
                }
    
                .emarsys-permission-popup .button-group {
                    margin-top: 6.6666666667vw;
                }
    
                .emarsys-permission-popup .button-group button {
                    width: 40vw;
                    height: 10.6666666667vw;
                    border-radius: 5.3333333333vw;
                    font-size: 3.4666666667vw;
                    box-sizing: border-box;
                }
    
                .emarsys-permission-popup .emarsys-decline-button {
                    line-height: 10.6666666667vw;
                }
    
                .emarsys-permission-popup .emarsys-subscribe-button {
                    margin: 0 0 0 1.333vw;
                    line-height: 10.6666666667vw;
                }
            }
        </style>
        
        <div class="emarsys-permission-popup" id="emarsys-permission-popup">
            <div class="emarsys-permission-popup-content">
                <p>
                    Möchten Sie aktuelle Informationen zu Veranstaltungen und Sonderangeboten erhalten?
                </p>
                <div class="button-group">
                    <button class="emarsys-decline-button" onclick="if (!window.__cfRLUnblockHandlers) return false; hideEmarsysPermissionPopup()" data-cf-modified-b582c3d0dfb6bd35c494053c-="">
                        Nein, danke
                    </button>
                    <button class="emarsys-subscribe-button" onclick="if (!window.__cfRLUnblockHandlers) return false; generalSubscribe()" data-cf-modified-b582c3d0dfb6bd35c494053c-="">
                        Ja
                    </button>
                </div>
                <svg onclick="if (!window.__cfRLUnblockHandlers) return false; hideEmarsysPermissionPopup()" class="emarsys-permission-popup-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-cf-modified-b582c3d0dfb6bd35c494053c-="">
                    <path
                        d="M15.3885 0C15.2258 7.43866e-05 15.0697 0.0647612 14.9547 0.179836L0.179654 14.953C0.122695 15.01 0.0775137 15.0776 0.0466886 15.152C0.0158636 15.2264 -1.12251e-06 15.3061 0 15.3867C1.12263e-06 15.4672 0.0158682 15.547 0.0466953 15.6214C0.0775224 15.6958 0.122706 15.7634 0.179666 15.8204C0.236626 15.8773 0.304247 15.9225 0.378668 15.9533C0.453089 15.9841 0.532853 16 0.613405 16C0.693958 16 0.773721 15.9841 0.848141 15.9533C0.922561 15.9225 0.990181 15.8773 1.04714 15.8204L15.8235 1.04593C15.9083 0.959752 15.9657 0.850498 15.9888 0.73183C16.0118 0.613161 15.9993 0.490342 15.9529 0.378729C15.9064 0.267116 15.8281 0.171661 15.7278 0.1043C15.6274 0.0369387 15.5094 0.000660896 15.3885 0Z"
                        fill="#666666" />
                    <path
                        d="M0.615693 5.72205e-06C0.493991 -0.000541687 0.374881 0.0351591 0.273539 0.102558C0.172197 0.169957 0.093211 0.266004 0.0466438 0.37846C7.66332e-05 0.490916 -0.0119631 0.614694 0.0120583 0.734018C0.0360798 0.853343 0.0950748 0.962814 0.181527 1.04849L14.9723 15.8399C15.0891 15.9463 15.2424 16.0036 15.4004 15.9998C15.5583 15.9961 15.7088 15.9316 15.8204 15.8198C15.9321 15.7079 15.9963 15.5574 15.9998 15.3994C16.0034 15.2414 15.9459 15.0882 15.8393 14.9715L1.04986 0.180064C0.992894 0.122958 0.925221 0.0776587 0.850718 0.0467606C0.776215 0.0158625 0.696347 -2.67029e-05 0.615693 5.72205e-06Z"
                        fill="#666666" />
                </svg>
            </div>
        </div>
    
    
        
    
        <!-- web push END -->
    
    
    
    
    
    

    <a class="scrollup" href="#" title="Nach oben scrollen" >
        <div class="scrollup-box">
            <div>
                <div class="svg"><svg width="18" height="11" viewBox="0 0 18 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2.01245 10.5191L8.9469 3.00623L15.882 10.5191C15.967 10.6113 16.0694 10.6858 16.1832 10.7383C16.297 10.7909 16.4201 10.8206 16.5453 10.8256C16.6706 10.8306 16.7956 10.8109 16.9133 10.7676C17.031 10.7243 17.1389 10.6583 17.2311 10.5732C17.3232 10.4882 17.3977 10.3859 17.4503 10.272C17.5029 10.1582 17.5325 10.0352 17.5375 9.90989C17.5426 9.78461 17.5229 9.65957 17.4796 9.54191C17.4363 9.42425 17.3702 9.31627 17.2852 9.22414L9.64881 0.951418C9.55942 0.854527 9.45094 0.777201 9.33019 0.724312C9.20944 0.671424 9.07904 0.644119 8.94722 0.644119C8.81539 0.644119 8.685 0.671424 8.56425 0.724312C8.4435 0.777201 8.33501 0.854527 8.24563 0.951419L0.609267 9.22414C0.524236 9.31627 0.458185 9.42425 0.414885 9.54191C0.371585 9.65957 0.351884 9.78461 0.356907 9.90989C0.361929 10.0352 0.391578 10.1582 0.444159 10.272C0.49674 10.3859 0.571224 10.4882 0.663358 10.5732C0.755492 10.6583 0.863472 10.7243 0.981133 10.7676C1.09879 10.8109 1.22383 10.8306 1.34911 10.8256C1.47438 10.8206 1.59744 10.7909 1.71126 10.7383C1.82507 10.6858 1.92742 10.6113 2.01245 10.5191Z" fill="white"/>
                </svg></div>
                <div class="txt">Top</div>
            </div>
        </div>
    </a>

    <style>
    .scrollup:visited, .scrollup:active {
        color: #FFFFFF;
    }
    .scrollup{
        color: #FFFFFF;
        background-color: #222222;
        border-color: #222222;
    }

    .scrollup:hover {
        color: #FFFFFF;
        background-color: #222222;
    }    
</style>
<div id="subscribe-modal" class="subscribe-modal summer-cooling-theme">
    <div class="modal-main" id="modal-main">
        <div class="modal-content">
            <span class="close-button gtm-pop-x">
                <svg class="gtm-pop-x" width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M19.2356 -8.96454e-05C19.0322 7.62939e-06 18.8372 0.0842361 18.6934 0.234074L0.224567 19.47C0.153369 19.5441 0.0968921 19.6322 0.0583608 19.7291C0.0198295 19.826 -1.40313e-06 19.9298 0 20.0347C1.40328e-06 20.1395 0.0198352 20.2434 0.0583691 20.3403C0.096903 20.4372 0.153382 20.5252 0.224582 20.5994C0.295782 20.6735 0.380309 20.7323 0.473335 20.7725C0.566361 20.8126 0.666066 20.8333 0.766757 20.8333C0.867447 20.8333 0.967151 20.8126 1.06018 20.7725C1.1532 20.7323 1.23773 20.6735 1.30892 20.5993L19.7793 1.3618C19.8853 1.24959 19.9572 1.10733 19.9859 0.952814C20.0147 0.798298 19.9991 0.638376 19.9411 0.493048C19.8831 0.347717 19.7852 0.223427 19.6597 0.135717C19.5342 0.048008 19.3867 0.000770569 19.2356 -8.96454e-05Z"
                        fill="#666666" />
                    <path
                        d="M0.769616 -8.01086e-05C0.617489 -0.00079155 0.468602 0.0456924 0.341924 0.133451C0.215246 0.22121 0.116514 0.346272 0.0583048 0.492699C9.57915e-05 0.639126 -0.0149539 0.800295 0.0150729 0.955666C0.0450997 1.11104 0.118844 1.25358 0.226909 1.36513L18.7154 20.6248C18.8614 20.7633 19.053 20.8379 19.2505 20.833C19.4479 20.8281 19.636 20.7442 19.7755 20.5986C19.9151 20.453 19.9954 20.2569 19.9998 20.0512C20.0042 19.8455 19.9323 19.646 19.7992 19.494L1.31232 0.234371C1.24112 0.160013 1.15653 0.10103 1.0634 0.0607986C0.970269 0.020565 0.870434 -0.00012207 0.769616 -8.01086e-05Z"
                        fill="#666666" />
                </svg>
            </span>
            <div id="dynamic-content">
            </div>
        </div>
    </div>

</div>
<div id="right-coupon-icon" class="right-coupon-icon footer-right-popup">
    <div class="footer-right-popup">
        <span class="price-box footer-right-popup">
            <span class="price footer-right-popup">160</span>
            <span class="coin footer-right-popup">€</span>
        </span>
    </div>
</div>
<div class="m-subscribe-rows" id="m-subscribe-rows">
    <div>
        <span class="close-btn"><svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M23.7194 2.97142C23.5079 2.97152 23.305 3.05561 23.1555 3.20521L3.94791 22.4103C3.87386 22.4844 3.81512 22.5723 3.77505 22.669C3.73498 22.7657 3.71435 22.8694 3.71436 22.9741C3.71436 23.0788 3.73498 23.1825 3.77506 23.2792C3.81513 23.376 3.87387 23.4639 3.94792 23.5379C4.02197 23.6119 4.10988 23.6707 4.20662 23.7107C4.30337 23.7508 4.40706 23.7714 4.51178 23.7714C4.6165 23.7714 4.72019 23.7508 4.81694 23.7107C4.91369 23.6707 5.00159 23.6119 5.07564 23.5379L24.2849 4.33113C24.3951 4.2191 24.4698 4.07707 24.4997 3.9228C24.5297 3.76853 24.5134 3.60887 24.4531 3.46377C24.3927 3.31867 24.291 3.19458 24.1605 3.10701C24.03 3.01944 23.8765 2.97228 23.7194 2.97142Z" fill="white"/><path d="M4.51476 2.97143C4.35654 2.97072 4.2017 3.01713 4.06996 3.10475C3.93821 3.19237 3.83553 3.31723 3.77499 3.46342C3.71446 3.60962 3.6988 3.77052 3.73003 3.92565C3.76126 4.08077 3.83795 4.22308 3.95034 4.33446L23.1783 23.5633C23.3302 23.7016 23.5295 23.7761 23.7349 23.7712C23.9402 23.7663 24.1358 23.6825 24.2809 23.5371C24.426 23.3917 24.5096 23.196 24.5142 22.9906C24.5187 22.7853 24.444 22.586 24.3055 22.4343L5.07917 3.20551C5.00512 3.13127 4.91714 3.07238 4.82029 3.03221C4.72343 2.99204 4.61961 2.97139 4.51476 2.97143Z" fill="white"/></svg></span><span class="txt">Jetzt abonnieren und  <strong>160 €</strong> sparen.</span><button type="button" class="btn">Abonnieren</button>
    </div>
</div>

<div class="sidebar-product-wrapper" id="sidebar-product-wrapper"></div></div>    
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="b582c3d0dfb6bd35c494053c-text/javascript">
    var LOCALE = 'de\u002DDE';
    var BASE_URL = 'https\u003A\u002F\u002Fwww.costway.de\u002F';
    var require = {
        'baseUrl': 'https\u003A\u002F\u002Fwww.costway.de\u002Fstatic\u002Fversion1778723978\u002Ffrontend\u002Fdefault\u002Fhooya\u002Fde_DE'
    };</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/requirejs/require.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/requirejs-min-resolver.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle0.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle1.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle2.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle3.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle4.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle5.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle6.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/js/bundle/bundle7.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/mage/requirejs/static.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/mage/requirejs/mixins.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/requirejs-config.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/Solwin_ScrolltoTop/js/scroll.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript" src="https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/Solwin_Cpanel/js/adbeaut-customjs.min.js"></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript"> 
require(['jquery'], function ($) {
     if($('body').hasClass('checkout-onepage-success')){
         $('title').text('Bestellung bestätigen')
     }
})
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        require(['jquery'], function ($) {
            var str= $(".page-title").text();
            $(".page-title").text(str.replace('- Costway', ''));
        })
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery'], function ($) {
        jQuery(document).ready(function () {         
if ($('body').hasClass('catalog-product-view')) {
            const includedSku = ['NP11494','NP11559','NP11598','NP11942','NP11941','NP11622GN','NP11394','NP11544NY','NP10752BE','NP11034','NP11075BE','NP10817BL',
            'OP70714','NP11545','NP11584BL','NP11617','OP70716','NP11076','OP70736','NP11603','NP11523','NP11522','NP11563','NP10817MS','NP11597BE','NP11597CF',
            'NP11074BE','NP11544MS','NP11584GR','OP3150','OP2227-10','OP2227-9','OP70314RY','OP70314GN','OP70314BL','OP70715','NP10498','OP70714GN','OP70714RE',
            'NP10823BE','NP10823CF','OP3928NY','NP10823NY','NP10823WN','NP10497','NP11562','NP11618','OP2227-9RE','OP2227-10BE','OP2227-10SA',
            'OP2227-10RE','OP3150BE','OP3150TN','OP3150GN'];
            const currentProductSku = $("#product_addtocart_form").data("product-sku");
            if (includedSku.includes(currentProductSku)) {
                $(".product-info-main .page-title-wrapper.product").after('<p>* Ein Schirmständer wird nicht mitgeliefert.</p>');
            }
        }
        })
    })
</script>
<script type="text/x-magento-init">
        {
            "*": {
                "Magento_PageCache/js/form-key-provider": {
                    "isPaginationCacheEnabled":
                        0                }
            }
        }
    </script>
<script async data-environment="production" src="https://js.klarna.com/web-sdk/v1/klarna.js" data-client-id="klarna_live_client_clZoTlBiVig0RlcobVRGSj9NMnphaWZxKiV5dUMyVGgsYWFjMDllMmUtYzdkMC00Zjg1LWJlNTctYTc2MzM2NTM1OTEyLDEsOXhNRUhoN1BpalJLdlZxVWlLS0FqRmhKaGNURlN4UWd1ai9DU1hPaWFaYz0" type="b582c3d0dfb6bd35c494053c-text/javascript"></script>
<script data-rocketjavascript="false" type="b582c3d0dfb6bd35c494053c-text/javascript">
    var MagefanWebP = {

        _canUseWebP: null,

        getUserAgentInfo: function(){
            try {
                var ua = navigator.userAgent,
                    tem,
                    M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
                if (/trident/i.test(M[1])) {
                    tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                    return ['IE', (tem[1] || '')];
                }
                if (M[1] === 'Chrome') {
                    tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
                    if (tem != null) {
                        tem = tem.slice(1);
                        tem[0] = tem[0].replace('OPR', 'Opera');
                        return tem;
                    }
                }
                M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
                if ((tem = ua.match(/version\/(\d+)/i)) != null) M.splice(1, 1, tem[1]);
                return M;
             } catch (e) {
                return ['', 0];
             }
        },

        canUseWebP: function(){

            if (null !== this._canUseWebP){
                return this._canUseWebP;
            }

            try {
                var elem = document.createElement('canvas');
                if (!!(elem.getContext && elem.getContext('2d'))) {
                    var r = (elem.toDataURL('image/webp').indexOf('data:image/webp') == 0);
                    if (!r) {
                        var ua = this.getUserAgentInfo();
                        if (ua && ua.length > 1) {
                            ua[0] = ua[0].toLowerCase();
                            if ('firefox' == ua[0] && parseInt(ua[1]) >= 65) {
                                this._canUseWebP = true;
                                return this._canUseWebP;
                            }
                            if ('edge' == ua[0] && parseInt(ua[1]) >= 18) {
                                this._canUseWebP = true;
                                return this._canUseWebP;
                            }
                        }
                    }

                    this._canUseWebP = r;
                    return this._canUseWebP;
                }
                this._canUseWebP = false;
                return this._canUseWebP;
            } catch (e) {
                console.log(e);
                this._canUseWebP = false;
                return this._canUseWebP;
            }
        },

        getOriginWebPImage: function(src) {

            if (src.indexOf('mf_webp') == -1) {
                return src;
            }

            var $array = src.split('/');
            var $imageFormat = '';

            for (var i = 0; i < $array.length; i++) {
                if ($array[i] == "mf_webp") {
                    $imageFormat = $array[i + 1];
                    $array.splice(i, 3);
                    break;
                }
            }
            src = $array.join('/');
            return src.replace('.webp', '.' + $imageFormat);
        },

        getWebUrl: function (imageUrl) {
            /* @var string */
            imageUrl = imageUrl.trim();
            var baseUrl = 'https://www.costway.de/';
            var imageFormat = imageUrl.split('.').pop();
            var mediaBaseUrl = 'https://www.costway.de/media/';
            var staticBaseUrl = 'https://www.costway.de/static/';

            if (imageUrl.indexOf(mediaBaseUrl) == -1 && imageUrl.indexOf(staticBaseUrl) == -1) {
                return false;
            }

            var imagePath = imageUrl;
            imagePath = imagePath.replace(mediaBaseUrl, 'media/');
            imagePath = imagePath.replace(staticBaseUrl, 'static/');
            imagePath = imagePath.replace(baseUrl + 'pub/media/', 'media/');
            imagePath = imagePath.replace(baseUrl + 'pub/static/', 'static/');
            imagePath = imagePath.replace(/\.(jpg|jpeg|png|JPG|JPEG|PNG|gif|GIF)/i, '.webp');
            imagePath = mediaBaseUrl + 'mf_webp/' + imageFormat + '/' + imagePath;
            imagePath = imagePath.replace('%20', ' ');
            imagePath = imagePath.replace(/version\d{10}\//g, '');
            return imagePath;
        }
    };

    /* MagicToolboxContainer Fix */
    function MagefanWebPMagicToolboxContainerFix()
    {
        if (!MagefanWebP.canUseWebP()) {
            (function(){
                var i;
                var els = document.querySelectorAll(".MagicToolboxContainer a, .MagicToolboxContainer img");
                if (!els) return;
                var el;
                for (i=0; i<els.length; i++) {
                    el = els[i];
                    if (el.href) {
                        el.href = MagefanWebP.getOriginWebPImage(el.href);
                    }

                    if (el.getAttribute('webpimg')) {
                        el.src = MagefanWebP.getOriginWebPImage(el.getAttribute('webpimg'));
                    } else {
                        if (el.src) {
                            el.src = MagefanWebP.getOriginWebPImage(el.src);
                        }
                    }

                    if (el.dataset && el.dataset.image) {
                        el.dataset.image = MagefanWebP.getOriginWebPImage(el.dataset.image);
                    }

                }
            })();
        } else {
            replacePixelMagicToolbox();
            checkIfPixelReplaced();
        }
    }

    function replacePixelMagicToolbox() {
        (function() {
            var i, els = document.querySelectorAll(".MagicToolboxContainer img");

            if (!els) return;
            var el;

            for (i=0; i<els.length; i++) {
                el = els[i];

                if (el.getAttribute('webpimg')) {
                    el.src = el.getAttribute('webpimg');
                }
            }
        })();
    }

    function checkIfPixelReplaced() {
        var intervalCounter = 0,
            waitForMagicToolbox = setInterval(function() {
                if (document.querySelectorAll('figure img[src$="/p.jpg"]').length) {
                   replacePixelMagicToolbox();
                   clearInterval(waitForMagicToolbox);
                }

                if (intervalCounter > 10) {
                    clearInterval(waitForMagicToolbox);
                }

                intervalCounter++;
            }, 500);
    }

    document.addEventListener("DOMContentLoaded", function(){
        if (!MagefanWebP.canUseWebP()) {
            document.body.className += ' no-webp ';

             (function(){
                var i;
                var els = document.querySelectorAll('a[href$=".webp"]');
                if (!els) return;
                var el;
                for (i=0; i<els.length; i++) {
                    el = els[i];
                    if (el.href) {
                        el.href = MagefanWebP.getOriginWebPImage(el.href);
                    }
                }
            })();
            
        } else {
            document.body.className += ' webp-supported ';
        }
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery', 'domReady!'], function($){
        if (!MagefanWebP.canUseWebP()) {
            /* Replace some custom webp images with original one if webp is not supported */
            /* Can add <a> tag in future as well */
            setInterval(function(){
                $("img[src$='.webp']:not(.no-origin-webp-img)").each(function(){
                    var $t = $(this);
                    var scr = $t.attr('src');
                    var newScr = MagefanWebP.getOriginWebPImage(scr);

                    if (scr != newScr) {
                        $t.attr('src', newScr);
                    } else {
                        $t.addClass('no-origin-webp-img');
                    }
                });
            }, 1000);
        }

        function processLazyPictureImg()
        {
            var $t = $(this);
            var src = $t.attr('src');
            var keys = ['original', 'src', 'lazyload'];
            var original, _original;
            for (var i=0;i<keys.length;i++) {
                _original = $t.data(keys[i]);
                if (_original) {
                    original = _original;
                    break;
                }
            }
            if (original == src) {

                if ($t.data('mf-lazy-picture-img')) return;
                $t.data('mf-lazy-picture-img', 1);

                $t.parent().find('source').each(function(){
                    var $s = $(this);
                    var srcset = $s.attr('srcset');
                    var originalset = $s.data('originalset');
                    if (originalset != srcset) {
                        $s.attr('srcset', originalset);
                        $s.removeClass('lazyload');
                    }
                });
                $t.parents('.lazy-loader').removeClass('lazy-loader');
                $("picture img[src='"+src+"']").each(processLazyPictureImg);
            }
        }

        $('picture img[data-original],picture img[data-src],picture img[data-lazyload]')
            .on('load', processLazyPictureImg)
            .each(processLazyPictureImg);
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        require([
            'jquery'
        ], function () {
            jQuery("body").addClass("bh-type-" +4);
        });
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require([
    'jquery',
    'domReady!'
    ], function ($) {
        $('.cus-ajax-loader').fadeOut("slow");
    });
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(['jquery'], function () {
    jQuery(document).ready(function() {
        if(jQuery(".block-reorder").find('.block-content.no-display').length > 0) {
          jQuery(".block.block-reorder").hide();
        }
        if (jQuery.trim(jQuery('.sidebar-main .account-nav #account-nav').text()).length == 0 ) {
          jQuery(".sidebar-main .account-nav").hide();
        }
    });
});
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(['jquery', 'jquery.lazyload.min','domReady!'], function ($) {
    if (typeof $.fn.lazyload !== 'undefined') {
        $('img.lazy').lazyload({
            failurelimit: 8,
        });

        $("[data-bg]").lazyload({
            effect: "fadeIn",
            appear: function () {
                $(this).css("background-image", "url('" + $(this).data("bg") + "')");
            }
        });
    }
});
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_PageBuilder/js/widget-initializer": {
                "config": {"[data-content-type=\"slider\"][data-appearance=\"default\"]":{"Magento_PageBuilder\/js\/content-type\/slider\/appearance\/default\/widget":false},"[data-content-type=\"map\"]":{"Magento_PageBuilder\/js\/content-type\/map\/appearance\/default\/widget":false},"[data-content-type=\"row\"]":{"Magento_PageBuilder\/js\/content-type\/row\/appearance\/default\/widget":false},"[data-content-type=\"tabs\"]":{"Magento_PageBuilder\/js\/content-type\/tabs\/appearance\/default\/widget":false},"[data-content-type=\"slide\"]":{"Magento_PageBuilder\/js\/content-type\/slide\/appearance\/default\/widget":{"buttonSelector":".pagebuilder-slide-button","showOverlay":"hover","dataRole":"slide"}},"[data-content-type=\"banner\"]":{"Magento_PageBuilder\/js\/content-type\/banner\/appearance\/default\/widget":{"buttonSelector":".pagebuilder-banner-button","showOverlay":"hover","dataRole":"banner"}},"[data-content-type=\"buttons\"]":{"Magento_PageBuilder\/js\/content-type\/buttons\/appearance\/inline\/widget":false},"[data-content-type=\"products\"][data-appearance=\"carousel\"]":{"Amasty_Xsearch\/js\/content-type\/products\/appearance\/carousel\/widget-override":false}},
                "breakpoints": {"desktop":{"label":"Desktop","stage":true,"default":true,"class":"desktop-switcher","icon":"Magento_PageBuilder::css\/images\/switcher\/switcher-desktop.svg","conditions":{"min-width":"1024px"},"options":{"products":{"default":{"slidesToShow":"5"}}}},"tablet":{"conditions":{"max-width":"1024px","min-width":"768px"},"options":{"products":{"default":{"slidesToShow":"4"},"continuous":{"slidesToShow":"3"}}}},"mobile":{"label":"Mobile","stage":true,"class":"mobile-switcher","icon":"Magento_PageBuilder::css\/images\/switcher\/switcher-mobile.svg","media":"only screen and (max-width: 768px)","conditions":{"max-width":"768px","min-width":"640px"},"options":{"products":{"default":{"slidesToShow":"3"}}}},"mobile-small":{"conditions":{"max-width":"640px"},"options":{"products":{"default":{"slidesToShow":"2"},"continuous":{"slidesToShow":"1"}}}}}            }
        }
    }
</script>
<script type="text&#x2F;javascript">document.querySelector("#cookie-status").style.display = "none";</script>
<script type="text/x-magento-init">
    {
        "*": {
            "cookieStatus": {}
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "mage/cookies": {
                "expires": null,
                "path": "\u002F",
                "domain": ".www.costway.de",
                "secure": false,
                "lifetime": "604800"
            }
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">    require.config({
        map: {
            '*': {
                wysiwygAdapter: 'mage/adminhtml/wysiwyg/tiny_mce/tinymce5Adapter'
            }
        }
    });</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require.config({
        paths: {
            googleMaps: 'https\u003A\u002F\u002Fmaps.googleapis.com\u002Fmaps\u002Fapi\u002Fjs\u003Fv\u003D3\u0026key\u003D'
        },
        config: {
            'Magento_PageBuilder/js/utils/map': {
                style: ''
            },
            'Magento_PageBuilder/js/content-type/map/preview': {
                apiKey: '',
                apiKeyErrorMessage: 'You\u0020must\u0020provide\u0020a\u0020valid\u0020\u003Ca\u0020href\u003D\u0027https\u003A\u002F\u002Fwww.costway.de\u002Fadminhtml\u002Fsystem_config\u002Fedit\u002Fsection\u002Fcms\u002F\u0023cms_pagebuilder\u0027\u0020target\u003D\u0027_blank\u0027\u003EGoogle\u0020Maps\u0020API\u0020key\u003C\u002Fa\u003E\u0020to\u0020use\u0020a\u0020map.'
            },
            'Magento_PageBuilder/js/form/element/map': {
                apiKey: '',
                apiKeyErrorMessage: 'You\u0020must\u0020provide\u0020a\u0020valid\u0020\u003Ca\u0020href\u003D\u0027https\u003A\u002F\u002Fwww.costway.de\u002Fadminhtml\u002Fsystem_config\u002Fedit\u002Fsection\u002Fcms\u002F\u0023cms_pagebuilder\u0027\u0020target\u003D\u0027_blank\u0027\u003EGoogle\u0020Maps\u0020API\u0020key\u003C\u002Fa\u003E\u0020to\u0020use\u0020a\u0020map.'
            },
        }
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require.config({
        shim: {
            'Magento_PageBuilder/js/utils/map': {
                deps: ['googleMaps']
            }
        }
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery', 'mage/cookies'], function($,cookies) {
        //注册
        if($.mage.cookies.get('onceCostwayTrackingRegister')){
            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push({
                'event': 'register_success',
                'method': 'joinfreebtn'
            });
            console.log('register_success! ' + 'joinfreebtn');
        }
        //订阅
        if($.mage.cookies.get('NewsletterSubscriberSuccessType')){
            var method = $.mage.cookies.get('NewsletterSubscriberSuccessType');
            var email = $.mage.cookies.get('NewsletterSubscriberSuccessEmail');
            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push({
                'event' : 'subs_success',
                'method': method,
                'email' : email
            });
            console.log('newsletter_success! ' + method);
            //清除cookie
            $.mage.cookies.clear('NewsletterSubscriberSuccessType');
        }
   });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    var country_code = 'US';
    function getLocalStorageItem(key, defaultValue = '') {
        return localStorage.getItem(key) || defaultValue;
    }
    var customer_email = "" ? "" : getLocalStorageItem('subscriber_email');
    var customer_id = "" ? "" : getLocalStorageItem('subscriber_customer_id');
    var md5_email = "";

    // Block Firday 
    var blockFirdayServerTime = "2026-05-18 02:03:43";
    function isServerTimeInRange(serverTimeString) {
        const startTimeString = '2024-10-21 00:00:00';
        const endTimeString = '2024-12-09 02:59:59';
        const serverTime = new Date(serverTimeString).getTime();
        const startTime = new Date(startTimeString).getTime();
        const endTime = new Date(endTimeString).getTime();
        return serverTime >= startTime && serverTime <= endTime;
    }
    // Block Firday end
    
    //安装数据埋点库
    window.customGlobalParams = {
        email: '' ? '' : getLocalStorageItem('subscriber_email'),
        customerId:'' ? '' : getLocalStorageItem('subscriber_customer_id'),
        quoteId:''
    }; 
    var _isLogin =0; //判断是否登陆            
    if(_isLogin){
        localStorage.removeItem('subscriber_email')
        localStorage.removeItem('subscriber_customer_id')
    }

    require(['jquery', 'mage/cookies'], function($,cookies) {
        $(document).ready(function() {
            //登陆 + 注册
            if($.mage.cookies.get('onceCostwayTrackingLogin') || $.mage.cookies.get('onceCostwayTrackingRegister')){
                window.dataLayer = window.dataLayer || [];
                dataLayer.push({
                    "event": "login",
                    "customer_id": customer_id,
                    "customer_email": customer_email
                });
                console.log('login success!');
            }
            //  登录事件
            if($.mage.cookies.get('onceCostwayTrackingLogin')){
                var source = $.mage.cookies.get('loginEntrypoint') ? $.mage.cookies.get('loginEntrypoint') : 'default';
                window.trackCustomEvent('login', {"email":customer_email, "source": source});
                $.mage.cookies.clear('onceCostwayTrackingLogin');
                if ($.mage.cookies.get('loginEntrypoint')) {
                    $.mage.cookies.clear('loginEntrypoint');
                }
            }

            //  注册订阅事件
            if($.mage.cookies.get('onceCTRegisterSubscriber')){
                window.trackCustomEvent('subscription_for_login', {"email":customer_email})
                $.mage.cookies.clear('onceCTRegisterSubscriber');
            }

            //  注册事件
            if($.mage.cookies.get('onceCostwayTrackingRegister')){
                var source = $.mage.cookies.get('registerEntrypoint') ? $.mage.cookies.get('registerEntrypoint') : 'default';
                window.trackCustomEvent('registered', {"email":customer_email, "source": source});
                $.mage.cookies.clear('onceCostwayTrackingRegister');
                if ($.mage.cookies.get('registerEntrypoint')) {
                    $.mage.cookies.clear('registerEntrypoint');
                }
            }

            //  个人中心订阅事件 点击update保存手机订阅
            const sms_subscription_save_val = $.mage.cookies.get('sms_save_status');
            if(sms_subscription_save_val){
                const sms_subscription_save = sms_subscription_save_val === "1" ? "success_true" : 'success_false';
                window.trackCustomEvent('sms_subscription_save', {"data":sms_subscription_save});
                $.mage.cookies.clear('sms_save_status');
            }

            //  个人中心订阅事件 点击update保存邮件订阅
            const email_subscription_save_val = $.mage.cookies.get('subscriber_save_status');
            if(email_subscription_save_val){
                const email_subscription_save = email_subscription_save_val === "1" ? "success_true" : 'success_false';
                window.trackCustomEvent('email_subscription_save', {"data":email_subscription_save});
                $.mage.cookies.clear('subscriber_save_status');
            }

            //  个人中心订阅事件 提交手机号后的接口返回
            const customer_phone_save_status_val = $.mage.cookies.get('customer_phone_save_status');
            if(customer_phone_save_status_val){
                const customer_phone_save_status = customer_phone_save_status_val === "1" ? "submit_success" : 'submit_fail';
                window.trackCustomEvent('phone_submit_result', {"data":customer_phone_save_status});
                $.mage.cookies.clear('customer_phone_save_status');
            }

            if (typeof ScarabQueue !== 'undefined' && ScarabQueue.push) {               
                if(customer_id){
                    ScarabQueue.push(["setCustomerId", `DE_${customer_id}`]);
                    ScarabQueue.push(['go']);                       
                }
            }
            
            // 登陆/退出后清除邮箱
            if(window._isLogin){
                 document.cookie = 'global_subscribe_email=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=' + window.location.hostname;
            }else{
                document.cookie = 'logged_subscribe_email=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=' + window.location.hostname;
            }
        })

        window.addEventListener('beforeunload', function (event) {
            $.mage.cookies.clear('onceCostwayTrackingLogin');
            $.mage.cookies.clear('onceCTRegisterSubscriber');
        });       

        //部署RTB代码
        (rtbhEvents = window.rtbhEvents || []).push(
        {
            eventType: 'placebo'
        },
        {
            eventType: 'uid',
            id: md5_email
        });
    })   
</script>
<script type="text/x-magento-init">
{"[data-role=compare-products-link]": {"Magento_Ui/js/core/app": {"components":{"compareProducts":{"component":"Magento_Catalog\/js\/view\/compare-products"}}}}}
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Ui/js/core/app": {
                "components": {
                    "customer": {
                        "component": "Magento_Customer/js/view/customer"
                    }
                }
            }
        }
    }
    </script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Ui/js/core/app": {
                "components": {
                    "wishlist": {
                        "component": "Magento_Wishlist/js/view/wishlist"
                    }
                }
            }
        }
    }

</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        window.checkout = {"shoppingCartUrl":"https:\/\/www.costway.de\/checkout\/cart\/","checkoutUrl":"https:\/\/www.costway.de\/checkout\/","updateItemQtyUrl":"https:\/\/www.costway.de\/checkout\/sidebar\/updateItemQty\/","removeItemUrl":"https:\/\/www.costway.de\/checkout\/sidebar\/removeItem\/","imageTemplate":"Magento_Catalog\/product\/image_with_borders","baseUrl":"https:\/\/www.costway.de\/","minicartMaxItemsVisible":5,"websiteId":"1","maxItemsToDisplay":10,"storeId":"1","storeGroupId":"1","customerLoginUrl":"https:\/\/www.costway.de\/customer\/account\/login\/referer\/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%2C%2C\/","isRedirectRequired":false,"autocomplete":"off","captcha":{"user_login":{"isCaseSensitive":false,"imageHeight":50,"imageSrc":"","refreshUrl":"https:\/\/www.costway.de\/captcha\/refresh\/","isRequired":false,"timestamp":1779062623}}};
    </script>
<script type="text/x-magento-init">
    {
        "[data-block='minicart']": {
            "Magento_Ui/js/core/app": {"components":{"minicart_content":{"children":{"subtotal.container":{"children":{"subtotal":{"children":{"subtotal.totals":{"config":{"display_cart_subtotal_incl_tax":0,"display_cart_subtotal_excl_tax":1,"template":"Magento_Tax\/checkout\/minicart\/subtotal\/totals"},"children":{"subtotal.totals.msrp":{"component":"Magento_Msrp\/js\/view\/checkout\/minicart\/subtotal\/totals","config":{"displayArea":"minicart-subtotal-hidden","template":"Magento_Msrp\/checkout\/minicart\/subtotal\/totals"}}},"component":"Magento_Tax\/js\/view\/checkout\/minicart\/subtotal\/totals"}},"component":"uiComponent","config":{"template":"Magento_Checkout\/minicart\/subtotal"}}},"component":"uiComponent","config":{"displayArea":"subtotalContainer"}},"item.renderer":{"component":"Magento_Checkout\/js\/view\/cart-item-renderer","config":{"displayArea":"defaultRenderer","template":"Magento_Checkout\/minicart\/item\/default"},"children":{"item.image":{"component":"Magento_Catalog\/js\/view\/image","config":{"template":"Magento_Catalog\/product\/image","displayArea":"itemImage"}},"checkout.cart.item.price.sidebar":{"component":"uiComponent","config":{"template":"Magento_Checkout\/minicart\/item\/price","displayArea":"priceSidebar"}}}},"extra_info":{"component":"uiComponent","config":{"displayArea":"extraInfo"}},"promotion":{"component":"uiComponent","config":{"displayArea":"promotion"}}},"config":{"itemRenderer":{"default":"defaultRenderer","simple":"defaultRenderer","virtual":"defaultRenderer"},"template":"Magento_Checkout\/minicart\/content"},"component":"Magento_Checkout\/js\/view\/minicart"}},"types":[]}        },
        "*": {
            "Magento_Ui/js/block-loader": "https://www.costway.de/static/version1778723978/frontend/default/hooya/de_DE/images/loader-1.gif"
        }
    }
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require([
        'Amasty_Xsearch/js/form-mini',
    ], function (autoComplete, searchClick) {
        'use strict';
        window.xsearch_options = {"url":"https:\/\/www.costway.de\/amasty_xsearch\/autocomplete\/index\/","isDynamicWidth":true,"isProductBlockEnabled":true,"width":900,"minChars":2,"currentUrlEncoded":"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,"};
    })
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "amastyXsearchAnalyticsCollector": {}
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(['jquery','swiper.min'], function($, Swiper) {
    $(document).ready(function() {

        var $headerWidget = $('.header-widget:visible'); // 只选择可见的 header-widget
        if ($headerWidget.length) {
            var headerAdWidget = new Swiper($headerWidget[0], {
                direction: 'vertical',
                wrapperClass : 'header-lb',
                slideClass : 'slide-item',
                loop: ($headerWidget.find('.slide-item').length > 1),
                speed: 600,
                slidesPerView: 1,
                spaceBetween: 0,
                mousewheel: false,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                pagination:false,
                navigation:false,
                lazy: {
                    loadPrevNext: true,  // 预加载前后图片
                    loadOnTransitionStart: true // 确保切换时加载
                }             
            });           

            // 鼠标移入时停止自动播放
            $headerWidget.mouseenter(function() {
                headerAdWidget.autoplay.stop();
            });

            // 鼠标移出时重新开始自动播放
            $headerWidget.mouseleave(function() {
                headerAdWidget.autoplay.start();
            });
        }
    })
})
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
 require(['jquery', 'domReady!'], function ($) {
    var pullCmpConsentView = false; // 是否已经触发过 cmp_consent_view 事件
    var eventDelegationBound = false; // 事件委托是否已绑定
   
    
    // 在 shadowRoot 上使用事件委托处理所有点击事件
    function bindEventDelegation(shadowRoot) {
        if (eventDelegationBound) return;
        
        shadowRoot.addEventListener('click', (event) => {
            const target = event.target;
            
                       
            // 「接受全部」按钮
            if (target.id === 'cmpwelcomebtnyes' || target.closest('#cmpwelcomebtnyes')) {
                console.log('点击「接受全部」');
                window.trackCustomEvent("cmp_consent_accept");
                return;
            }
            
            // 「拒绝全部」按钮
            if (target.id === 'cmpwelcomebtnno' || target.closest('#cmpwelcomebtnno')) {
                console.log('点击「拒绝全部」');
                window.trackCustomEvent("cmp_consent_reject");
                return;
            }
            
            // 「保存并退出」按钮
            if (target.id === 'cmpwelcomebtnsave' || target.closest('#cmpwelcomebtnsave')) {
                console.log('点击「保存并退出」',getCustomizeCategories());
                window.trackCustomEvent("cmp_consent_save&exit", {                  
                    "consent_categories": getCustomizeCategories()
                });
                return;
            }
            
            // 「设置/自定义」按钮 
            if (target.id === 'cmpcustomchoiceslink' ||  target.closest('#cmpcustomchoiceslink') || target.classList.contains('cmptxt_btn_custom') || target.closest('.cmptxt_btn_custom') || target.classList.contains('cmptxt_btn_settings') || target.closest('.cmptxt_btn_settings')) {
                console.log('点击「设置/自定义」按钮');
                window.trackCustomEvent("cmp_consent_customize");
                return;
            }
            
            // 自定义页面的「保存并退出」按钮
            if (target.classList.contains('cmptxt_btn_save') || 
                target.closest('.cmptxt_btn_save')) {
                console.log('自定义 点击「保存并退出」',getCustomizeCategories());
                window.trackCustomEvent("cmp_consent_saved", {                  
                    "consent_categories": getCustomizeCategories()
                });
                return;
            }
            
            // 自定义页面的「接受全部」按钮
            if (target.classList.contains('cmptxt_btn_yes') || 
                target.closest('.cmptxt_btn_yes')) {
                console.log('自定义 点击「接受全部」');
                window.trackCustomEvent("cmp_consent_accept", {
                    "from": "customize"
                });
                return;
            }           


        }, true); // 使用捕获阶段，确保能捕获到所有点击
        
        eventDelegationBound = true;
    }

    // 获取自定义类别的选择状态
    function getCustomizeCategories(){
      if(window.cmpmngr && window.cmpmngr.purposes){
            const purposes = window.cmpmngr.purposes.reduce((acc, purpose) => {
              const key = purpose.nameTrans.toLowerCase();
                // consentStatus 为 1 表示 true，0 表示 false
                acc[key] = purpose.consentStatus === 1;
                return acc;
              }, {});
            return purposes;
      } else{
        return {};
      }
    }
    
    // 处理 shadowRoot 内部的内容
    function handleShadowRootContent(cmpwrapper) {
        const shadowRoot = cmpwrapper.shadowRoot;
        if (!shadowRoot) return;
        
        console.log('shadowRoot 已经挂载到 #cmpwrapper');
        const cmpbox = shadowRoot.querySelector('#cmpbox');
        if (!cmpbox || cmpbox.style.display === 'none') {
            // 隐私弹窗关闭后，重置变量，等待下次打开
            pullCmpConsentView = true;
        }
        
        // 绑定事件委托（只绑定一次）
        bindEventDelegation(shadowRoot);
        
        // 显示隐私弹窗事件（只触发一次）
        if (pullCmpConsentView === false) {
            console.log('隐私弹窗展示');
            window.trackCustomEvent("cmp_consent_view");
            pullCmpConsentView = true;
        }
    }
    
    // 观察 #cmpwrapper 元素内部变化
    function observeCmpWrapper(cmpwrapper) {
        const cmpwrapperObserver = new MutationObserver((mutations) => {
            if (cmpwrapper.shadowRoot) {
                handleShadowRootContent(cmpwrapper);
            }
        });       
       
        cmpwrapperObserver.observe(cmpwrapper, {
            attributes: true,
            childList: true,
            subtree: true
        });

        if (cmpwrapper.shadowRoot) {
            handleShadowRootContent(cmpwrapper);
        }
    }
    
    // 查找 #cmpwrapper 元素
    const cmpwrapper = document.querySelector('#cmpwrapper');
    
    if (cmpwrapper) {
        observeCmpWrapper(cmpwrapper);
    } else {
        const bodyObserver = new MutationObserver((mutations) => {
            const cmpwrapper = document.querySelector('#cmpwrapper');
            if (cmpwrapper) {
                bodyObserver.disconnect();
                observeCmpWrapper(cmpwrapper);
            }
        });
        
        bodyObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }    
});
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(['jquery', 'toastr', 'domReady!'], function ($, toastr) {
    var heiwuEnd = 1;    
    var toastrOptions = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "3000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    
    const $html = $('html');
    const _hashtag = heiwuEnd ? '#CostwayFinds##Costwayde' : '#COSTWAYBLACKFRIDAY';

    var isMobile = $(window).width() <= 750;
    let isFirstShare = false;
    
    // 生成分享模态框HTML --------------------------------------
    function generateShareModal(shareData,isHasShare) {
        const baseImages = shareData.base_images || [];
        const imagesHtml = generateProductImages(baseImages);

        const html = heiwuEnd ? `
            <div class="bfth-share-modal heiwu-end ${isHasShare ? 'no-first-share' : ''} active">
            <div class="bfth-share-modal-main">
                <button class="bfth-share-modal-close" id="bfthShareCloseBtn">
                    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20.1936 0C19.9801 9.72748e-05 19.7754 0.0849991 19.6244 0.236034L0.235752 19.6258C0.161008 19.7006 0.101718 19.7893 0.0612674 19.887C0.0208171 19.9846 -1.47302e-06 20.0893 0 20.195C1.47317e-06 20.3007 0.0208231 20.4054 0.0612762 20.5031C0.101729 20.6007 0.161022 20.6895 0.235768 20.7642C0.310514 20.839 0.39925 20.8983 0.496909 20.9387C0.594569 20.9792 0.699239 21 0.804945 21C0.91065 21 1.01532 20.9792 1.11298 20.9387C1.21064 20.8983 1.29937 20.839 1.37411 20.7642L20.7645 1.37278C20.8757 1.25967 20.9511 1.11628 20.9813 0.960526C21.0115 0.804773 20.9952 0.643574 20.9342 0.49708C20.8733 0.350588 20.7706 0.225304 20.6389 0.136892C20.5071 0.048481 20.3523 0.000865936 20.1936 0Z" fill="white" />
                        <path d="M0.807946 7.62939e-06C0.648242 -0.000709534 0.49194 0.0461464 0.358953 0.134607C0.225967 0.223068 0.122317 0.349129 0.0612086 0.496729C0.000100562 0.644327 -0.0156987 0.806786 0.0158236 0.963398C0.0473459 1.12001 0.124763 1.26369 0.23821 1.37614L19.6475 20.7899C19.8008 20.9295 20.002 21.0047 20.2093 20.9998C20.4165 20.9948 20.6139 20.9102 20.7604 20.7634C20.9069 20.6167 20.9913 20.4191 20.9959 20.2117C21.0005 20.0044 20.9251 19.8032 20.7852 19.6501L1.37768 0.236334C1.30293 0.161383 1.21413 0.101927 1.11636 0.0613728C1.01859 0.0208187 0.913785 -3.43323e-05 0.807946 7.62939e-06Z" fill="white" />
                    </svg>
                </button>
                <div class="bfth-share-modal-cen">
                    <h3>Teilen und 400 Prämienpunkte gewinnen</h3>
                    <p>Freunde bestellen → 15 % Cashback erhalten</p>
                    <div class="bfth-sm-product-item ${shareData.items > 1 ? "even": ""}">
                        <h4><h4>Hab’s bei <strong>Costway!</strong></h4></h4>
                        <div class="bfth-sm-product-images">
                            ${imagesHtml}
                        </div>
                        <div class="bfth-sm-product-info">
                            <div><span>Bestellnummer : </span><span>${shareData.increment_id}</span></div>
                            <div><span>${shareData.items} ${shareData.items > 1 ? " Artikeln :" : " Artikel :"}
                            </span><span>${shareData.grand_total}</span></div>
                        </div>
                    </div>
                    <div class="bfth-sm-bottom-box">
                        <button class="bfth-sm-download-btn" id="bfthSmDownloadBtn">Poster herunterladen</button>
                        <button class="bfth-sm-share-btn" id="bfthSmShareBtn">Teilen</button>
                    </div>
                </div>
            </div>
        </div>
        
        ` : `
        <div class="bfth-share-modal ${isHasShare ? 'no-first-share' : ''} active">
            <div class="bfth-share-modal-main">
                <button class="bfth-share-modal-close" id="bfthShareCloseBtn">
                    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20.1936 0C19.9801 9.72748e-05 19.7754 0.0849991 19.6244 0.236034L0.235752 19.6258C0.161008 19.7006 0.101718 19.7893 0.0612674 19.887C0.0208171 19.9846 -1.47302e-06 20.0893 0 20.195C1.47317e-06 20.3007 0.0208231 20.4054 0.0612762 20.5031C0.101729 20.6007 0.161022 20.6895 0.235768 20.7642C0.310514 20.839 0.39925 20.8983 0.496909 20.9387C0.594569 20.9792 0.699239 21 0.804945 21C0.91065 21 1.01532 20.9792 1.11298 20.9387C1.21064 20.8983 1.29937 20.839 1.37411 20.7642L20.7645 1.37278C20.8757 1.25967 20.9511 1.11628 20.9813 0.960526C21.0115 0.804773 20.9952 0.643574 20.9342 0.49708C20.8733 0.350588 20.7706 0.225304 20.6389 0.136892C20.5071 0.048481 20.3523 0.000865936 20.1936 0Z" fill="white" />
                        <path d="M0.807946 7.62939e-06C0.648242 -0.000709534 0.49194 0.0461464 0.358953 0.134607C0.225967 0.223068 0.122317 0.349129 0.0612086 0.496729C0.000100562 0.644327 -0.0156987 0.806786 0.0158236 0.963398C0.0473459 1.12001 0.124763 1.26369 0.23821 1.37614L19.6475 20.7899C19.8008 20.9295 20.002 21.0047 20.2093 20.9998C20.4165 20.9948 20.6139 20.9102 20.7604 20.7634C20.9069 20.6167 20.9913 20.4191 20.9959 20.2117C21.0005 20.0044 20.9251 19.8032 20.7852 19.6501L1.37768 0.236334C1.30293 0.161383 1.21413 0.101927 1.11636 0.0613728C1.01859 0.0208187 0.913785 -3.43323e-05 0.807946 7.62939e-06Z" fill="white" />
                    </svg>
                </button>
                <div class="bfth-share-modal-cen">
                    <h3>Teilen und 400 Fackelteile gewinnen</h3>
                    <p>Freunde werben und <strong>15 %</strong> Cashback erhalten</p>
                    <div class="bfth-sm-product-item ${shareData.items > 1 ? "even": ""}">
                        <h4>Hab’s bei <strong>Costway !</strong></h4>
                        <div class="bfth-sm-product-images">
                            ${imagesHtml}
                        </div>
                        <div class="bfth-sm-product-info">
                            <div><span>Bestellnummer : </span><span>${shareData.increment_id}</span></div>
                            <div><span>${shareData.items} ${shareData.items > 1 ? " Artikeln :" : " Artikel :"}
                            </span><span>${shareData.grand_total}</span></div>
                        </div>
                    </div>
                    <div class="bfth-sm-bottom-box">
                        <button class="bfth-sm-download-btn" id="bfthSmDownloadBtn">Poster herunterladen</button>
                        <button class="bfth-sm-share-btn" id="bfthSmShareBtn">Teilen</button>
                    </div>
                </div>
            </div>
        </div>
    `;

        return html;
    }

    // 生成产品图片HTML
    function generateProductImages(baseImages) {
        // if (!baseImages || baseImages.length === 0) {
        //     return '<img src="./pub/images/torch-hunt/p1.png" alt="">';
        // }

        // 只有一张图时，不显示更多图片容器
        if (baseImages.length === 1) {
            return `<img src="${baseImages[0]}" alt="">`;
        }

        // 多张图片的处理
        const mainImage = `<img src="${baseImages[0]}" alt="">`;

        // 确定何时显示"..."

        const showNum =  $(window).width() <= 750 ? 4 :  6
        const showMoreDots = baseImages.length > showNum;

        // 生成更多图片项
        let moreItemsHtml = '';
        for (let i = 1; i < showNum ; i++) {
            moreItemsHtml += `<div class="bfth-sm-product-more-item"><img src="${baseImages[i]}" alt=""></div>`;
        }

        if (showMoreDots) {
            moreItemsHtml += '<div class="bfth-sm-product-more-item">...</div>';
        }

        return `
        ${mainImage}
        <div class="bfth-sm-product-more-img" >
            ${moreItemsHtml}
        </div>
    `;
    }

    // 绑定事件
    function bindShareEvents(shareData, orderId,obj) {
        // 关闭按钮
        $(document).on('click', '#bfthShareCloseBtn', function () {
            $('.bfth-share-modal').remove();
             if(isMobile){
                $html[0].style.setProperty('overflow', '');
             }
        });

        // 下载poster按钮
        $(document).on('click', '#bfthSmDownloadBtn', function () {
            handleShareButton("bfthSmDownloadBtn",shareData, orderId,obj);            
        });


        // 分享按钮
        $(document).on('click', '#bfthSmShareBtn', function () {
           handleShareButton("bfthSmShareBtn",shareData, orderId,obj);
        });
    }
    function setShareTextTitle(shareData){
        let text = '';
        if(heiwuEnd){
            text = "Hab’s bei Costway—Heim-Updates ganz einfach und günstig.";
        }else{
            text = shareData.items > 1 ? "Hab’s bei Costway – Black Friday Preise sind der Wahnsinn! Mehr Hammer-Deals warten!" : "Hab’s bei Costway – Black Friday Preise sind der Wahnsinn! Mehr Hammer-Deals warten!";
        }

        return text;
    }   

    // 移动端系统分享
    async function shareToSystemShare(shareData) {
        try {
            if (!navigator.share) {
                 toastr['warning']("Dein Browser unterstützt die Freigabe-Funktion nicht.", '', toastrOptions);
                return ;
            }
           
            const imageUrl = shareData.poster_image;
                // 请求图片为 blob
            const response = await fetch(imageUrl);
            const blob = await response.blob();

            // 从 URL 提取文件名
            const fileName = imageUrl.split('/').pop();
            const $name = heiwuEnd ? "Hab’s bei Costway—Heim-Updates ganz einfach und günstig.png" : "Hab’s bei Costway – Black Friday Preise sind der Wahnsinn! Mehr Hammer-Deals warten.png";
            const file = new File([blob],$name, { type: blob.type });
            // 检查浏览器是否支持 share(files)
            if (navigator.canShare && navigator.canShare({ files: [file] })) {
                await navigator.share({
                    title: setShareTextTitle(shareData) + _hashtag,
                    text: setShareTextTitle(shareData) + _hashtag,
                    files: [file],
                });
                
            } else {
                // 不支持文件时，只分享文字和链接
                await navigator.share({
                    title: setShareTextTitle(shareData) + _hashtag,
                    text: setShareTextTitle(shareData) + _hashtag,
                });
            }
        
            
            removeButtonTips();
            // toastr['success']("分享成功", '', toastrOptions);
            window.trackCustomEvent("bf_share_invoke", {
                type: "webshareapi",
                data: "success",
            });
        } catch (error) {
            console.error(error);
            if (error.name !== 'AbortError') {
                // toastr['error']("分享失败，请重试", '', toastrOptions);
            }
            window.trackCustomEvent("bf_share_invoke", {
                type: "webshareapi",
                data: "fail",
            });
        }
        showSharedTipsModal();
    }

    function removeButtonTips(){
        if(/^\/sales\/order\/history\/?$/.test(window.location.pathname)){
            $('.order-share').addClass("share")
        }
        $('.share-my-order-event').addClass("share")
    }

    function showSharedTipsModal(){
        let $title = "";
        let $text = "";
        let $submitBtn = "";
        if(heiwuEnd){
            $title ="Erfolgreich geteilt!";
            $text = isFirstShare ? `<p class="text"><span class="t1">Du hast für dieses Teilen </span><span class="t2"><img class="points" src="https://cdn1.costway.de/public/blackfriday/torch-hunt/points-icon.png" alt="" ><span class="color">400</span><span  class="t1"> Prämienpunkte erhalten.</span></span></p>` : "";
            $submitBtn = "OK";
        }else{
            $title = "Erfolgreich geteilt!";
            $text = isFirstShare ? `<p class="text"><span class="t1">Du hast </span><span class="t2"><img class="fire" src="https://cdn1.costway.de/public/blackfriday/torch-hunt/fire-icon.png" alt="" ><span class="color">400</span><span  class="t1"> Fackelteile für dieses Teilen erhalten.</span></span></p>` : "";
            $submitBtn = "OK";
        }
        // 弹窗 HTML 代码
        const popupHTML = `
        <div class="hooya-modal-wrapper shared-success-modal show" id="shared-success-modal">
            <div class="hooya-modal-content">      
                <div class="shared-success-modal-cen">    
                    <div class="icon">
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="20" cy="20" r="20" fill="#0BC063"/>
                        <path d="M9.41406 20.5878L16.809 27.0584L28.2376 14.1172" stroke="white" stroke-width="3.52941"/>
                        </svg>
                    </div>
                    <h4 class="title">${$title}</h4>
                    ${$text}
                    <button class="ok-button" type="button">${$submitBtn}</button>
                </div>
            </div>
        </div>
        `;
        $('.bfth-share-modal').remove();
        // 将弹窗插入页面
        $('body').append(popupHTML);
        $html[0].style.setProperty('overflow', 'hidden', 'important');

        // 绑定表单提交事件
        $('#shared-success-modal .ok-button').on('click', function (e) {
            e.preventDefault(); // 阻止默认提交行为
            $html[0].style.setProperty('overflow', '');
            $('#shared-success-modal').remove();
        });
    }

    // PC端Facebook分享
    function shareToFacebook(shareData,orderId) {
        const dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : window.screenX;
        const dualScreenTop = window.screenTop !== undefined ? window.screenTop : window.screenY;
        const w= 800,h=500;
        const width = window.innerWidth || document.documentElement.clientWidth || screen.width;
        const height = window.innerHeight || document.documentElement.clientHeight || screen.height;

        const left = (width - w) / 2 + dualScreenLeft;
        const top = (height - h) / 2 + dualScreenTop;

        const _href = window.location.origin + `/activity/order/shareview/incrementid-${orderId}/source-${isMobile ? "mb" : "pc"}`;// 分享中间页面
        const shareUrl =
            `https://www.facebook.com/dialog/share` +
            `?app_id=348494614492027` +
            `&display=popup` +
            `&href=${encodeURIComponent(_href)}` +
            `&redirect_uri=${encodeURIComponent(_href)}`;
          
        const fbSharePopup =  window.open(
            shareUrl,
            'fbShareWindow',
            `width=${w},height=${h},top=${top},left=${left},scrollbars=yes,resizable=yes`
        );

        const timer = setInterval(() => {
            if (fbSharePopup.closed) {
                clearInterval(timer);
                showSharedTipsModal();            
            }
        }, 500);
        
         window.trackCustomEvent("bf_share_invoke",{
                "type":"facebook",
                "data":"success"
        });

    }
    /**
     * 获取是否成功分享
     */
     function handleShareButton(buttonType,shareData, orderId,obj){
        const buttonObj = $("#" + buttonType);
        $.ajax({
            url: '/rest/V1/hooya/activity/share',
            type: 'POST',
            contentType: 'application/json',
            beforeSend: function () {
                obj.prop("disabled", true);
                buttonObj.prop("disabled", true);
            },
            data: JSON.stringify({
                incrementId: orderId
            }),
            dataType: 'json',
            success: function (response) {
                if (response.success ) {
                    if(buttonType === "bfthSmDownloadBtn"){
                            const posterImage = shareData.poster_image;
                            if (!posterImage) {
                                console.error("海报为空")
                                // toastr['warning']("海报暂时不可用", '', toastrOptions);
                                return;
                            }
                            const fileName = posterImage.split('/').pop();
                            // 创建隐藏的a标签用于下载
                            const link = document.createElement('a');
                            link.href = posterImage;
                            link.download = fileName;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            // 下载海报
                            window.trackCustomEvent("bf_poster_download");
                            // 显示成功提示
                            if(!heiwuEnd){
                                toastr['success']("Bestellposter gespeichert.", '', toastrOptions);
                            }else{  
                                toastr['success']("Share-Poster gespeichert.", '', toastrOptions);
                            }
                    }
                    
                    if(buttonType === "bfthSmShareBtn"){
                        // 判断是否为移动端
                        if (isMobile) {
                            // 移动端：调用系统自带分享功能
                          shareToSystemShare(shareData,orderId);
                        } else {
                            // PC端：保留现有Facebook分享逻辑
                            shareToFacebook(shareData,orderId);
                        }
                    }                   
                    if(!heiwuEnd){
                        try {
                            window.getBfthTorchDetails();
                        } catch (error) {
                            console.error("火炬详情接口请求失败");
                        }
                    }
                    removeButtonTips()

                } else {                   
                    // toastr['error']("获取数据失败", '', toastrOptions);
                    window.trackCustomEvent("bf_share_invoke",{
                        "type":"facebook",
                        "data":"fail"
                    });
                }
                obj.prop("disabled", false);
                buttonObj.prop("disabled", false);
            },
            error: function (xhr, status, error) {
                obj.prop("disabled", false);
                buttonObj.prop("disabled", false);
                // toastr['error']("请求失败", '', toastrOptions);
                window.trackCustomEvent("bf_share_invoke",{
                    "type":"facebook",
                    "data":"fail"
                });
            }
        });
    }

    // POST请求获取分享数据
    function requestShareData(orderId, obj) {
        if (!orderId) return;
        $.ajax({
            url: '/rest/V1/hooya/activity/share-info',
            type: 'POST',
            contentType: 'application/json',
            beforeSend: function () {
                obj.prop("disabled", true);
            },
            data: JSON.stringify({
                incrementId: orderId
            }),
            dataType: 'json',
            success: function (response) {
                if (response.success && response.share_data) {
                    const shareData = response.share_data;                  

                    // 生成HTML模态框
                    const html = generateShareModal(shareData,obj.hasClass("share"));
                    // 移除旧的模态框和事件监听
                    $('.bfth-share-modal').remove();
                    $(document).off('click', '#bfthShareCloseBtn');
                    $(document).off('click', '#bfthSmDownloadBtn');
                    $(document).off('click', '#bfthSmShareBtn');
                    // 插入到body最后面
                    $('body').append(html);                    
                    
                    // 显示模态框
                    $('.bfth-share-modal').addClass('active');
                    if(isMobile){
                        $html[0].style.setProperty('overflow', 'hidden', 'important');
                    }                   
                    
                    obj.prop("disabled", false);
                    // 绑定事件
                    bindShareEvents(shareData, orderId,obj);

                    // 结算成功页、我的订单页 Share 按钮曝光
                    
                    window.trackCustomEvent("bf_share_cta_click",{
                        "location":obj.data("location"),
                        "data":obj.hasClass("share") ? "first_share_false":"first_share_true",
                        "data1": shareData.poster_image ? "poster_template_success":"poster_template_fail"
                    })

                } else {
                    obj.prop("disabled", false);
                    console.error("获取share-info数据失败");
                    
                    // toastr['error']("获取数据失败", '', toastrOptions);
                }
            },
            error: function (xhr, status, error) {
                obj.prop("disabled", false);
                console.error("获取share-info数据失败");
                // toastr['error']("请求失败", '', toastrOptions);
            }
        });
    }

    function showOrderLogInPopup(orderId, btnObj) {
        const t1 = heiwuEnd ? `<span class="t1">Melde dich an, um </span><span class="t2"><img src="https://cdn1.costway.com/media/blackfriday/torch-hunt/points-icon.png" alt="" ><span class="color">400</span> <span> Prämienpunkte zu erhalten.</span></span>` :`<span class="t1">Melde dich an, um </span><span class="t2"><img src="https://cdn1.costway.de/public/blackfriday/torch-hunt/fire-icon.png" alt="" ><span class="color">400</span> <span> Fackelteile zu erhalten.</span></span>`;
        const btnText_1 = heiwuEnd ? "Anmelden & 400 Prämienpunkte erhalten " :"Anmelden & 400 Teile erhalten";
        const btnText_2 = "Ohne Anmeldung teilen";
        // 弹窗 HTML 代码
        const popupHTML = `<div class="hooya-modal-wrapper log-in-modal show" id="log-in-modal">
    <div class="hooya-modal-content">
        <button class="close-btn">
            <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M20.1936 0C19.9801 9.72748e-05 19.7754 0.0849991 19.6244 0.236034L0.235752 19.6258C0.161008 19.7006 0.101718 19.7893 0.0612674 19.887C0.0208171 19.9846 -1.47302e-06 20.0893 0 20.195C1.47317e-06 20.3007 0.0208231 20.4054 0.0612762 20.5031C0.101729 20.6007 0.161022 20.6895 0.235768 20.7642C0.310514 20.839 0.39925 20.8983 0.496909 20.9387C0.594569 20.9792 0.699239 21 0.804945 21C0.91065 21 1.01532 20.9792 1.11298 20.9387C1.21064 20.8983 1.29937 20.839 1.37411 20.7642L20.7645 1.37278C20.8757 1.25967 20.9511 1.11628 20.9813 0.960526C21.0115 0.804773 20.9952 0.643574 20.9342 0.49708C20.8733 0.350588 20.7706 0.225304 20.6389 0.136892C20.5071 0.048481 20.3523 0.000865936 20.1936 0Z"
                    fill="white" />
                <path
                    d="M0.807946 7.62939e-06C0.648242 -0.000709534 0.49194 0.0461464 0.358953 0.134607C0.225967 0.223068 0.122317 0.349129 0.0612086 0.496729C0.000100562 0.644327 -0.0156987 0.806786 0.0158236 0.963398C0.0473459 1.12001 0.124763 1.26369 0.23821 1.37614L19.6475 20.7899C19.8008 20.9295 20.002 21.0047 20.2093 20.9998C20.4165 20.9948 20.6139 20.9102 20.7604 20.7634C20.9069 20.6167 20.9913 20.4191 20.9959 20.2117C21.0005 20.0044 20.9251 19.8032 20.7852 19.6501L1.37768 0.236334C1.30293 0.161383 1.21413 0.101927 1.11636 0.0613728C1.01859 0.0208187 0.913785 -3.43323e-05 0.807946 7.62939e-06Z"
                    fill="white" />
            </svg>
        </button>
        <div class="log-in-modal-cen">           
           <p class="des">${t1}</p>
            <button class="log-in-button" type="button">${btnText_1}</button>
            <button class="share-button" type="button">${btnText_2}</button>
        </div>
    </div>
</div>
    `;

        // 将弹窗插入页面
        $('body').append(popupHTML);
        $html[0].style.setProperty('overflow', 'hidden', 'important');

        
        $('#log-in-modal .close-btn').on('click', function (e) {
            e.preventDefault(); 
            $html[0].style.setProperty('overflow', '');
            $('#log-in-modal').remove();
        });

        $('#log-in-modal .log-in-button').on('click', function (e) {
            e.preventDefault(); 
            if (typeof window.trackCustomEvent === 'function') {
                window.trackCustomEvent("guest_share_popup_cta_click", {
                    "data": "login_get_400 "
                });
            }
            $(this).prop("disabled", true);
            $('#log-in-modal').remove();
             window.location.href = '/sales/order/history/?entrypoint=success-share-my-order';
        });


        $('#log-in-modal .share-button').on('click', function (e) {
            e.preventDefault();
            if (typeof window.trackCustomEvent === 'function') {
                window.trackCustomEvent("guest_share_popup_cta_click", {
                    "data": "share_without_login"
                });
            }
            $(this).prop("disabled", true);
            $('#log-in-modal').remove();
            requestShareData(orderId, btnObj);
        });
    }

    $(".share-my-order-event").on("click", function () {
        const orderId = $(this).data("orderid");
        isFirstShare = $(this).hasClass("share") ? false : true;
        if($(this).data("location") === "pay_result" &&  !window._isLogin){
            // window.location.href = '/sales/order/history/?entrypoint=success-share-my-order';
            showOrderLogInPopup(orderId, $(this));
        }else{
            requestShareData(orderId, $(this));
        }
    })
})
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Ui/js/core/app": {
                "components": {
                        "messages": {
                            "component": "Magento_Theme/js/view/messages"
                        }
                    }
                }
            }
    }
</script>
<script type="text/x-magento-init">
    {
        "[data-gallery-role=gallery-placeholder]": {
            "mage/gallery/gallery": {
                "mixins":["magnifier/magnify"],
                "magnifierOpts": {"fullscreenzoom":"5","top":"","left":"","width":"","height":"","eventType":"hover","enabled":false},
                "data": [{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","caption":"Costway 180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","position":"0","isMain":false,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_6_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_6_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_6_.jpg","caption":"Verschneiter beleuchteter weihnachtsbaum","position":"1","isMain":false,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_2_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_2_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_2_.jpg","caption":"180 cm K\u00fcnstlicher Weihnachtsbaum ","position":"2","isMain":true,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_9_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_9_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_9_.jpg","caption":"Abmessungen des k\u00fcnstlichen Weihnachtsbaums","position":"3","isMain":false,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_7_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_7_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_7_.jpg","caption":"K\u00fcnstlicher Weihnachtsbaum f\u00fcr Weinachten","position":"4","isMain":false,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_4_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_4_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_4_.jpg","caption":"Weihnachtsbaum f\u00fcr innen- und au\u00dfendekoration mit Lichtern","position":"5","isMain":false,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_8_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_8_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_8_.jpg","caption":"Weihnachtsbaum mit LED Lichtern und Metallst\u00e4nder","position":"6","isMain":false,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_5_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_5_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_5_.jpg","caption":"Dichter bunter warmer Weihnachtsbaum","position":"7","isMain":false,"type":"image","videoUrl":null},{"thumb":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/6f1ab9f67d44f735dd0ae0cbc143343f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_3_.jpg","img":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/c4db9a9c74edf330d39d62982732ede8\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_3_.jpg","full":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/82774a4bfaf4b86ed41de9a5b2b8663f\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_3_.jpg","caption":"180cm Klappbarer weihnachtsbaum","position":"8","isMain":false,"type":"image","videoUrl":null}],
                "options": {"nav":"thumbs","loop":true,"keyboard":true,"arrows":true,"allowfullscreen":true,"showCaption":false,"width":711,"thumbwidth":120,"thumbheight":106,"height":627,"transitionduration":500,"transition":"slide","navarrows":true,"navtype":"slides","navdir":"horizontal"},
                "fullscreen": {"nav":"thumbs","loop":true,"navdir":"horizontal","navarrows":false,"navtype":"slides","arrows":false,"showCaption":false,"transitionduration":500,"transition":"dissolve","keyboard":true},
                 "breakpoints": {"mobile":{"conditions":{"max-width":"767px"},"options":{"options":{"nav":"dots","navigation":"dots"}}}}            }
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "[data-gallery-role=gallery-placeholder]": {
            "Magento_ProductVideo/js/fotorama-add-video-events": {
                "videoData": [{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":true},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false}],
                "videoSettings": [{"playIfBase":"0","showRelated":"0","videoAutoRestart":"0"}],
                "optionsVideoData": []            }
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery'], function ($) {
        $('.share-title').on('click', function() {
            $('.mask-share').show();
            $('.product-reward-points-share').addClass('show');
        })
    })
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "productCoupons": {}
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery'], function ($) {
        var p_w = $(window).width();
        $('.coupon-promotion .get-now').on('click', function() {
            window.trackCustomEvent('product_coupon_list_btn', {});
            $('.prodetail-coupons-wrapper, .prodetail-coupons-wrapper .cmpboxBG').show();
            if (p_w >= 767) {
                $(".prodetail-coupons-main").animate({right:'0'});
            } else {
                $(".prodetail-coupons-main").animate({bottom: '0'});
            }
        })
        $('.svg-box.copy-box').on('click', function() {
            var text = $(this).siblings('.code-tips').text();
            window.trackCustomEvent("product_coupon_code_btn", { "code": text });
            var oInput = document.createElement('input');
            oInput.value = text;
            document.body.appendChild(oInput);
            oInput.select();
            document.execCommand("Copy");
            oInput.className = 'oInput';
            oInput.style.display = 'none';
            document.body.removeChild(oInput);
            document.execCommand("copy");
            $(this).hide().siblings('.copied-box').attr('style', 'display: inline-block;');
            $('.code-tips').addClass('copied');
            setTimeout(() => {
                $('.copied-box').hide().siblings(this).show();
                $('.code-tips').removeClass('copied');
            }, 5000);
        })
    });
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "earlyBirdPolicy": {}
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(['jquery','clipboard.min'], function($,ClipboardJS) {
        $(document).ready(function() {
            // 复制CODE
            var clipboardTimer;

            $('#md-spike-product').on('click',function(){

                const self = $(this);

                if(self.hasClass("clipboard")) return;
                
                self.addClass("clipboard");
                const clipboard = new ClipboardJS('#md-spike-product',{
                    text: function(trigger) {
                        return trigger.getAttribute('data-code');
                    }
                });
                clipboard.on('success', function(e) {
                    if(e.text !=''){
                        $('#md-spike-product .code-col').addClass('active');
                        
                        clipboardTimer = setTimeout(() => {
                            $('#md-spike-product .code-col').removeClass('active');
                            self.removeClass("clipboard");
                            clearTimeout(clipboardTimer);
                        }, 6000);
                    }
                    e.clearSelection();
                });

                clipboard.on('error', function(e) {
                    console.log('text:', e.text);
                });

            })

            $('#md-spike-product-12').on('click',function(){

                const self = $(this);

                if(self.hasClass("clipboard")) return;
                
                self.addClass("clipboard");
                const clipboard = new ClipboardJS('#md-spike-product-12',{
                    text: function(trigger) {
                        return trigger.getAttribute('data-code');
                    }
                });
                clipboard.on('success', function(e) {
                    if(e.text !=''){
                        $('#md-spike-product-12 .code-col').addClass('active');
                        
                        clipboardTimer = setTimeout(() => {
                            $('#md-spike-product-12 .code-col').removeClass('active');
                            self.removeClass("clipboard");
                            clearTimeout(clipboardTimer);
                        }, 6000);
                    }
                    e.clearSelection();
                });

                clipboard.on('error', function(e) {
                    console.log('text:', e.text);
                });

            })

        });
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery','Magento_Checkout/js/model/postcode-validator',], function($,postCodeValidator){
        $(document).ready(function() {
            const $formSection = $('#formSection');
            const $expandArrow = $('#expandArrow');
            const $zipInput = $('#zipCode');
            const $updateBtn = $('#updateBtn');
            const $errorMessage = $('#errorMessage');
            const $deliveryDate = $('#deliveryDate');
            const $currentAddress = $('#currentAddress');
            const patterns = {
                "DE":{
                    "pattern_1": {
                        "example": "12345",
                        "pattern": "^[0-9]{5}$"
                    }
                }
            }
            // 表单展开/收起状态
            let isExpanded = false;            

            // 验证邮编格式
            function isValidZipCode(zip) {
                return postCodeValidator.validate(zip, 'DE',patterns);;
            }

            // 显示错误消息
            function showErrorMessage(message) {
                $errorMessage.text(message).fadeIn();
                // setTimeout(() => $errorMessage.fadeOut(), 3000);
            }
           
            function updateShippingInfo(zipCode) {
                const sku = $('input[name="sku"]').val();
                $.ajax({
                    url: '/api/ajax/getarrivaltime',
                    type: 'GET',
                    cache: false,
                    dataType: 'json',
                    data: {
                        "sku": sku,
                        "postcode":zipCode
                    },
                    beforeSend() {                        
                        $updateBtn.prepend('<span class="ant-btn-loading-icon"><span role="img" aria-label="loading" class="anticon anticon-loading anticon-spin"><svg focusable="false" data-icon="loading" width="1em" height="1em" fill="currentColor" aria-hidden="true" viewBox="0 0 1024 1024"><path d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 00-94.3-139.9 437.71 437.71 0 00-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z"></path></svg></span></span>')
                    },
                    success(response) {
                        if(response.code === 200){
                            response.arrival_text && $deliveryDate.text(response.arrival_text);
                            response.zip_city && $currentAddress.text(response.zip_city);
                        }else{
                            showErrorMessage(response.message)
                        }
                    },
                    error(response) {
                        showErrorMessage(response.message)
                    },
                    complete() {
                        // 清空输入框
                        $zipInput.val('');
                        $updateBtn.prop('disabled', false)
                        $updateBtn.find('.ant-btn-loading-icon').remove();
                    }
                });
            }

            // 切换表单展开/收起状态
            function toggleForm() {
                isExpanded = !isExpanded;
                
                if (isExpanded) {
                    $formSection.addClass('expanded');
                    $expandArrow.addClass('expanded');
                } else {
                    $formSection.removeClass('expanded');
                    $expandArrow.removeClass('expanded');
                    // 收起时清空消息
                    $errorMessage.hide();
                }
            }        
            
            $expandArrow.on('click', function(e) {
                toggleForm();
            });
            $currentAddress.on('click', function(e) {
                toggleForm();
            });

            // Update按钮点击事件
            $updateBtn.on('click', function() {
                const zipCode = $zipInput.val().trim();
                
                if (!zipCode) {
                    showErrorMessage('Dies ist ein Pflichtfeld.');
                    $zipInput.focus();
                    return;
                }

                if (!isValidZipCode(zipCode)) {
                    showErrorMessage('Die eingegebene Postleitzahl ist ungültig. Bitte geben Sie eine gültige PLZ ein. Zum Beispiel: 12345.');
                    $zipInput.focus();
                    return;
                }

                // 禁用按钮并显示加载状态
                $updateBtn.prop('disabled', true);

                $errorMessage.hide();
                updateShippingInfo(zipCode)                    
            });

            // 输入框回车键支持
            $zipInput.on('keypress', function(e) {
                if (e.which === 13) {
                    $updateBtn.click();
                }
            });

            // 邮编输入格式化
            // $zipInput.on('input', function() {
            //     let value = $(this).val();
            //     value = value.toUpperCase();
            //     $(this).val(value);
            // });
            function isMobile() {
                return window.matchMedia("(max-width: 767px)").matches;
            }
            // info图标悬停提示（移除点击事件，使用CSS悬停效果）
            $('.info-icon').on('click', function(e) {
                e.stopPropagation();
                if(isMobile()){
                    $('.delivers-tooltip').addClass('show')
                }                
            });

            $('#got-it').on('click', function(e) {                               
                e.stopPropagation(); 
                $(this).closest('.delivers-tooltip').removeClass('show');            
            });
        });
    })
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery'], function($) {
        $(document).ready(function() {
            
            var pdp_swatch_opt = $('.pdp-swatch-opt');
            var options = {
                optionClass: 'swatch-option',
                attributeClass: 'swatch-attribute',
                attributeSelectedOptionLabelClass: 'swatch-attribute-selected-option'
            };
            // 添加鼠标移入移出事件处理
            pdp_swatch_opt.on('mouseenter', '.' + options.optionClass, function() {
                var $this = $(this);
                var $parent = $this.parents('.' + options.attributeClass);
                var $label = $parent.find('.' + options.attributeSelectedOptionLabelClass);
                
                // 保存当前选中的label
                $this.data('label', $label.text());
                
                // 显示鼠标移入选项的label
                $label.text($this.attr('label'));
            });

            pdp_swatch_opt.on('mouseleave', '.' + options.optionClass, function() {
                var $this = $(this);
                var $parent = $this.parents('.' + options.attributeClass);
                var $label = $parent.find('.' + options.attributeSelectedOptionLabelClass);
                
                // 恢复显示之前保存的label
                var originalLabel = $this.data('label');
                if (originalLabel) {
                    $label.text(originalLabel);
                }
            });

            $('.pdp-swatch-opt a').on('click',  function(e) {
                const title = $(this).data('title') || ""; 
                const sku = $(this).data('sku') || ""; 
                const url = $(this).attr('href') || ""; 
                
                // 执行跟踪事件
                window.trackCustomEvent("pdp", { 
                    name: title, 
                    url: url, 
                    sku: sku
                });
                
                // 不阻止默认行为，允许继续跳转
               
            });

        });
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        require([
            'jquery',
            'mage/mage',
            'Magento_Catalog/product/view/validation',
            'Magento_Catalog/js/catalog-add-to-cart'
        ], function ($) {
            'use strict';

            // if(!$('body').hasClass('page-product-configurable') && $('input[name="oos"]').val() !== "0"){
            //     if($(window).width()>750){
            //         $('#product-addtocart-button').attr('disabled',false).removeClass('disabled');
            //     }else{
            //         $("#add-to-cart-button").attr('disabled', false);
            //     }
            // }

            $('#product_addtocart_form').mage('validation', {
                radioCheckboxClosest: '.nested',
                submitHandler: function (form) {
                    if(!$('body').hasClass('page-product-configurable')){
                        var widget = $(form).catalogAddToCart({
                            bindSubmit: false
                        });
                        widget.catalogAddToCart('disableAddToCartButton',$(form));
                        widget.catalogAddToCart('submitForm', $(form));
                    }
                    /**********2021-5-12--google跟踪代码(zdj)---start************/
                    var is_Configurable = 0;
                    var name    = "180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern";
                    if (is_Configurable == 1){
                        //配置产品
                        var sku = $('#product_addtocart_form input[name="sku"]').val();
                        var variant = $('.swatch-option.selected').attr('option-label');
var price = document.querySelector('.price-wrapper[data-price-type="finalPrice"]')?.getAttribute('data-price-amount');
                        price = price ? parseFloat(price.replace(',', '.')) : null;                    }else{
                        //简单产品
                        var sku     = "CM23511DE";
                        var variant = "";
                        var price   = 96.99;
                    }
                    var qty     = $('input[name="qty"]').val();
                    //双属性的延迟请求到数据后再推送
                    var is_shuangsuxing = 0;
                    if (is_Configurable == 1 && is_shuangsuxing >= 2){
                        var url = "/hooyacatalog/index/getmultiattribute";
                        var variant_1 = $('.swatch-option.selected.image').attr('option-id');
                        var variant_2 = $('.swatch-option.selected.text').attr('option-id');
                        var variant_3 = $('.swatch-option.selected.color').attr('option-id');
                        var variant_4 = $('.swatch-select').find("option:selected").attr('option-id');
                        $.ajax({
                            url: url,
                            data: {
                                product_id: 4961,
                                attr1: Number(variant_1) || '',
                                attr2: Number(variant_2) || '',
                                attr3: Number(variant_3) || '',
                                attr4: Number(variant_4) || ''
                            },
                            type: 'GET',
                            cache: false,
                            dataType: 'json',
                            context: this,
                            /**
                             * Response handler
                             * @param {Object} response
                             */
                            success: function (response) {
                                if (response.result == 200){
                                    variant = response.variant;
                                    sku = response.sku;
                                    price = response.price;
                                }else{
                                    console.log(response)
                                }
                                //添加加购埋点
                                window.trackCustomEvent("addToCart", { "suk": sku, "qty": qty })
                                window.dataLayer = window.dataLayer || [];
                                dataLayer.push({
                                    "event": "addToCart",
                                    "ecommerce": {
                                        // "currencyCode": "USD",
                                        "add": {
                                            "products": [
                                                {
                                                    "id": sku,
                                                    "name": name,
                                                    "category": "Deko",
                                                    "variant": variant,
                                                    "price": price,
                                                    "quantity": qty
                                                }
                                            ]
                                        }
                                    },
                                    "add_to_cart_ga4_items": [
                                        {
                                            "item_id": sku,
                                            "item_name":name,
                                            "item_category": "Deko",
                                            "item_category2": "Festtags-Dekoartikel",
                                            "item_category3": "Weihnachten",
                                            "item_category4": "Weihnachtsbäume",
                                            "item_variant": variant,
                                            "price": price,
                                            "itemgroup_id" :"CM23511DE",
                                            "quantity": qty
                                        }
                                    ],
                                    'criteo_item':[
                                        {
                                            "id": sku,
                                            "price": price,
                                            "quantity": qty
                                        }
                                    ],
                                    'value': 96.99,
                                    'items' : [{
                                        'id': "CM23511DE",
                                        'google_business_vertical': 'retail'
                                    }]
                                });
                                // console.log(window.dataLayer)
                                console.log('add_to_cart success1')
                                /**********2021-5-12--google跟踪代码(zdj)---end************/
                            }
                        });
                        /**  2022年6月14日  迁移GTM**/
                    }else{
                        //添加加购埋点
                        window.trackCustomEvent("addToCart", { "suk": sku, "qty": qty })
                        /**  2022年6月14日  迁移GTM**/
                        window.dataLayer = window.dataLayer || [];
                        dataLayer.push({
                            "event": "addToCart",
                            "ecommerce": {
                                // "currencyCode": "USD",
                                "add": {
                                    "products": [
                                        {
                                            "id": sku,
                                            "name": name,
                                            "category": "Deko",
                                            "variant": variant,
                                            "price": price,
                                            "quantity": qty
                                        }
                                    ]
                                }
                            },
                            "add_to_cart_ga4_items": [
                                {
                                    "item_id": sku,
                                    "item_name":name,
                                    "item_category": "Deko",
                                    "item_category2": "Festtags-Dekoartikel",
                                    "item_category3": "Weihnachten",
                                    "item_category4": "Weihnachtsbäume",
                                    "item_variant": variant,
                                    "price": price,
                                    "itemgroup_id" :"CM23511DE",
                                    "quantity": qty
                                }
                            ],
                            'criteo_item':[
                                {
                                    "id": sku,
                                    "price": price,
                                    "quantity": qty
                                }
                            ],
                            'value': 96.99,
                            'items' : [{
                                'id': "CM23511DE",
                                'google_business_vertical': 'retail'
                            }]
                        });
                        // console.log(window.dataLayer)
                        console.log('add_to_cart success2')
                        /**********2021-5-12--google跟踪代码(zdj)---end************/
                    }
                    //部署RTB代码                        
                   
                    var md5_email = "unknown";
                    
                    (rtbhEvents = window.rtbhEvents || []).push(
                    {
                        eventType: 'basketadd',
                        offerId: sku
                    },
                    {
                        eventType: 'uid',
                        id: md5_email
                    });                    
                    return false;
                }
            });
        });
        

    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    var md5_email = "unknown";

    (rtbhEvents = window.rtbhEvents || []).push(
    {
        eventType: 'offer',
        offerId: 'CM23511DE'
    },
    {
        eventType: 'uid',
        id: md5_email
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        /**  2022年6月14日  迁移GTM**/
        window.dataLayer.push({
            "event": "viewItem",
            "ecommerce": {
                "detail": {
                    "products": [{"id":"CM23511DE","name":"180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","category":"Deko","variant":"","price":"96.99"}]                },

            },
            "ga4items": [{"item_id":"CM23511DE","item_name":"180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","item_category":"Deko","item_category2":"Festtags-Dekoartikel","item_category3":"Weihnachten","item_category4":"Weihnachtsb\u00e4ume","item_variant":"","price":"96.99","itemgroup_id":"CM23511DE"}],
            'value': 96.99,
            "items":[
                {
                    "id":  "CM23511DE",
                    'google_business_vertical': 'retail'
                }
            ]
        });

        // console.log(window.dataLayer)
        console.log('viewItem success')
    </script>
<script type="text/x-magento-init">
            {
                "body": {
                    "addToWishlist": {"productType":"simple"}                }
            }
        </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        require([
            'jquery',
        ], function(jQuery){
            (function($) {
                $(document).ready(function(){
                    if($(window).width() <= 750 && $("body").hasClass('catalog-product-view')){
                        if(!$("body").hasClass('page-product-configurable')){
                            if($('#bottom-to-cart').find('.product-addto-links').length === 0){
                                $('.product-addto-links').eq(0).appendTo('.product-addto-links-box');
                            }
                        }else{
                            $('#bottom-to-cart').find('.product-addto-links').remove();
                            $('.product-addto-links').eq(0).appendTo('.product-addto-links-box');
                        }                        
                    }
                    $('.product-info-main').append('<div class="towishlist-tips"></div>')
                    var toWishIconObj='.product-info-main .towishlist';
                    const toWishTipsObj = $('.product-info-main .towishlist-tips');
                    var _removeItem = [];
                    var wishlistSubmitParams = "{\"action\":\"https:\\\/\\\/www.costway.de\\\/wishlist\\\/index\\\/ajaxadd\\\/\",\"data\":{\"product\":4961,\"child_id\":\"4961\",\"uenc\":\"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,\"}}";
                    var parsedJson = Array.isArray(_removeItem) && _removeItem.length > 0
                        ? $.parseJSON(_removeItem[0])
                        : $.parseJSON(wishlistSubmitParams);
                        $(toWishIconObj).attr('item', JSON.stringify(parsedJson));
                    var timer ;
                    var url = location.search;
                    if (url.indexOf("?") != -1) {
                        var str = url.substr(1);
                        urlQuery = str.split("=");
                        if (urlQuery[1] === 'remove' && $(toWishIconObj).hasClass('successful')) {
                            clearTimeout(timer);
                            toWishTipsObj.html('Der Artikel wurde Ihrer <a href="/wishlist/">Wunschliste</a> hinzugefügt.').show(0);
                            toWishTipsObj.animate({top: '23.5%',opacity:1},400);
                            timer =  setTimeout(() => {
                                toWishTipsObj.animate({top: '20%',opacity:0}, 400);
                                toWishTipsObj.delay(1000).hide(0);
                            }, 4000);
                           
                        }
                    }

                    $(toWishIconObj).on('click', function () {
                        const self = $(this);
                        let currentWishItemStatus,newWishItemStatusObj ={};
                        const $swatchOpt = self.parents('.product-info-main').find('.swatch-opt');
                        if($swatchOpt.length > 0){
                             currentWishItemStatus = $swatchOpt.attr('data-wish-item-status');
                             if(currentWishItemStatus){
                                newWishItemStatusObj = JSON.parse(currentWishItemStatus)
                             }
                        }
                        toWishTipsObj.removeClass('show');
                        var toWishIocnAttrItem = JSON.parse(self.attr('item'));
                        if (self.hasClass('successful')){//判断已收藏的class是否存在，存在就走移除收藏。不存在，则添加收藏
                            formKey = $('input[name="form_key"]').val();
                            const dataObj = {
                                form_key   : formKey,
                                item       : toWishIocnAttrItem.data.item,
                                uenc       : toWishIocnAttrItem.data.uenc
                            }
                            $.ajax({
                                url: toWishIocnAttrItem.action,
                                data: dataObj,
                                type: 'POST',
                                async:false,
                                dataType : "json",
                                beforeSend: function (xhr) {
                                    xhr.setRequestHeader( "Test", "testheadervalue");
                                },
                                success: function(data){
                                    if (data.success == true) {
                                        clearTimeout(timer);
                                        const addToWishAction = JSON.parse(data.addParam);
                                        self.attr('item',JSON.stringify(addToWishAction));
                                        if( newWishItemStatusObj && typeof newWishItemStatusObj === 'object' && JSON.stringify(newWishItemStatusObj) !== '{}' ){
                                            delete newWishItemStatusObj[addToWishAction.data.child_id.toString()];
                                            $swatchOpt.attr('data-wish-item-status', JSON.stringify(newWishItemStatusObj));
                                        }
                                        toWishTipsObj.html('Der Artikel wurde erfolgreich von der <a href="/wishlist/">Wunschliste</a> entfernt.').show(0);
                                        self.removeClass('successful');
                                        self.attr('title','Zur Wunschliste hinzufügen');
                                        toWishTipsObj.animate({top: '23.5%',opacity:1},400);
                                        timer =  setTimeout(() => {
                                            toWishTipsObj.animate({top: '20%',opacity:0},400);
                                            toWishTipsObj.delay(1000).hide(0);
                                        }, 4000);
                                    }
                                },
                                error: function (data) {
                                    console.info("error: " + data.responseText);
                                }
                            });
                        }else {
                            if(!window._isLogin){//判断是否客户登录
                                //点击收藏,记录用户操作
                                var Days = 1;
                                var exp = new Date();
                                exp.setTime(exp.getTime() + Days*24*60*60*1000);
                                document.cookie = "wishList="+ 4961 + ";expires=" + exp.toGMTString()+";  path=/";
                                window.location.href="https://www.costway.de/customer/account/login/referer/aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA%3D%3D/";
                                return;
                            }
                            var parsedJson = $swatchOpt.length > 0 ? JSON.parse($(this).attr('item')): $.parseJSON("{\"action\":\"https:\\\/\\\/www.costway.de\\\/wishlist\\\/index\\\/ajaxadd\\\/\",\"data\":{\"product\":4961,\"child_id\":\"4961\",\"uenc\":\"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,\"}}");
                            var url = parsedJson.action;
                            var data1 = parsedJson.data;
                            var current_prod = data1.product;
                            var current_uenc = data1.uenc;
                            formKey = $('input[name="form_key"]').val();
                            let dataObj = {
                                action   : "add-to-wishlist",
                                form_key : formKey,
                                product  : current_prod,
                                uenc     : current_uenc
                            }

                            // 如果登陆，复杂产品 ，存在child_id
                            if($swatchOpt.length > 0 && window._isLogin && data1.child_id){
                                dataObj.child_id = data1.child_id;
                            }

                            $.ajax({
                                url: url,
                                data: dataObj,
                                type: 'POST',
                                async:false,
                                dataType : "json",
                                beforeSend: function (xhr) {
                                    xhr.setRequestHeader( "Test", "testheadervalue");
                                },
                                success: function(data){
                                    if (data.success == true) {
                                        clearTimeout(timer);
                                        toWishTipsObj.html('Der Artikel wurde Ihrer <a href="/wishlist/">Wunschliste</a> hinzugefügt.').show(0);
                                        var itemNo = JSON.parse(data.removeParam);
                                        var wishlistQty = JSON.parse(data.wishlistQty);
                                        if($swatchOpt.length > 0){
                                            newWishItemStatusObj[data.child_id]= itemNo.data.item;
                                            $swatchOpt.attr('data-wish-item-status', JSON.stringify(newWishItemStatusObj));
                                        }
                                        if($('.header .wishlist .qty').length>0){
                                            $('.header .wishlist .qty').text(wishlistQty+' Artikel')
                                        }else{
                                            var _html='<a href="/wishlist/">Mi Lista de Deseos <!-- ko if: wishlist().counter --><span data-bind="text: wishlist().counter" class="counter qty">'+wishlistQty+' Artikel</span><!-- /ko --></a>'
                                            $('.header .wishlist').html(_html)
                                        }
                                        self.addClass('successful');
                                        self.attr('title','Von der Wunschliste entfernen');
                                        toWishTipsObj.attr('item',JSON.stringify(itemNo));
                                        toWishTipsObj.animate({top: '23.5%',opacity:1},400);
                                        timer = setTimeout(() => {
                                            toWishTipsObj.animate({top: '20%',opacity:0},400);
                                            toWishTipsObj.delay(1000).hide(0);
                                        }, 4000);

                                        //收藏事件
                                        const sku = $('#product_addtocart_form input[name="sku"]').val();
                                        window.trackCustomEvent("product_wishlist_btn", { "url": window.location.href, "sku": sku})
                                        //部署RTB代码
                                        var md5_email = "unknown";
                                        (rtbhEvents = window.rtbhEvents || []).push(
                                        {
                                            eventType: 'wishlist',
                                            offerId: sku
                                        },
                                        {
                                            eventType: 'uid',
                                            id: md5_email
                                        });
                                    }
                                },
                                error: function (data) {
                                    console.info("error: " + data.responseText);
                                }
                            });
                        }

                    });
                });
            })(jQuery);
        });
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require([
    'jquery',
], function($){

//<![CDATA[
    $.extend(true, $, {
        calendarConfig: {
            dayNames: ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"],
            dayNamesMin: ["So.","Mo.","Di.","Mi.","Do.","Fr.","Sa."],
            monthNames: ["Januar","Februar","M\u00e4rz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"],
            monthNamesShort: ["Jan.","Feb.","M\u00e4rz","Apr.","Mai","Juni","Juli","Aug.","Sept.","Okt.","Nov.","Dez."],
            infoTitle: 'About\u0020the\u0020calendar',
            firstDay: 0,
            closeText: 'Schlie\u00DFen',
            currentText: 'Go\u0020Today',
            prevText: 'Vorherige',
            nextText: 'Weiter',
            weekHeader: 'WK',
            timeText: 'Time',
            hourText: 'Hour',
            minuteText: 'Minute',
            dateFormat: "D, d M yy", // $.datepicker.RFC_2822
            showOn: 'button',
            showAnim: '',
            changeMonth: true,
            changeYear: true,
            buttonImageOnly: null,
            buttonImage: null,
            showButtonPanel: true,
            showWeek: true,
            timeFormat: '',
            showTime: false,
            showHour: false,
            showMinute: false
        }
    });

    enUS = {"m":{"wide":["January","February","March","April","May","June","July","August","September","October","November","December"],"abbr":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]}}; // en_US locale reference
//]]>

});</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery'], function($){
        if(!$("#add-to-cart-button").hasClass('no-js-click')){
            $("#add-to-cart-button").on('click',function(){
                $("#product_addtocart_form").submit();
            })
        }
    })

</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
  require(['jquery', 'Message'], function($){
    jQuery(document).ready(function() {
                                var html = `<div class="product-img">
                                                            <div class="img-row"> <a href="#" data-name="invite_friends_banner">                             <img class="pc" src="/media/advertising/d/e/de-pc-bf15_cashback.png" alt="freunde werben">
                            <img class="mb" src="/media/advertising/a/t/at-mb-bf15_cashback.png" alt="freunde werben">
                     </a></div>
                            </div>`;
            $.each($('.product-info-price'),function(index,item){
                if(!$(item).find('.product-img').length){
                    $(item).find('.price-box.price-final_price').before(html);
                }
            })
                
        if($('body').hasClass('page-product-configurable') && $('.amxnotif-block').eq(0).parent().attr('class') == 'product-info-main' ){
            $('.amxnotif-block').eq(0).remove()
        }
        var is_oos = 0;
        if(is_oos && $('body').hasClass('page-product-configurable') && $('.detail-coupon-wrap').eq(0).parent().attr('class') == 'product-info-main' ){
            $('.detail-coupon-wrap').eq(0).remove()
        }

        var notice = sessionStorage.getItem('out_of_stock_notice');
        if (notice) {
            setTimeout(function () {
                showSpring.shower(6, notice, 5000);
                sessionStorage.removeItem('out_of_stock_notice');
            }, 500);
        }
        // 简单产品
        if (typeof ScarabQueue !== 'undefined' && ScarabQueue.push && !$('body').hasClass('page-product-configurable')) {
            ScarabQueue.push(["view", "CM23511DE"]);
            ScarabQueue.push(['go']);
        }
     })

 })
</script>
<script type="text/x-magento-init">
    {
        "[data-role=priceBox][data-price-box=product-id-4961]": {
            "priceBox": {
                "priceConfig":  {"productId":"4961","priceFormat":{"pattern":"%s\u00a0\u20ac","precision":2,"requiredPrecision":2,"decimalSymbol":",","groupSymbol":".","groupLength":3,"integerRequired":false},"tierPrices":[]}            }
        }
    }
</script>
<script type="application/ld+json">
        {
          "@context": "http://schema.org/",
          "@type": "Product",
          "name": "180 cm Künstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern",
          "image": "https://www.costway.de/media/catalog/product/cache/bbfaed54adcd969869090b8940d0426e/k/_/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_2_.jpg",
          "description": "Für eine festliche Atmosphäre!",
          "sku": "CM23511DE",
          "gtin": "0661706101578",
          "brand": {
            "@type": "Brand",
            "name": "COSTWAY"
          },
          "review": {
            "@type": "Review",
            "reviewRating": {
              "@type": "Rating",
              "ratingValue": "4.8",
              "bestRating": "5"
            },
            "author": {
              "@type": "Person",
              "name": "Tanno"
            }
          },
                    "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "reviewCount": "3"
          },
                    "offers": {
            "@type": "Offer",
            "url": "https://www.costway.de/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html",
            "priceCurrency": "EUR",
            "price": "96.99",
            "priceValidUntil":"2026-12-31" ,
            "itemCondition": "NewCondition",
            "availability": "https://schema.org/OutOfStock",
            "shippingDetails": {
              "@type": "OfferShippingDetails",
              "shippingRate": {
                "@type": "MonetaryAmount",
                "value": 0,
                "currency": "EUR"
              },
              "shippingDestination": {
                "@type": "DefinedRegion",
                "addressCountry": "DE",
                "addressRegion": ["BE"]
              },
              "deliveryTime": {
                "@type": "ShippingDeliveryTime",
                "handlingTime": {
                  "@type": "QuantitativeValue",
                  "minValue": 0,
                  "maxValue": 1,
                  "unitCode": "DAY"
                },
                "transitTime": {
                  "@type": "QuantitativeValue",
                  "minValue": 2,
                  "maxValue": 5,
                  "unitCode": "DAY"
                }
              }
            },
            "hasMerchantReturnPolicy": {
              "@type": "MerchantReturnPolicy",
              "applicableCountry": "DE",
              "returnPolicyCategory": "https://schema.org/MerchantReturnFiniteReturnWindow",
              "merchantReturnDays": 30,
              "returnMethod": "https://schema.org/ReturnByMail",
              "returnFees": "https://schema.org/FreeReturn"
           }
          }
        }
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(['jquery','toastr', 'subscribeModal', 'mage/cookies'], function ($,toastr) { 
    $(document).ready(function() {
    
    const $childProductId = $('input[name="child_item"]').val();
    let oosProductTimeStatus = Object.values({"4961":{"productId":"4961","inOonDay":0,"subscribeStatus":0}});

    // 游客状态更新
    if(_isLogin){
        document.cookie = 'oos_subscribe_product=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=' + window.location.hostname;
    }else{
        handleCookieOosProduct();
    }

    var toastrOptions = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "3000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };

    function handleCookieOosProduct (){
        let gusetCustomerOosProduct =  getSubscribeProducts();
        if(gusetCustomerOosProduct && gusetCustomerOosProduct.length){
            // 创建映射
            const updateMap = {};
            gusetCustomerOosProduct.forEach(item => {
                updateMap[item.productId] = item;
            });

            // 批量更新
            oosProductTimeStatus.forEach(item => {
                const updateItem = updateMap[item.productId];
                if (updateItem) {
                    item.inOonDay = updateItem.inOonDay;
                    item.subscribeStatus = updateItem.subscribeStatus;
                }
            });
        }
    }

    const $t1 = "Bei Verfügbarkeit benachrichtigen";
    const $t2 = "Erfolgreich! Sie sind auf der Warteliste.";
    const str_1 = "Vielen Dank! Sie sind bereits für dieses Produkt angemeldet.";

    function findProductByProductId(productId) {
        return oosProductTimeStatus.find(item => String(item.productId) === productId);
    }


    if($('body').hasClass('page-product-configurable')){
        // 复杂产品

        const hiddenChildItemInput = document.querySelector('input[name="child_item"]');
        let productChildItem= hiddenChildItemInput.value; // 初始值

        // 创建MutationObserver实例
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'value') {
                    
                    setTimeout(() => {
                        handleCookieOosProduct();
                        productChildItem = hiddenChildItemInput.value;
                        // console.log('child_item值已更新为:', productChildItem);
                        const foundProductObjects = findProductByProductId(productChildItem);

                        if (foundProductObjects) {
                            // console.log("找到对象:", foundProductObjects);
                            // 如果有多个相同 product_id，可以用 foundObjects
                            if($(".oos-subscribe-button").length){
                                setOosButtonsStatus(foundProductObjects)
                            }else{
                                 let setOosButtonsStatusTimer =  setInterval(() => {
                                    if($(".oos-subscribe-button").length){
                                        clearInterval(setOosButtonsStatusTimer)
                                        setOosButtonsStatus(foundProductObjects);

                                    }
                                }, 500);
                            }
                        } else {
                            console.log("未找到product id");
                        }
                    }, 50);
                }
            });
        });

        // 开始观察元素
        observer.observe(hiddenChildItemInput, {
            attributes: true, // 监听属性变化
            attributeFilter: ['value'] // 只监听value属性变化
        });
    }else{
        const hiddenSimpleProductId = $('input[name="item"]').val();
        const simpleProductObjects = findProductByProductId(hiddenSimpleProductId);
        setOosButtonsStatus(simpleProductObjects)
    }




    function getSubscribeProducts() {
        var cookieName = 'oos_subscribe_product';
        var existingData = $.mage.cookies.get(cookieName);

        if (!existingData) {
            return [];
        }

        try {
            var productArray = JSON.parse(existingData);
            return Array.isArray(productArray) ? productArray: [];
        } catch (e) {
            console.error('解析 oos_subscribe_product cookie 数据失败:', e);
            return [];
        }
    }


    function setOosButtonsStatus(foundProductObjects){
        
        if(!foundProductObjects) return;
        $(".oos-subscribe-button").removeClass("success");
        $(".oos-subscribe-button").removeClass("already-subscribed");
        // 在一天内和已订阅
        if(foundProductObjects.inOonDay && foundProductObjects.subscribeStatus){
           $(".oos-subscribe-button").text($t2).addClass("success").show();
        }
        // 超过一天内和已订阅
        if(!foundProductObjects.inOonDay && foundProductObjects.subscribeStatus){
            $(".oos-subscribe-button").text($t1).show();
            $(".oos-subscribe-button").addClass("already-subscribed");
        }
        // 未订阅
        if(!foundProductObjects.subscribeStatus){
            $(".oos-subscribe-button").text($t1).show()
        }
        
        if(!window._isLogin){
            handleCookieOosProduct();
        }
    }

    $(document).on('click', ".oos-subscribe-button",function (e) {
        e.preventDefault();
        if($(this).hasClass("success")) return;
        
        try {
            
             const $subscribe_email = window._isLogin ? $.mage.cookies.get("logged_subscribe_email") : $.mage.cookies.get("global_subscribe_email");
            
            if($subscribe_email){
                // 登陆用户已订阅不弹窗，只提醒
                const parent_id = $("input[name='item']").val() || "";        
                const product_id = $("input[name='child_item']").val() || "";

                if(!parent_id || !product_id) {
                    return;
                }
                handleSubscribeUserRemind($subscribe_email,parent_id,product_id,$(this));
                
            }else{
                window.showSubscriptionModal('product_oos_subs_btn');
            }
        } catch (error) {
            if (typeof window.trackCustomEvent === 'function') {
                window.trackCustomEvent("oos_subscribe", {
                    "subscribe_popup": false
                });
            }
        }

    });

    function addOrUpdateSubscribeProduct(productData) {
       
        var cookieName = 'oos_subscribe_product';
        
        // 获取现有的 cookie 数据
        var existingData = $.cookie(cookieName);
        var productArray = [];
        
        // 如果 cookie 已存在，解析数据
        if (existingData) {
            try {
                productArray = JSON.parse(existingData);
                
                // 检查是否是数组，如果不是则重置
                if (!Array.isArray(productArray)) {
                    console.warn('Cookie 数据格式错误，重置为数组');
                    productArray = [];
                }
            } catch (e) {
                console.error('解析 cookie 数据失败:', e);
                productArray = [];
            }
        }
        
        // 检查 product_id 是否已存在
        var existingIndex = -1;
        for (var i = 0; i < productArray.length; i++) {
            if (productArray[i].productId === productData.productId) {
                existingIndex = i;
                break;
            }
        }
        
        // 如果存在不处理
        if (existingIndex !== -1) {
            return true;
            // // 更新现有产品信息
            // productArray[existingIndex] = productData;
            // console.log('更新了产品 ID:', productData.productId);
        } else {
            // 添加新产品
            productArray.push(productData); 
        }
        
        // 将更新后的数组保存回 cookie
        // 设置过期时间
        $.cookie(cookieName, JSON.stringify(productArray), { 
            expires: 1, 
            path: '/',
            domain : window.location.hostname
        });
        
        return true;
    }

    /** 
     * @param {string} parentId
     * @param {string} productId
     * @param {string} obj
     */
    function handleSubscribeUserRemind(email,parentId,productId,obj) {
        
        const $subscriberData = {
            email: email || "",
            type: "oos_subscribe",
            device: $(window).width() > 750 ? 'pc' : 'mb',
            parent_id:parentId,
            product_id:productId
        }
   
        $.ajax({
            url: '/newsletter/subscriber/new/',
            data: $subscriberData,
            type: 'POST',
            async: true,
            dataType: 'json',
            beforeSend() {
               obj.addClass('disabled');
               obj.prepend('<span class="ant-btn-loading-icon"><span role="img" aria-label="loading" class="anticon anticon-loading anticon-spin"><svg focusable="false" data-icon="loading" width="1em" height="1em" fill="currentColor" aria-hidden="true" viewBox="0 0 1024 1024"><path d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 00-94.3-139.9 437.71 437.71 0 00-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z"></path></svg></span></span>')
            },
            success(data) {                              
                if(data.code === 200){
                    toastr["success"](str_1, '', toastrOptions);
                    $(".oos-subscribe-button").text($t2).addClass("success").show();

                    // 状态写在cookie 1天过期
                    addOrUpdateSubscribeProduct({
                        "productId": $subscriberData.product_id ||  $subscriberData.parent_id,
                        "inOonDay": 1,
                        "subscribeStatus": 1
                    })
                }else{
                    toastr["error"](data.messages, '', toastrOptions);
                }
                obj.removeClass('disabled');
                if (typeof window.trackCustomEvent === 'function') {
                    window.trackCustomEvent("oos_subsribe_success", {
                        "subscribe_popup": false
                    });
                }
            },
            error(data) {
                toastr["error"](data.responseText, '', toastrOptions);
                obj.removeClass('disabled');
            }
        });
    }
   }) 
})
</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-7860");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-7860  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-3885");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-3885  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">var elemOPkxSsTL = document.querySelector('#rating-result_3885 span');
if (elemOPkxSsTL) {
elemOPkxSsTL.style.width = '95%';
}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-8977");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-8977  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-14026");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-14026  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-4113");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-4113  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">var elemqE98zgEz = document.querySelector('#rating-result_4113 span');
if (elemqE98zgEz) {
elemqE98zgEz.style.width = '100%';
}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-16640");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-16640  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
            require([
                "jquery",
                 "Amasty_Base/vendor/slick/slick.min",
                'jquery.lazyload.min',
            ], function ($) {
                if ($('body.account').length > 0) {
                    $('#amrelated-block-4 [data-amrelated-js="slider"]').slick(
                        {
                            dots:false,
                            infinite: false,
                            slidesToShow: 4,
                            slidesToScroll: 4,
                            variableWidth: true,
                            centerMode: false,
                            responsive: [
                                {
                                    breakpoint: 767,
                                    settings: {

                                        arrows:false,
                                        slidesToShow: 2,
                                        slidesToScroll: 2
                                    }
                                }
                            ]
                        }
                    );
                } else {
                    $('#amrelated-block-4 [data-amrelated-js="slider"]').slick(
                        {
                            dots:false,
                            infinite: false,
                            slidesToShow: 5,
                            slidesToScroll: 5,
                            variableWidth: true,
                            centerMode: false,

                            responsive: [
                                {
                                    breakpoint: 1280,
                                    settings: {
                                        slidesToShow: 4,
                                        slidesToScroll: 4
                                    }
                                },
                                {
                                    breakpoint: 767,
                                    settings: {

                                        arrows:false,
                                        slidesToShow: 2,
                                        slidesToScroll: 2
                                    }
                                },
                                // {
                                //     breakpoint: 425,
                                //     settings: {
                                //         slidesToShow: 1,
                                //         slidesToScroll: 1
                                //     }
                                // }
                            ]
                        }
                    );
                }
            $('#amrelated-block-4 [data-amrelated-js="slider"]').on("afterChange", function(event, slick, currentSlide){
                    if (typeof $.fn.lazyload !== 'undefined'){
                        $(window).trigger('scroll');
                    }
                });
            });
        </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require([
        'jquery',
        'Amasty_Mostviewed/js/mostviewed_analytics'
    ], function ($, analytics) {
        analytics(
            'https://www.costway.de/ammostviewed/analytics/view/',
            4,
            '#amrelated-block-4',
            null,
            'https://www.costway.de/ammostviewed/analytics/click/'
        );
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
            function reviewLogin(){
                var islogin = 0;
                if (islogin != true){
                    window.location.href='/customer/account/login'
                }else{
                    window.location.href='#review-form'
                }
            }
        </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
                require(['jquery', 'swiper.min', 'Magento_Ui/js/modal/modal'], function ($, Swiper, modal) {
                    let _pw = $(window).width();
                    let $image = document.querySelector('.custom-image-preview-img');
                    let imagesEle = $('.click_product_image');
                    let reviewImagesIndex = 0;
                    let lastIndex = imagesEle.length - 1;
                    var listVanSwiper;
                    const isVideo = /\.(avi|rm|ram|rmvb|mpeg|mpg|dat|mov|qt|asf|wmv|swf|flv|mp4|3gq)$/i;
                    $(".click_product_image").on('click', function () {
                        let imgList = $(this).closest('.review-media-value').next('.review_images').html();
                        imgList = JSON.parse(imgList);
                        imgList = imgList.map(function(element) {
                            if (element.indexOf("http") !== -1) {
                                return element;
                            } else {
                                return `/media/review_images${element}`;
                            }
                        });
                        if (imgList.length !== 0) {
                            localStorage.setItem('reviewImages', imgList);
                        }
                        $('body').css({'overflow-y': 'hidden', 'width': 'calc(100% - 17px)'});
                        if (_pw < 1000) {
                            let index = $(this).parent().index();
                            let $swiperSlide = '';
                            $.each(imgList, function(i, value) {
                                if (isVideo.test(value)) {
                                    $swiperSlide = $('<div class="swiper-slide">').append(`<video autoplay muted controls src="${value}" onerror="this.src='${value}';this.onerror=null;;" alt="Video">${value}</video>`);
                                } else {
                                    $swiperSlide = $('<div class="swiper-slide">').append('<img src="' + value + '" alt="">');
                                }
                                $('.mb-hooya-swiper-container-review .swiper-wrapper').append($swiperSlide);
                            });
                            $('.mb-hooya-overlay-review, .mb-hooya-image-preview-review').show();
                            listVanSwiper = new Swiper('.mb-hooya-swiper-container-review', {
                                pagination: {
                                    el: '.swiper-pagination',
                                    type: 'fraction',
                                }
                            });
                            listVanSwiper.slideTo(index, 0);
                        } else {
                            $('.custom-image-preview-switch-left, .custom-image-preview-switch-right').removeClass('custom-image-preview-switch-left-disabled');
                            $('.operation-zoom-out').addClass('custom-image-preview-operations-operation-disabled');
                            let index = $(this).parent().index();
                            reviewImagesIndex = index;
                            $('.custom-image-preview-mask, .custom-image-preview-wrap, .custom-image-preview').show();
                            if ($(this).children().is('.video-wrap')) {
                                $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').addClass('custom-image-preview-operations-operation-disabled');
                                value = $(this).find('video').attr('src');
                                $('.custom-image-preview-img-wrapper').append(`<video autoplay muted controls src="${value}" onerror="this.src='${value}';this.onerror=null;;" alt="Video">${value}</video>`);
                                return;
                            }
                            value = $(this).find('img').attr('src');
                            $('.custom-image-preview-img-wrapper').append(`<img class="custom-image-preview-img" src="${value}" style="transform: scale3d(1, 1, 1) rotate(0deg);">`);
                            document.querySelector('.custom-image-preview-img').style.transform = `scale3d(1, 1, 1) rotate(0deg)`;
                            if (index == 0) {
                                $('.custom-image-preview-switch-left').addClass('custom-image-preview-switch-left-disabled');
                            }
                            if (index === lastIndex) {
                                $('.custom-image-preview-switch-right').addClass('custom-image-preview-switch-left-disabled');
                            }
                        }
                    });

                    // start
                    $('.custom-image-preview-switch-left').on('click', function () {
                        console.log('reviewImagesIndex', reviewImagesIndex)
                        if (localStorage.getItem('reviewImages') == null) return;
                        let reviewImages = localStorage.getItem('reviewImages').split(',');
                        if (reviewImagesIndex == 0) {
                            return;
                        };
                        if (reviewImagesIndex == 1) {
                            $('.custom-image-preview-switch-left').addClass('custom-image-preview-switch-left-disabled');
                        }
                        $('.custom-image-preview-switch-right').removeClass('custom-image-preview-switch-left-disabled');
                        $('.custom-image-preview-img-wrapper').empty();
                        let value = reviewImages[reviewImagesIndex-1];
                        if (isVideo.test(value)) {
                            $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').addClass('custom-image-preview-operations-operation-disabled');
                            $('.custom-image-preview-img-wrapper').append(`<video autoplay muted controls src="${value}" onerror="this.src='${value}';this.onerror=null;" alt="Video">${value}</video>`);
                        } else {
                            $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').removeClass('custom-image-preview-operations-operation-disabled');
                            $('.custom-image-preview-img-wrapper').append(`<img class="custom-image-preview-img" src="${value}" style="transform: scale3d(1, 1, 1) rotate(0deg);">`);
                        }
                        reviewImagesIndex --;
                    });

                    $('.custom-image-preview-switch-right').on('click', function () {
                        console.log('reviewImagesIndex-right', reviewImagesIndex)
                        if (localStorage.getItem('reviewImages') == null) return;
                        let reviewImages = localStorage.getItem('reviewImages').split(',');
                        if (reviewImagesIndex == lastIndex) {
                            return;
                        };
                        if (reviewImagesIndex + 1 == lastIndex) {
                            $('.custom-image-preview-switch-right').addClass('custom-image-preview-switch-left-disabled');
                        };
                        $('.custom-image-preview-switch-left').removeClass('custom-image-preview-switch-left-disabled');
                        $('.custom-image-preview-img-wrapper').empty();
                        let value = reviewImages[reviewImagesIndex+1];
                        if (isVideo.test(value)) {
                            $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').addClass('custom-image-preview-operations-operation-disabled');
                            $('.custom-image-preview-img-wrapper').append(`<video autoplay muted controls src="${value}" onerror="this.src='${value}';this.onerror=null;;" alt="Video">${value}</video>`);
                        } else {
                            $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').removeClass('custom-image-preview-operations-operation-disabled');
                            $('.custom-image-preview-img-wrapper').append(`<img class="custom-image-preview-img" src="${value}" style="transform: scale3d(1, 1, 1) rotate(0deg);">`);
                        }
                        reviewImagesIndex ++;
                    });

                    $(".operation-close").on('click', function () {
                        $('.custom-image-preview-mask, .custom-image-preview-wrap, .custom-image-preview').hide();
                        $('body').attr('style', '');
                        $('.custom-image-preview-img-wrapper').empty();
                    });

                    $('.custom-image-preview-img-wrapper').on('click', function(event) {
                        if (event.target === this) {
                            $('.custom-image-preview-mask, .custom-image-preview-wrap, .custom-image-preview').hide();
                            $('body').attr('style', '');
                            $('.custom-image-preview-img-wrapper').empty();
                        }
                    });

                    $(".operation-zoom-in").on('click', function () {
                        let currentScale = getScaleValue();
                        let currentRotation = getRotateValue();
                        let nextScale = currentScale + 1;
                        $('.operation-zoom-out').removeClass('custom-image-preview-operations-operation-disabled');
                        $image.style.transform = `scale3d(${nextScale}, ${nextScale}, ${nextScale}) rotate(${currentRotation}deg)`;
                    });

                    $(".operation-zoom-out").on('click', function () {
                        let currentScale = getScaleValue();
                        let currentRotation = getRotateValue();
                        if (currentScale <= 2) {
                            $(this).addClass('custom-image-preview-operations-operation-disabled');
                        }
                        let nextScale = currentScale < 2 ? 1 : currentScale - 1;
                        if (currentScale <= 1) return;
                        $image.style.transform = `scale3d(${nextScale}, ${nextScale}, ${nextScale}) rotate(${currentRotation}deg)`;
                    });

                    $('.operation-rotate-right').on('click', function () {
                        let currentScale = getScaleValue();
                        let currentRotation = getRotateValue();
                        let nextRotation = currentRotation + 90;
                        $image.style.transform = `scale3d(${currentScale}, ${currentScale}, ${currentScale}) rotate(${nextRotation}deg)`;
                    });

                    $('.operation-rotate-left').on('click', function () {
                        let currentScale = getScaleValue();
                        let currentRotation = getRotateValue();
                        let nextRotation = currentRotation - 90;
                        $image.style.transform = `scale3d(${currentScale}, ${currentScale}, ${currentScale}) rotate(${nextRotation}deg)`;
                    });

                    $(window).on('wheel', function(event) {
                        if ($('.custom-image-preview').is(":hidden") || $('.custom-image-preview-img-wrapper').children().is('video')) return;
                        let currentScale = getScaleValue();
                        let currentRotation = getRotateValue();
                        let deltaY = event.originalEvent.deltaY;
                        let scrollDistance = Math.abs(deltaY);
                        if (deltaY < 0) {
                            if (currentScale > 1) {
                                $('.operation-zoom-out').removeClass('custom-image-preview-operations-operation-disabled');
                            }
                            currentScale += 0.1 * scrollDistance / 100;
                        } else {
                            currentScale -= 0.1 * scrollDistance / 100;
                            if (currentScale <= 1) {
                                $('.operation-zoom-out').addClass('custom-image-preview-operations-operation-disabled');
                            }
                        }
                        currentScale = Math.max(1, Math.min(currentScale, 20));
                        $image.style.transform = `scale3d(${currentScale}, ${currentScale}, ${currentScale}) rotate(${currentRotation}deg)`;
                    });
                    function getRotateValue() {
                        let $image = document.querySelector('.custom-image-preview-img');
                        const transformStyle = $image.style.transform;
                        const rotateValues = transformStyle.match(/rotate\(([^)]+)\)/);
                        return rotateValues ? parseFloat(rotateValues[1]) : 0;
                    }

                    function getScaleValue() {
                        let $image = document.querySelector('.custom-image-preview-img');
                        const transformStyle = $image.style.transform;
                        const scale3dValues = transformStyle.match(/scale3d\(([^)]+)\)/);
                        return scale3dValues ? scale3dValues[1].split(',').map(parseFloat)[0] : 1;
                    }
                    // end

                    $('.mb-hooya-image-preview-review .swiper-wrapper').on('click','.swiper-slide', function(e) {
                        if ($(e.target).is("video")) return;
                        hidePreviewPhotos();
                    });
                    $('.mb-hooya-image-preview__close-icon-wrap').on('click', function () {
                        hidePreviewPhotos();
                    })
                    function hidePreviewPhotos () {
                        if (listVanSwiper) {
                            listVanSwiper.destroy();
                            listVanSwiper = null;
                        };
                        $('.mb-hooya-image-preview-review, .mb-hooya-overlay-review').hide();
                        $('body').attr('style', '');
                        $('.mb-hooya-swiper-container-review .swiper-wrapper').empty();
                    }
                });
            </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(
        [ 'jquery' ], function ($) {
            $(document).ready(function($){           
                var reviewFilesList = [];
                var reviewMediaInputName = 0;  
                var maxImg = 5;   
                let isUpVideo = false;      
                $(document).on('change','#review_media',function() {               
                    const source = this.files[0];           
                    reviewMediaInputName ++;

                    if($('#media_field-error').is(':hidden')){
                        $('#media_field-error').show();
                    }

                    $('#media_field-error').html('')

                    if( reviewFilesList.length > maxImg){
                        $('#media_field-error').append('<p>Sie können maximal 5 Bilder auswählen.</p>');
                        return
                    }


                    if (!/image|video\/\w+/.test(source.type)){
                        $('#media_field-error').append('<p>Das Bildformat ist falsch.</p>');
                        return;
                    }        
            
                    if(reviewFilesList.length > 0 && $.inArray(source.name,reviewFilesList) != -1){
                        $('#media_field-error').append('<p>Doppeltes Bild. Bitte wählen Sie es erneut.</p>');
                        $('.review-images input:last').val('');
                        return;
                    }

                    if (/image\/\w+/.test(source.type)) {
                        if(source.size > 15*1024*1024){
                            $('#media_field-error').append('<p>Bitte ändern Sie die Größe oder wählen Sie ein anderes Bild. Das Bild überschreitet die maximale Größe von 15MB.</p>');
                            return;
                        }
                    }

                    if (/video\/\w+/.test(source.type)) {
                        if (isUpVideo) {
                            $('#media_field-error').append('<p>Maximal ein Video kann hochgeladen werden.</p>');
                            return;
                        }
                        if(source.size > 20*1024*1024){
                            $('#media_field-error').append('<p>Bitte achten Sie darauf, dass die hochgeladenen Bilder nicht größer als 15 MB und die Videos nicht größer als 20 MB sind.</p>');
                            return;
                        }
                        isUpVideo = true;
                    }
                        
                    if(window.FileReader) {
                        if (/image\/\w+/.test(source.type)){
                            const fr = new FileReader();                
                            fr.onloadend = function(e) {
                                $("#review-picture-preview").append("<div class='img-box'><div class='close'>X</div><div class='mid-img'><img src='"+e.target.result+"' class='img'/></div></div>");
                            };
                            fr.readAsDataURL(source);
                        } else {
                            $("#review-picture-preview").append(`
                                <div class='img-box video-box'><div class='close'>X</div>
                                <svg focusable="false" class="" data-icon="file" width="1em" height="1em" fill="currentColor" aria-hidden="true" viewBox="64 64 896 896"><path d="M534 352V136H232v752h560V394H576a42 42 0 01-42-42z" fill="#e6f7ff"></path><path d="M854.6 288.6L639.4 73.4c-6-6-14.1-9.4-22.6-9.4H192c-17.7 0-32 14.3-32 32v832c0 17.7 14.3 32 32 32h640c17.7 0 32-14.3 32-32V311.3c0-8.5-3.4-16.7-9.4-22.7zM602 137.8L790.2 326H602V137.8zM792 888H232V136h302v216a42 42 0 0042 42h216v494z" fill="#1890ff"></path></svg>
                                <span class="ant-upload-list-item-name" title="${source.name}">${source.name}</span>
                                </div>
                            `);
                        }
                    }
                    
                    reviewFilesList.push(source.name)
                    
                    if(reviewFilesList.length < maxImg){
                        $(this).clone(true).insertAfter(this);
                        $(this).hide();
                        $(this).next().attr('name','review_media['+reviewMediaInputName+']');                    
                        $(this).next().val(''); 
                    }
                    if(reviewFilesList.length  == maxImg){
                        $(this).parent().hide();
                    } 
                    
                });

                $(document).on('click','#review-picture-preview .img-box .close',function() {
                    const removeReviewImg = $(this).parent();
                    isUpVideo = false;
                    const imgIndex = removeReviewImg.index();
                    removeReviewImg.remove();
                    $('.review-images input:eq('+imgIndex+')').remove();
                    reviewFilesList.splice(imgIndex,1)
                    var input_count = $('.review-images input').size();
                    if(input_count <= maxImg && $(".review-images").is(":hidden")){                    
                        $('.review-images').show();
                        $('.review-images input:last').clone(true).insertAfter($('.review-images input:last'));
                        $('.review-images input:last').attr('name','review_media['+reviewMediaInputName+']');
                        $('.review-images input:last').val('');
                        $('.review-images input:last').show().siblings().hide();
                    }               
                }); 
        });
    })
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Review/js/process-reviews": {
                "productReviewUrl": "https\u003A\u002F\u002Fwww.costway.de\u002Freview\u002Fproduct\u002FlistAjax\u002Frand\u002F359158137\u002Fid\u002F4961\u002F",
                "reviewsTabSelector": "#tab-label-reviews"
            }
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery', 'domReady!'], function ($) {
        $('#recaptcha-8bcc0f8a1913e7cdd90403abe408039d21bd32d6-container')
            .appendTo('.faq-field-recaptcha');
    });
</script>
<script type="text/x-magento-init">
{
    "#recaptcha-8bcc0f8a1913e7cdd90403abe408039d21bd32d6-container": {
        "Magento_Ui/js/core/app": {"components":{"recaptcha-8bcc0f8a1913e7cdd90403abe408039d21bd32d6":{"settings":{"rendering":{"sitekey":"6Ld4E1MdAAAAAAmTHwXzLLfOkWk5etYQulgMuFmT","size":"normal","theme":"light","hl":"de"},"invisible":false},"component":"Magento_ReCaptchaFrontendUi\/js\/reCaptcha","reCaptchaId":"recaptcha-8bcc0f8a1913e7cdd90403abe408039d21bd32d6"}}}    }
}
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        ///numLimit：字数限制
        ///isRequired：文本是否必填
        function numLimit(numLimit,isRequired) {
            var text = jQuery("#faq_content").val();
            var textLength = 0;
            if (text!="undefined"&&text!=""&&text!=null) {
                textLength = text.length;
            }
            jQuery(".faq_msg3").css('display', 'none');
            jQuery('[name="faq_content"]').css('border', '1px solid #cbcbcb');
            if (isRequired && textLength >= 5000) {
                jQuery (".faq_msg3").html('Maximal 5000 Zeichen.');
                jQuery(".faq_msg3").css('display', 'block');
            }
            jQuery ("#DJZYLimit").html(textLength + "/" + numLimit);

        }

        function seemorebtn(type = 0) {   //鼠标点击
            var count = jQuery(".seemore-btn").attr("count");
            var issearch = type;
            var search_where = '';
            var all_count = '';
            if (issearch == 1){
                jQuery('.searchdel').css('display','block');
                all_count = jQuery("#faqsearch").attr("all_count");
                search_where = jQuery("#faqsearch").attr("value");
                console.log(search_where);
                if (search_where == 'undefined' || search_where == ''){
                    issearch = 2;
                }
            } else if (issearch == 2){
                jQuery("#faqsearch").val('');
                jQuery('.searchdel').css('display','none');
            }  else {
                all_count = 0            }
            if (count + 5 > all_count){
                jQuery('.seemore-btn').css('display','none');
            }
            var form_key =  jQuery("input[name='form_key']").val();

            var url = "https://www.costway.de/report/question/ajaxList/";
            require(['jquery', 'jquery/ui'], function($){
                $.ajax({
                    method:"POST",
                    url:url,
                    data:{
                        form_key:form_key,
                        count:count,
                        issearch:issearch,
                        search_where:search_where,
                        product_id:4961,
                    },
                    dataType:"json"
                }).done(function(res) {
                    var html = '';
                    all_count = res.all_count;
                    if (issearch == 1){
                        $(res.data).each(function(key,value){
                            html += '<li class="item faq-item">';
                            html += '<div class="question" >';
                            html += '<span>F:&nbsp;&nbsp; </span><span>'+value.content;
                            if (value.status == 0){
                                html += '<span class="under_review" >Wir werden diese Frage später beantworten, vielen Dank für Ihre Geduld</span>'
                            }
                            html += '</span></div>';
                            var content = value.answer.content;
                            if (value.answer){
                                html += '<div class="answer"><span>A:&nbsp;&nbsp;&nbsp;</span> '+ content +' </div>'
                            }
                            html +='</li>'
                        })
                        $(".faq-items").children().remove();
                        $('.faq-items').append(html);
                    } else if (issearch == 2){
                        $(res.data).each(function(key,value){
                            var content = value.answer.content;
                            html += `<li class="item faq-item">
                                <div class="question" >
                                <span>F:&nbsp;&nbsp; </span><span>${value.content}`;
                            if (value.status == 0){
                                html += `<span class="under_review" >Wir werden diese Frage später beantworten, vielen Dank für Ihre Geduld</span>`;
                            }
                            html += `</span></div>`;
                            if (content){
                                html +=`<div class="answer"><span>A:&nbsp;&nbsp;&nbsp;</span> ${content} </div>`
                            }
                            html += `</li>`;
                        });
                        $(".faq-items").children().remove();
                        $('.faq-items').append(html);
                        count = 5;
                        $('.seemore-btn').attr('count',count);
                        if (all_count > count ){
                            jQuery('.seemore-btn').css('display','block');
                        }
                    } else {
                        $(res.data).each(function(key,value){
                            var content = value.answer.content;
                            html += `<li class="item faq-item">
                            <div class="question" >
                            <span>F:&nbsp;&nbsp; </span><span>${value.content}`;
                            if (value.status == 0){
                                html += `<span class="under_review" >Wir werden diese Frage später beantworten, vielen Dank für Ihre Geduld</span>`;
                            }
                            html += `</span></div>`;
                            if (content){
                                html +=`<div class="answer"><span>A:&nbsp;&nbsp;&nbsp;</span> ${content} </div>`
                            }
                            html += `</li>`;
                        });
                        $('.faq-items').append(html);
                        count = Number(count)+5;
                        $('.seemore-btn').attr('count',count);
                        if (all_count > count ){
                            jQuery('.seemore-btn').css('display','block');
                        }

                    }
                });
            });

        }


    function Askquestion() {
        jQuery('.product-faq-contaniner .faq-ask-contaniner').show()
    }
    function cancelAsk() {
        jQuery('.product-faq-contaniner .faq-ask-contaniner').hide()
    }

    function questionsPost() {
        var url = "https://www.costway.de/report/question/post/";
        var faq_nickname = jQuery("input[name='faq_nickname']").val();
        var faq_email = jQuery("input[name='faq_email']").val();
        var faq_content = jQuery("#faq_content").val();
        var form_key =  jQuery("input[name='form_key']").val();
        jQuery('.faq_msg3').html('Dies ist ein Pflichtfeld!');
        if(!faq_nickname){
            jQuery(".faq_msg1").css('display', 'none');
            jQuery(".faq_msg2").css('display', 'none');
            jQuery(".faq_msg3").css('display', 'none');
            jQuery('.faq_msg1').css('display', 'block');
            jQuery('[name="faq_nickname"]').css('border', '1px dashed #E64D43');
            return false;
        }

        if(!faq_email){
            jQuery(".faq_msg1").css('display', 'none');
            jQuery(".faq_msg2").css('display', 'none');
            jQuery(".faq_msg3").css('display', 'none');
            jQuery('.faq_msg2').css('display', 'block');
            jQuery('[name="faq_nickname"]').css('border', '1px solid #cbcbcb');
            jQuery('[name="faq_email"]').css('border', '1px dashed #E64D43');
            return false;
        }
        if (faq_email){
            var reg = /^([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*@([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*\.(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]){2,})$/i;
            console.log(reg.test(faq_email));
            if(reg.test(faq_email) == false || reg.test(faq_email) == 'undefined'){
                console.log(reg.test(faq_email));
                jQuery('.faq_msg2').css('display', 'block');
                jQuery('[name="faq_email"]').css('border', '1px dashed #E64D43');
                jQuery('.faq_msg2').html('Bitte geben Sie eine gültige E-Mail-Adresse ein (Beispiel: maxmuster@domain.de).');
                return false;
            }
        }

        if(!faq_content){
            jQuery(".faq_msg1").css('display', 'none');
            jQuery(".faq_msg2").css('display', 'none');
            jQuery(".faq_msg3").css('display', 'none');
            jQuery('.faq_msg3').css('display', 'block');
            jQuery('[name="faq_nickname"]').css('border', '1px solid #cbcbcb');
            jQuery('[name="faq_email"]').css('border', '1px solid #cbcbcb');
            jQuery('[name="faq_content"]').css('border', '1px dashed #E64D43');
            return false;
        }

        jQuery(".faq_msg1").css('display', 'none');
        jQuery(".faq_msg2").css('display', 'none');
        jQuery(".faq_msg3").css('display', 'none');
        jQuery('[name="faq_nickname"]').css('border', '1px solid #cbcbcb');
        jQuery('[name="faq_email"]').css('border', '1px solid #cbcbcb');
        jQuery('[name="faq_content"]').css('border', '1px solid #cbcbcb');

        var faqfieldrecaptchaform = jQuery("#faq-field-recaptcha-form").serialize();
        if(faqfieldrecaptchaform){
            faqfieldrecaptchaform = "&"+faqfieldrecaptchaform;
        }
        var data = jQuery("#faq-form").serialize()+faqfieldrecaptchaform+"&faq_product_id="+encodeURIComponent(4961);
        console.log(data);

        require(['jquery', 'jquery/ui'], function($){
            $.ajax({
                method:"POST",
                url:url,
                data:data,
                dataType:"json",
                beforeSend:function(){
                    $(".faq-btn-group .submit").attr("disabled", "disabled");
                },
            }).done(function(msg) {
                var  g_recaptcha_response = $('#faq-field-recaptcha-form').find('.g-recaptcha-response').attr('id');
                var widgetid = '';
                if (g_recaptcha_response != undefined || g_recaptcha_response != null){
                    widgetid = g_recaptcha_response.replace(/g-recaptcha-response/g, "").replace(/-/g, "");
                }
                console.log(widgetid);
                $(".faq-btn-group .submit").removeAttr("disabled");
                if (msg.status == 'success'){
                    jQuery("#faq_nickname").val('');
                    jQuery("#faq_email").val('');
                    jQuery("#faq_content").val('');
                    jQuery('.faq_message').css('background','#e5efe5');
                    jQuery('.faq_message').css('color','#006400');
                    jQuery('.faq_message').css('display','block');
                    jQuery('.faq_message').text(msg.msg);
                    var html = '';
                    all_count = msg.all_count;
                    $(msg.data).each(function(key,value){
                        var content = value.answer.content;
                        html += `<li class="item faq-item">
                            <div class="question" >
                            <span>F:&nbsp;&nbsp; </span><span>${value.content}`;
                        if (value.status == 0){
                            html += `<span class="under_review" >Wir werden diese Frage später beantworten, vielen Dank für Ihre Geduld</span>`;
                        }
                        html += `</span></div>`;
                        if (content){
                            html +=`<div class="answer"><span>A:&nbsp;&nbsp;&nbsp;</span> ${content} </div>`
                        }
                        html += `</li>`;
                    });
                    $(".faq-items").children().remove();
                    $('.faq-items').append(html);
                    count = 5;
                    $('.seemore-btn').attr('count',count);
                    if (all_count > count ){
                        jQuery('.seemore-btn').css('display','block');
                    }
                    if (widgetid){
                        window.grecaptcha.reset(widgetid)
                    } else {
                        window.grecaptcha.reset()
                    }
                }else{
                    jQuery('.faq_message').css('display','block');
                    jQuery('.faq_message').css('color','black');
                    jQuery('.faq_message').css('background','pink');
                    jQuery('.faq_message').text(msg.msg);
                    if (widgetid){
                        window.grecaptcha.reset(widgetid)
                    } else {
                        window.grecaptcha.reset()
                    }
                }
            });
        });
    }

</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
        require([
            'jquery',
            'jquery/jquery.cookie'
        ], function($) {
            $(document).ready(function() {

                var pw = $(document).width()
                var _hash = 'instructions'
                $('#download-instructions').on('click', function(event) {
                    var _url = window.location.href
                    if (_url.includes("#")) {
                        _url = _url.replace(/#.*/, "#" + _hash);
                    } else {
                        _url = window.location.href + "#" + _hash;
                    }

                    var currentTime = new Date();
                    var tenMinutesLater = new Date(currentTime.getTime() + 60 * 60 * 1000);
                    $.cookie('redirect', _url, {
                        expires: tenMinutesLater
                    })
                    // 用户未登录，跳转登录页面
                    window.location.href = "https://www.costway.de/customer/account/login/";
                });

                if (window.location.hash === '#' + _hash) {
                    var locateToInstructions = setInterval(function() {
                        // 选择两个图片元素
                        var galleryElements = $('[data-gallery-role="gallery"]');
                        var navImage = $('[data-gallery-role="nav-wrap"] .fotorama__active img');
                        var stageImage = $('.fotorama__stage .fotorama__active img');
                        var fotoramaNavFrameDot = $('.fotorama__nav__frame--dot.fotorama__active')

                        if (navImage.length && stageImage.length&& pw>750 || pw<=750 && stageImage.length && fotoramaNavFrameDot.length ) {
                            clearInterval(locateToInstructions)
                            var $images = pw>750 ? $('[data-gallery-role="gallery"] .fotorama__active img') : stageImage

                            // 设置计数器，用于跟踪加载完成的图片数量
                            var loadedCount = 0;

                            // 遍历每张图片
                            $images.each(function() {
                                var $image = $(this);

                                // 创建一个新的 Image 对象
                                var img = new Image();

                                // 设置加载完成的回调函数
                                img.onload = function() {
                                    loadedCount++;

                                    // 判断是否所有图片都已加载完成
                                    if (loadedCount === $images.length) {
                                        console.log('All images loaded successfully.');
                                        // 在这里执行所有图片加载完成后的逻辑
                                        var targetElement = $('#tab-label-instructions_tab');
                                        if (pw > 750) {
                                            const pos = targetElement.offset().top - $('.header-widget').height()
                                            $('#tab-label-instructions_tab').trigger('click')
                                            $('html, body').animate({
                                                scrollTop: pos
                                            }, 1000);
                                        } else {
                                            $('#tab-label-instructions_tab').collapsible('forceActivate')
                                        }
                                    }
                                };

                                // 设置加载失败的回调函数
                                img.onerror = function() {
                                    console.log('Image failed to load:', $image.attr('src'));
                                };

                                // 设置图片地址，触发加载
                                img.src = $image.attr('src');
                            });
                        }

                    }, 1000)


                }

            });
        })
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(['jquery', 'tabs'], function($) {
    var url_content = window.location.hash;

    function getTabIdex(_id) {
        var indexValue;
        var objId = _id
        $(".data.item.title").each(function(index) {
            if ($(this).attr('id') === 'tab-label-' + objId) {
                indexValue = index;
                return false;
            }
        });
        return indexValue;
    }
    let active = 0;
    if (url_content == '#questions') {
        active = getTabIdex('questions');
    }
    if (url_content == '#reviews') {
        active = getTabIdex('reviews');
    }

    $("#detailed-tabs").tabs({
        "active": active,
        "openedState": "active",
        "collapsible": $(window).width() <= 750 // 小屏幕支持折叠
    });

    if (url_content) {
        $('.product.data.items').tabs('activate', active);
    }

    // A+ 图及视频懒加载
    const lazyElements = document.querySelectorAll("#description img[data-src],#description video[data-src]");
    let imgVideoObserver;
    // 初始化 IntersectionObserver
    function initDesImagesObserver() {
        if ("IntersectionObserver" in window) {
            imgVideoObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const element = entry.target;
                        element.src = element.getAttribute("data-src");
                        if (element.tagName === 'VIDEO') {
                            element.load();
                        }
                        element.removeAttribute("data-src");
                        observer.unobserve(element); // 加载完成后停止观察
                    }
                });
            });
            observeDesImages();
        } else {
            // 不支持 IntersectionObserver 的降级方案
            loadDesAllImages();
        }
    }

    // 观察元素
    function observeDesImages() {
        lazyElements.forEach(element => {
            if (element.hasAttribute("data-src")) {
                imgVideoObserver.observe(element);
            }
        });
    }

    // 加载所有元素（降级处理）
    function loadDesAllImages() {
        lazyElements.forEach(element => {
            element.src = element.getAttribute("data-src");
            element.removeAttribute("data-src");
        });
    }

    // 初始化懒加载
    initDesImagesObserver();



    // 获取所有具有 data-src 的 <source> 元素
    const lazySourceVideos = document.querySelectorAll('video:not([data-src])');
    // 初始化 IntersectionObserver
    function initLazySourceVideoObserver() {
        if ("IntersectionObserver" in window) {
            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const video = entry.target;

                        // 加载 <source> 的 data-src 属性到 src
                        const sources = video.querySelectorAll('source[data-src]');
                        sources.forEach(source => {
                            source.src = source.getAttribute('data-src');
                            source.removeAttribute('data-src');
                        });

                        // 触发 <video> 的加载
                        video.load();

                        observer.unobserve(video); // 加载后停止观察
                    }
                });
            });

            lazySourceVideos.forEach(video => observer.observe(video));
        } else {
            // 降级方案：加载所有视频
            lazySourceVideos.forEach(video => {
                const sources = video.querySelectorAll('source[data-src]');
                sources.forEach(source => {
                    source.src = source.getAttribute('data-src');
                    source.removeAttribute('data-src');
                });
                video.load();
            });
        }
    }

    // 初始化懒加载
    initLazySourceVideoObserver();

    require(['jquery', 'jquery-ui-modules/tooltip'], function($) {
        $(document).ready(function() {
            $(".price-drop-wrap .coupon-tips-svg").tooltip({
                position: {
                    my: "center top",
                    at: "center bottom+16",
                    collision: "flipfit"
                },
                tooltipClass: "drop-coupon-tips",
                show: { effect: "fadeIn", duration: 100 },
                hide: { effect: "fadeOut", duration: 100 }
            });

            $(".product-tag-type .coupon-tips-svg").tooltip({
                position: {
                    my: "center top",
                    at: "center bottom+10",
                    collision: "flipfit"
                },
                tooltipClass: "drop-coupon-tips clearanceTips",
                show: { effect: "fadeIn", duration: 100 },
                hide: { effect: "fadeOut", duration: 100 }
            });

            // 移除 aria-live 支持的元素
            $(".ui-helper-hidden-accessible").remove();
            $(".black-friday-baojia-tips-svg").on('click', function() {
                $("#black-friday-baojia-popups").show();
            })
            $("#black-friday-baojia-popups .close").on('click', function() {
                $("#black-friday-baojia-popups").hide();
            })
        });
    });
});
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">window.authenticationPopup = {"autocomplete":"off","customerRegisterUrl":"https:\/\/www.costway.de\/customer\/account\/create\/","customerForgotPasswordUrl":"https:\/\/www.costway.de\/customer\/account\/forgotpassword\/","baseUrl":"https:\/\/www.costway.de\/","customerLoginUrl":"https:\/\/www.costway.de\/customer\/ajax\/login\/"}</script>
<script type="text/x-magento-init">
        {
            "#authenticationPopup": {
                "Magento_Ui/js/core/app": {"components":{"authenticationPopup":{"component":"Magento_Customer\/js\/view\/authentication-popup","children":{"messages":{"component":"Magento_Ui\/js\/view\/messages","displayArea":"messages"},"captcha":{"component":"Magento_Captcha\/js\/view\/checkout\/loginCaptcha","displayArea":"additional-login-form-fields","formId":"user_login","configSource":"checkout"},"social-buttons":{"component":"Mageplaza_SocialLogin\/js\/view\/social-buttons","displayArea":"before"}}}}}            },
            "*": {
                "Magento_Ui/js/block-loader": "https\u003A\u002F\u002Fwww.costway.de\u002Fstatic\u002Fversion1778723978\u002Ffrontend\u002Fdefault\u002Fhooya\u002Fde_DE\u002Fimages\u002Floader\u002D1.gif"
                            }
        }
    </script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Customer/js/section-config": {
                "sections": {"stores\/store\/switch":["*"],"stores\/store\/switchrequest":["*"],"directory\/currency\/switch":["*"],"*":["messages"],"customer\/account\/logout":["*","recently_viewed_product","recently_compared_product","persistent"],"customer\/account\/loginpost":["*"],"customer\/account\/createpost":["*"],"customer\/account\/editpost":["*"],"customer\/ajax\/login":["checkout-data","cart","captcha","connect_session"],"catalog\/product_compare\/add":["compare-products"],"catalog\/product_compare\/remove":["compare-products"],"catalog\/product_compare\/clear":["compare-products"],"sales\/guest\/reorder":["cart"],"sales\/order\/reorder":["cart"],"checkout\/cart\/add":["cart","directory-data","magepal-gtm-jsdatalayer"],"checkout\/cart\/delete":["cart","magepal-gtm-jsdatalayer"],"checkout\/cart\/updatepost":["cart","magepal-gtm-jsdatalayer"],"checkout\/cart\/updateitemoptions":["cart","magepal-gtm-jsdatalayer"],"checkout\/cart\/couponpost":["cart","magepal-gtm-jsdatalayer"],"checkout\/cart\/estimatepost":["cart","magepal-gtm-jsdatalayer"],"checkout\/cart\/estimateupdatepost":["cart","magepal-gtm-jsdatalayer"],"checkout\/onepage\/saveorder":["cart","checkout-data","last-ordered-items","magepal-gtm-jsdatalayer","connect_session"],"checkout\/sidebar\/removeitem":["cart","magepal-gtm-jsdatalayer"],"checkout\/sidebar\/updateitemqty":["cart","magepal-gtm-jsdatalayer"],"rest\/*\/v1\/carts\/*\/payment-information":["cart","last-ordered-items","captcha","instant-purchase","magepal-gtm-jsdatalayer"],"rest\/*\/v1\/guest-carts\/*\/payment-information":["cart","captcha","magepal-gtm-jsdatalayer"],"rest\/*\/v1\/guest-carts\/*\/selected-payment-method":["cart","checkout-data","magepal-gtm-jsdatalayer"],"rest\/*\/v1\/carts\/*\/selected-payment-method":["cart","checkout-data","instant-purchase","magepal-gtm-jsdatalayer"],"customer\/address\/*":["instant-purchase"],"customer\/account\/*":["instant-purchase"],"vault\/cards\/deleteaction":["instant-purchase"],"multishipping\/checkout\/overviewpost":["cart"],"paypal\/express\/placeorder":["cart","checkout-data"],"paypal\/payflowexpress\/placeorder":["cart","checkout-data"],"paypal\/express\/onauthorization":["cart","checkout-data"],"persistent\/index\/unsetcookie":["persistent"],"review\/product\/post":["review"],"wishlist\/index\/add":["wishlist"],"wishlist\/index\/remove":["wishlist"],"wishlist\/index\/updateitemoptions":["wishlist"],"wishlist\/index\/update":["wishlist"],"wishlist\/index\/cart":["wishlist","cart"],"wishlist\/index\/fromcart":["wishlist","cart"],"wishlist\/index\/allcart":["wishlist","cart"],"wishlist\/shared\/allcart":["wishlist","cart"],"wishlist\/shared\/cart":["cart"],"aw_rewardpoints\/cart\/remove":["cart"],"rest\/*\/v1\/carts\/*\/apply-aw-reward-points":["cart"],"rest\/*\/v1\/carts\/*\/remove-aw-reward-points":["cart"],"ammostviewed\/cart\/add":["cart","messages"],"sociallogin\/popup\/create":["checkout-data","cart"],"braintree\/paypal\/placeorder":["cart","checkout-data"],"braintree\/googlepay\/placeorder":["cart","checkout-data"],"rest\/*\/v1\/carts\/*\/shipping-information":["connect_session"],"rest\/*\/v1\/guest-carts\/*\/shipping-information":["connect_session"]},
                "clientSideSections": ["checkout-data","cart-data"],
                "baseUrls": ["https:\/\/www.costway.de\/","http:\/\/www.costway.de\/"],
                "sectionNames": ["messages","customer","compare-products","last-ordered-items","cart","directory-data","captcha","instant-purchase","loggedAsCustomer","persistent","review","wishlist","connect_session","recently_viewed_product","recently_compared_product","product_data_storage","paypal-billing-agreement","magepal-gtm-jsdatalayer"]            }
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Customer/js/customer-data": {
                "sectionLoadUrl": "https\u003A\u002F\u002Fwww.costway.de\u002Fcustomer\u002Fsection\u002Fload\u002F",
                "expirableSectionLifetime": 60,
                "expirableSectionNames": ["cart","persistent"],
                "cookieLifeTime": "604800",
                "updateSessionUrl": "https\u003A\u002F\u002Fwww.costway.de\u002Fcustomer\u002Faccount\u002FupdateSession\u002F"
            }
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "Magento_Customer/js/invalidation-processor": {
                "invalidationRules": {
                    "website-rule": {
                        "Magento_Customer/js/invalidation-rules/website-rule": {
                            "scopeConfig": {
                                "websiteId": "1"
                            }
                        }
                    }
                }
            }
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "body": {
            "pageCache": {"url":"https:\/\/www.costway.de\/page_cache\/block\/render\/id\/4961\/","handles":["default","catalog_product_view","catalog_product_view_type_simple","catalog_product_view_id_4961","catalog_product_view_sku_CM23511DE"],"originalRequest":{"route":"catalog","controller":"product","action":"view","uri":"\/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html"},"versionCookieName":"private_content_version"}        }
    }
</script>
<script type="text/x-magento-init">
    {
        "body": {
            "awRewardPointsAjax": {"url":"https:\/\/www.costway.de\/aw_rewardpoints\/block\/render\/id\/4961\/","originalRequest":{"route":"catalog","controller":"product","action":"view","uri":"\/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html"}}        }
    }
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "catalogNewList": {}
        }
    }
</script>
<script type="text/x-magento-init">
    {
        "body": {
            "requireCookie": {"noCookieUrl":"https:\/\/www.costway.de\/cookie\/index\/noCookies\/","triggers":[".action.towishlist"],"isRedirectCmsPage":true}        }
    }
</script>
<script type="text/x-magento-init">
    {
        "*": {
                "Magento_Catalog/js/product/view/provider": {
                    "data": {"items":{"4961":{"add_to_cart_button":{"post_data":"{\"action\":\"https:\\\/\\\/www.costway.de\\\/checkout\\\/cart\\\/add\\\/uenc\\\/%25uenc%25\\\/product\\\/4961\\\/\",\"data\":{\"product\":\"4961\",\"uenc\":\"%uenc%\"}}","url":"https:\/\/www.costway.de\/checkout\/cart\/add\/uenc\/%25uenc%25\/product\/4961\/","required_options":false},"add_to_compare_button":{"post_data":null,"url":"{\"action\":\"https:\\\/\\\/www.costway.de\\\/catalog\\\/product_compare\\\/add\\\/\",\"data\":{\"product\":\"4961\",\"uenc\":\"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,\"}}","required_options":null},"price_info":{"final_price":96.99,"max_price":96.99,"max_regular_price":96.99,"minimal_regular_price":96.99,"special_price":null,"minimal_price":96.99,"regular_price":136.99,"formatted_prices":{"final_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","max_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","minimal_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","max_regular_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","minimal_regular_price":null,"special_price":null,"regular_price":"<span class=\"price\">136,99\u00a0\u20ac<\/span>"},"extension_attributes":{"msrp":{"msrp_price":"<span class=\"price\">0,00\u00a0\u20ac<\/span>","is_applicable":"","is_shown_price_on_gesture":"","msrp_message":"","explanation_message":"Our price is lower than the manufacturer&#039;s &quot;minimum advertised price.&quot; As a result, we cannot show you the price in catalog or the product page. <br><br> You have no obligation to purchase the product once you know the price. You can simply remove the item from your cart."},"tax_adjustments":{"final_price":96.99,"max_price":96.99,"max_regular_price":96.99,"minimal_regular_price":96.99,"special_price":96.99,"minimal_price":96.99,"regular_price":136.99,"formatted_prices":{"final_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","max_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","minimal_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","max_regular_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","minimal_regular_price":null,"special_price":"<span class=\"price\">96,99\u00a0\u20ac<\/span>","regular_price":"<span class=\"price\">136,99\u00a0\u20ac<\/span>"}},"weee_attributes":[],"weee_adjustment":"<span class=\"price\">96,99\u00a0\u20ac<\/span>"}},"images":[{"url":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/91b17ec672c43b669d01d5228e518663\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","code":"recently_viewed_products_grid_content_widget","height":397,"width":450,"label":"Costway 180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","resized_width":450,"resized_height":397},{"url":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/91b17ec672c43b669d01d5228e518663\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","code":"recently_viewed_products_list_content_widget","height":397,"width":450,"label":"Costway 180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","resized_width":450,"resized_height":397},{"url":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/f79e3c9c25895822bffc292ea062d494\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","code":"recently_viewed_products_images_names_widget","height":69,"width":78,"label":"Costway 180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","resized_width":78,"resized_height":69},{"url":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/91b17ec672c43b669d01d5228e518663\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","code":"recently_compared_products_grid_content_widget","height":397,"width":450,"label":"Costway 180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","resized_width":450,"resized_height":397},{"url":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/91b17ec672c43b669d01d5228e518663\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","code":"recently_compared_products_list_content_widget","height":397,"width":450,"label":"Costway 180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","resized_width":450,"resized_height":397},{"url":"https:\/\/www.costway.de\/media\/catalog\/product\/cache\/f79e3c9c25895822bffc292ea062d494\/k\/_\/k_nstlicher_weihnachtsbaum-verschneiter_beleuchteter_weihnachtsbaum-cm23510us_1_.jpg","code":"recently_compared_products_images_names_widget","height":69,"width":78,"label":"Costway 180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","resized_width":78,"resized_height":69}],"url":"https:\/\/www.costway.de\/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html","id":4961,"name":"180 cm K\u00fcnstlicher Weihnachtsbaum mit 200 Farbwechselnden LED-Lichtern","type":"simple","is_salable":"","store_id":1,"currency_code":"EUR","extension_attributes":{"review_html":"        <div class=\"product-reviews-summary short\">\n                <div class=\"rating-summary\">\n            <span class=\"label\"><span>Bewertung:<\/span><\/span>\n            <div class=\"rating-result\"\n                 id=\"rating-result_4961\"\n                 title=\"96%\">\n                <span style=\"width: 96%\"><span>96%<\/span><\/span>\n            <\/div>\n            <script type=\"text&#x2F;javascript\">var elemBBgCIVvI = document.querySelector('#rating-result_4961 span');\nif (elemBBgCIVvI) {\nelemBBgCIVvI.style.width = '96%';\n}<\/script>        <\/div>\n                <div class=\"reviews-actions\">\n            <a class=\"action view\"\n               href=\"https:\/\/www.costway.de\/costway-180-cm-kunstlicher-weihnachtsbaum-mit-200-farbwechselnden-led-lichtern.html#reviews\">3&nbsp;<span>Bewertungen                <\/span>\n            <\/a>\n        <\/div>\n    <\/div>\n","wishlist_button":{"post_data":null,"url":"{\"action\":\"https:\\\/\\\/www.costway.de\\\/wishlist\\\/index\\\/add\\\/\",\"data\":{\"product\":4961,\"uenc\":\"aHR0cHM6Ly93d3cuY29zdHdheS5kZS9jb3N0d2F5LTE4MC1jbS1rdW5zdGxpY2hlci13ZWlobmFjaHRzYmF1bS1taXQtMjAwLWZhcmJ3ZWNoc2VsbmRlbi1sZWQtbGljaHRlcm4uaHRtbA,,\"}}","required_options":null}},"is_available":false}},"store":"1","currency":"EUR","productCurrentScope":"website"}            }
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require(['jquery', 'swiper.min'], function ($, Swiper) {
        $(document).ready(function () {
            let _pw = $(window).width();
            let imagesEle = $('.main-slide-photos img');
            let reviewImagesIndex = 0;
            let lastIndex = imagesEle.length - 1;
            const isVideo = /\.(avi|rm|ram|rmvb|mpeg|mpg|dat|mov|qt|asf|wmv|swf|flv|mp4|3gq)$/i;
            $('.custom-image-preview-switch-left').on('click', function () {
                if (localStorage.getItem('reviewImages') == null) return;
                let reviewImages = localStorage.getItem('reviewImages').split(',');
                if (reviewImagesIndex == 0) {
                    return;
                };
                if (reviewImagesIndex == 1) {
                    $('.custom-image-preview-switch-left').addClass('custom-image-preview-switch-left-disabled');
                }
                $('.custom-image-preview-switch-right').removeClass('custom-image-preview-switch-left-disabled');
                $('.custom-image-preview-img-wrapper').empty();
                let value = reviewImages[reviewImagesIndex-1];
                if (isVideo.test(value)) {
                    $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').addClass('custom-image-preview-operations-operation-disabled');
                    $('.custom-image-preview-img-wrapper').append(`<video autoplay muted controls src="${value}" onerror="this.src='${value}';this.onerror=null;" alt="Video">${value}</video>`);
                } else {
                    $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').removeClass('custom-image-preview-operations-operation-disabled');
                    $('.custom-image-preview-img-wrapper').append(`<img class="custom-image-preview-img" src="${value}" style="transform: scale3d(1, 1, 1) rotate(0deg);">`);
                }
                reviewImagesIndex --;
            });

            $('.custom-image-preview-switch-right').on('click', function () {
                if (localStorage.getItem('reviewImages') == null) return;
                let reviewImages = localStorage.getItem('reviewImages').split(',');
                if (reviewImagesIndex == lastIndex) {
                    return;
                };
                if (reviewImagesIndex + 1 == lastIndex) {
                    $('.custom-image-preview-switch-right').addClass('custom-image-preview-switch-left-disabled');
                };
                $('.custom-image-preview-switch-left').removeClass('custom-image-preview-switch-left-disabled');
                $('.custom-image-preview-img-wrapper').empty();
                let value = reviewImages[reviewImagesIndex+1];
                if (isVideo.test(value)) { 
                    $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').addClass('custom-image-preview-operations-operation-disabled');
                    $('.custom-image-preview-img-wrapper').append(`<video autoplay muted controls src="${value}" onerror="this.src='${value}';this.onerror=null;;" alt="Video">${value}</video>`);
                } else {
                    $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').removeClass('custom-image-preview-operations-operation-disabled');
                    $('.custom-image-preview-img-wrapper').append(`<img class="custom-image-preview-img" src="${value}" style="transform: scale3d(1, 1, 1) rotate(0deg);">`);
                }
                reviewImagesIndex ++;
            });

            
            $(".main-slide-photos .cus-img, .main-slide-photos .video-wrap").on('click', function () {
                if (_pw < 1000) return;
                $('.custom-image-preview-switch-left, .custom-image-preview-switch-right').removeClass('custom-image-preview-switch-left-disabled');
                $('.operation-zoom-out').addClass('custom-image-preview-operations-operation-disabled');
                $('.custom-image-preview-mask, .custom-image-preview-wrap, .custom-image-preview').show();
                let value = '';
                if ($(this).is('.video-wrap')) {
                    $('.operation-zoom-in, .operation-rotate-right, .operation-rotate-left').addClass('custom-image-preview-operations-operation-disabled');
                    value = $(this).children('video').attr('src');
                    $('.custom-image-preview-img-wrapper').append(`<video autoplay muted controls src="${value}" onerror="this.src='${value}';this.onerror=null;;" alt="Video">${value}</video>`);
                    return;
                }
                let index = $(this).parent().index();
                reviewImagesIndex = index;
                value = $(this).attr('src');
                $('.custom-image-preview-img-wrapper').append(`<img class="custom-image-preview-img" src="${value}" style="transform: scale3d(1, 1, 1) rotate(0deg);">`);
                document.querySelector('.custom-image-preview-img').style.transform = `scale3d(1, 1, 1) rotate(0deg)`;
                if (index == 0) {
                    $('.custom-image-preview-switch-left').addClass('custom-image-preview-switch-left-disabled');
                }
                if (index === lastIndex) {
                    $('.custom-image-preview-switch-right').addClass('custom-image-preview-switch-left-disabled');
                }
            });

            $(".operation-close").on('click', function () {
                $('.custom-image-preview-mask, .custom-image-preview-wrap, .custom-image-preview').hide();
                $('body').attr('style', '');
                $('.custom-image-preview-img-wrapper').empty();
            });

            $('.custom-image-preview-img-wrapper').on('click', function(event) {
                if (event.target === this) {
                    $('.custom-image-preview-mask, .custom-image-preview-wrap, .custom-image-preview').hide();
                    $('body').attr('style', '');
                    $('.custom-image-preview-img-wrapper').empty();
                }
            });

            $(".operation-zoom-in").on('click', function () {
                let currentScale = getScaleValue();
                let currentRotation = getRotateValue();
                let nextScale = currentScale + 1;
                $('.operation-zoom-out').removeClass('custom-image-preview-operations-operation-disabled');
                document.querySelector('.custom-image-preview-img').style.transform = `scale3d(${nextScale}, ${nextScale}, ${nextScale}) rotate(${currentRotation}deg)`;
            });

            $(".operation-zoom-out").on('click', function () {
                let currentScale = getScaleValue();
                let currentRotation = getRotateValue();
                if (currentScale <= 2) {
                    $(this).addClass('custom-image-preview-operations-operation-disabled');
                }
                let nextScale = currentScale < 2 ? 1 : currentScale - 1;
                if (currentScale <= 1) return;
                document.querySelector('.custom-image-preview-img').style.transform = `scale3d(${nextScale}, ${nextScale}, ${nextScale}) rotate(${currentRotation}deg)`;
            });

            $('.operation-rotate-right').on('click', function () {
                let currentScale = getScaleValue();
                let currentRotation = getRotateValue();
                let nextRotation = currentRotation + 90;
                document.querySelector('.custom-image-preview-img').style.transform = `scale3d(${currentScale}, ${currentScale}, ${currentScale}) rotate(${nextRotation}deg)`;
            });

            $('.operation-rotate-left').on('click', function () {
                let currentScale = getScaleValue();
                let currentRotation = getRotateValue();
                let nextRotation = currentRotation - 90;
                document.querySelector('.custom-image-preview-img').style.transform = `scale3d(${currentScale}, ${currentScale}, ${currentScale}) rotate(${nextRotation}deg)`;
            });

            $(window).on('wheel', function(event) {
                if ($('.custom-image-preview').is(":hidden") || $('.custom-image-preview-img-wrapper').children().is('video')) return;
                let currentScale = getScaleValue();
                let currentRotation = getRotateValue();
                let deltaY = event.originalEvent.deltaY;
                let scrollDistance = Math.abs(deltaY);
                if (deltaY < 0) {
                    if (currentScale > 1) {
                        $('.operation-zoom-out').removeClass('custom-image-preview-operations-operation-disabled');
                    }
                    currentScale += 0.1 * scrollDistance / 100;
                } else {
                    currentScale -= 0.1 * scrollDistance / 100;
                    if (currentScale <= 1) {
                        $('.operation-zoom-out').addClass('custom-image-preview-operations-operation-disabled');
                    }
                }
                currentScale = Math.max(1, Math.min(currentScale, 20));
                document.querySelector('.custom-image-preview-img').style.transform = `scale3d(${currentScale}, ${currentScale}, ${currentScale}) rotate(${currentRotation}deg)`;
            });

        });
        function getRotateValue() {
            const transformStyle = document.querySelector('.custom-image-preview-img').style.transform;
            const rotateValues = transformStyle.match(/rotate\(([^)]+)\)/);
            return rotateValues ? parseFloat(rotateValues[1]) : 0;
        }

        function getScaleValue() {
            const transformStyle = document.querySelector('.custom-image-preview-img').style.transform;
            const scale3dValues = transformStyle.match(/scale3d\(([^)]+)\)/);
            return scale3dValues ? scale3dValues[1].split(',').map(parseFloat)[0] : 1;
        }
    });
</script>
<script type="text/x-magento-init">
    {
        "*": {
            "amastyXsearchCollectProductView": {}
        }
    }
</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-16958");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-16958  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-17959");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-17959  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-18724");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-18724  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-16983");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-16983  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-6324");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-6324  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">var elemYmuX7HYN = document.querySelector('#rating-result_6324 span');
if (elemYmuX7HYN) {
elemYmuX7HYN.style.width = '91%';
}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-14555");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-14555  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-18381");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-18381  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-11625");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-11625  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">var elem8BZDSjpj = document.querySelector('#rating-result_11625 span');
if (elem8BZDSjpj) {
elem8BZDSjpj.style.width = '100%';
}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-16903");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-16903  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-19097");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-19097  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-15771");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-15771  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-18292");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-18292  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-14155");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-14155  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-7727");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-7727  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">var elemBqF7UnNE = document.querySelector('#rating-result_7727 span');
if (elemBqF7UnNE) {
elemBqF7UnNE.style.width = '100%';
}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-12624");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-12624  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-8342");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-8342  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-16753");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-16753  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-7275");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-7275  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-17139");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-17139  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="text&#x2F;javascript">prodImageContainers = document.querySelectorAll(".product-image-container-17788");
for (var i = 0; i < prodImageContainers.length; i++) {
    prodImageContainers[i].style.width = "240px";
}
prodImageContainersWrappers = document.querySelectorAll(
    ".product-image-container-17788  span.product-image-wrapper"
);
//for (var i = 0; i < prodImageContainersWrappers.length; i++) {
//    prodImageContainersWrappers[i].style.paddingBottom = "100%";
//}</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
            require([
                "jquery",
                 "Amasty_Base/vendor/slick/slick.min",
                'jquery.lazyload.min',
            ], function ($) {
                if ($('body.account').length > 0) {
                    $('#amrelated-block-3 [data-amrelated-js="slider"]').slick(
                        {
                            dots:false,
                            infinite: false,
                            slidesToShow: 4,
                            slidesToScroll: 4,
                            variableWidth: true,
                            centerMode: false,
                            responsive: [
                                {
                                    breakpoint: 767,
                                    settings: {

                                        arrows:false,
                                        slidesToShow: 2,
                                        slidesToScroll: 2
                                    }
                                }
                            ]
                        }
                    );
                } else {
                    $('#amrelated-block-3 [data-amrelated-js="slider"]').slick(
                        {
                            dots:false,
                            infinite: false,
                            slidesToShow: 5,
                            slidesToScroll: 5,
                            variableWidth: true,
                            centerMode: false,

                            responsive: [
                                {
                                    breakpoint: 1280,
                                    settings: {
                                        slidesToShow: 4,
                                        slidesToScroll: 4
                                    }
                                },
                                {
                                    breakpoint: 767,
                                    settings: {

                                        arrows:false,
                                        slidesToShow: 2,
                                        slidesToScroll: 2
                                    }
                                },
                                // {
                                //     breakpoint: 425,
                                //     settings: {
                                //         slidesToShow: 1,
                                //         slidesToScroll: 1
                                //     }
                                // }
                            ]
                        }
                    );
                }
            $('#amrelated-block-3 [data-amrelated-js="slider"]').on("afterChange", function(event, slick, currentSlide){
                    if (typeof $.fn.lazyload !== 'undefined'){
                        $(window).trigger('scroll');
                    }
                });
            });
        </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    require([
        'jquery',
        'Amasty_Mostviewed/js/mostviewed_analytics'
    ], function ($, analytics) {
        analytics(
            'https://www.costway.de/ammostviewed/analytics/view/',
            3,
            '#amrelated-block-3',
            null,
            'https://www.costway.de/ammostviewed/analytics/click/'
        );
    });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
  require(["jquery","subscribeModal","Message"], function($){
    $(document).ready(function () {
      var emailReg = /^([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9,!\#\$%&'\*\+\/=\?\^_`\{\|\}~-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*@([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z0-9-]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*\.(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]){2,})$/i;
      $('#newsletter-validate-detail').submit(function(event) {
        event.preventDefault();
        var email = $('#newsletter').val();
        if (email == '') {
          $('.newsletter-errortips').text('Dies ist ein Pflichtfeld.');
          $('.newsletter_v2 .control,.subscribe-placehoder').addClass('error');
          return;
        }
        if(emailReg.test(email) == false || emailReg.test(email) == 'undefined') {
          $('.newsletter-errortips').text('Bitte geben Sie eine gültige E-Mail-Adresse ein (Beispiel: maxmuster@domain.de).');
          $('.newsletter_v2 .control,.subscribe-placehoder').addClass('error');
          return;
        }
        
          $.ajax({
            url:  '/newsletter/subscriber/new/',
            data: {
              email: email,
              type:'subsfrom_foot',
              device: $(window).width() >750 ?'pc':'mb'
            },
            type: 'POST',
            async: true,
            dataType : "json",
            beforeSend:function(){
              $('.input-group-btn .subscribe').css('opacity','0.5').attr('disabled',true);
              $('.input-group-btn .subscribe').prepend('<span class="ant-btn-loading-icon"><span role="img" aria-label="loading" class="anticon anticon-loading anticon-spin"><svg focusable="false" data-icon="loading" width="1em" height="1em" fill="currentColor" aria-hidden="true" viewBox="0 0 1024 1024"><path d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 00-94.3-139.9 437.71 437.71 0 00-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z"></path></svg></span></span>')
            },
            success: function(data){
              window.handleSubscribeModalResult(data,'subsfrom_foot',email)
            },
            error: function (data) {
              $('.input-group-btn .subscribe').css('opacity','1').attr('disabled',false);
              console.info("error: " + data.responseText);
            },
            complete:function(){
              $('#newsletter-validate-detail #newsletter').val('');
              $('.input-group-btn .subscribe').css('opacity','1').attr('disabled',false);
              $('#newsletter-validate-detail .ant-btn-loading-icon').remove();
            }
          });        
      })
      $('#newsletter').focus(function() {
        $(this).attr("placeholder", "");
        $('.subscribe-placehoder').css({"display":"block"});
      })
      $('#newsletter').blur(function() {
        if (!$(this).val()) {
          $(this).attr("placeholder", "E-Mail");
          $('.subscribe-placehoder').css({"display":"none"});
          $('.newsletter_v2 .control,.subscribe-placehoder').removeClass('error');
          $('.newsletter-errortips').text('');
        }
      })
      $('#newsletter').bind('input propertychange', function() {
        $('.newsletter-errortips').text('');
        $('.newsletter_v2 .control,.subscribe-placehoder').removeClass('error');
        if ($('#newsletter').val() !== '') {
          $('.subscribe-close').css({'display':'block'});
        } else {
          $('.subscribe-close').css({'display':'none'});
        }
      })
      $('.subscribe-close').click(function() {
        $('.subscribe-placehoder').css({"display":"none"});
        $('#newsletter').attr("placeholder", "E-Mail");
        $('#newsletter').val('');
        $(this).css({"display":"none"});
        $('.newsletter-errortips').text('');
        $('.newsletter_v2 .control,.subscribe-placehoder').removeClass('error');
      })
    });
  });
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
            (function() {
              var _tsid = 'XA2206FF04AA17F911080ABAC358DC1A8';
              _tsConfig = {
                'yOffset': '0',
                /* offset from page bottom */
                'variant': 'custom_reviews',
                /* default, reviews, custom, custom_reviews */
                'customElementId': 'MyCustomTrustbadge',
                /* required for variants custom and custom_reviews */
                'trustcardDirection': '',
                /* for custom variants: topRight, topLeft, bottomRight, bottomLeft */
                'customBadgeWidth': '90',
                /* for custom variants: 40 - 90 (in pixels) */
                'customBadgeHeight': '',
                /* for custom variants: 40 - 90 (in pixels) */
                'disableResponsive': 'true',
                /* deactivate responsive behaviour */
                'disableTrustbadge': 'false',
                /* deactivate trustbadge */
                'trustCardTrigger': 'mouseenter',
                'customCheckoutElementId': '',
                'responsive': {
                  'variant': 'custom_reviews',
                  'customElementId': 'MyCustomTrustbadge'
                }
              };
              var _ts = document.createElement('script');
              _ts.type = 'text/javascript';
              _ts.charset = 'utf-8';
              _ts.async = true;
              _ts.src = '//widgets.trustedshops.com/js/' + _tsid + '.js';
              var __ts = document.getElementsByTagName('script')[0];
              __ts.parentNode.insertBefore(_ts, __ts);
            })();
          </script>
<script type="text/plain" class="cmplazyload" data-cmp-vendor="s1" src="https://apis.google.com/js/platform.js" async defer></script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
            window.___gcfg = {
              lang: 'de'
            };
          </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
  require(['jquery', 'jquery/jquery.cookie'], function($) {
    $(document).ready(function() {

      const _pw = $(window).width();
      if(_pw<=980){
        $('.footer-menu dt').on('click', function () {
          $(this).parent().toggleClass('show').siblings().removeClass('show');
        })
      }
      window._isLogin = 0; //判断是否登陆
      window._is_subscribe = 0; //判断登陆用户订阅状态

      $('.sidebar-popup-wrapper .close, .sidebar-popup-wrapper .cmpboxBG, .attributes-popup-main .confirm-btn').on('click', function() {
        hideProdetailCoupons()
      })

      function hideProdetailCoupons() {
        $('.sidebar-popup-wrapper .cmpboxBG').hide();
        if (_pw >= 767) {
          $(".sidebar-popup-main").animate({
            right: '-380px'
          });
        } else {
          $(".sidebar-popup-main").animate({
            bottom: '-550px'
          });
        }
      }
      var interval = setInterval(function() {
          var cmpwrapperEle = document.querySelector('#cmpwrapper');
          if (cmpwrapperEle !== null) {
              clearInterval(interval);
              clearTimeout(cmpboxTimeout);
              var shadowRoot = cmpwrapperEle.shadowRoot;
              var cmpboxEle = shadowRoot ? shadowRoot.querySelector('#cmpbox') : null;

              if (cmpboxEle) {
                  var $cmpbox = $(cmpboxEle);
                  let cmpboxVisible = $cmpbox.is(':visible');

                  if ($('.popover-coupons-box').hasClass('show') && cmpboxVisible) {
                      $('body').append('<div class="pop-costway-cmp"></div>');

                      var observer = new MutationObserver(function(mutationsList, observer) {
                          mutationsList.forEach(function(mutation) {
                              if (mutation.attributeName === 'style' && !$cmpbox.is(':visible')) {
                                  $('.pop-costway-cmp').remove();
                                  observer.disconnect();
                              }
                          });
                      });

                      var config = { attributes: true };
                      observer.observe($cmpbox[0], config);
                  }
              }
          }
      }, 100);

      var cmpboxTimeout = setTimeout(function() {
          clearInterval(interval);
      }, 10000);
      $('.common-pop .close').on('click', function () {
          $('.common-pop').hide();
      });
    })

  })
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
  require(['jquery', 'jqueryScrollbar', 'domReady!'], function ($) {
    $(document).ready(function () {
      // 创建弹窗HTML
      function createInviteModal() {
        const modalHTML = `
          <div class="activity-rules-wrapper invite-friends-modal" id="invite-friends-modal">
            <div class="activity-rules-content">
                  <div class="popup-header">
                      <div class="popup-title"></div>
                      <button class="close-btn">
                          <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path
                                  d="M19.6203 0C19.4129 9.72748e-05 19.2139 0.0849991 19.0673 0.236034L0.229059 19.6258C0.156437 19.7006 0.0988299 19.7893 0.059528 19.887C0.0202261 19.9846 -1.4312e-06 20.0893 0 20.195C1.43135e-06 20.3007 0.0202319 20.4054 0.0595365 20.5031C0.098841 20.6007 0.15645 20.6895 0.229074 20.7642C0.301698 20.839 0.387915 20.8983 0.482802 20.9387C0.577689 20.9792 0.679388 21 0.782092 21C0.884796 21 0.986494 20.9792 1.08138 20.9387C1.17627 20.8983 1.26248 20.839 1.3351 20.7642L20.1749 1.37278C20.283 1.25967 20.3563 1.11628 20.3857 0.960526C20.415 0.804773 20.3991 0.643574 20.3399 0.49708C20.2807 0.350588 20.1809 0.225304 20.0529 0.136892C19.9249 0.048481 19.7744 0.000865936 19.6203 0Z"
                                  fill="#fff" />
                              <path
                                  d="M0.785008 7.62939e-06C0.629838 -0.000709534 0.477974 0.0461464 0.348762 0.134607C0.219551 0.223068 0.118844 0.349129 0.0594709 0.496729C9.77073e-05 0.644327 -0.015253 0.806786 0.0153744 0.963398C0.0460017 1.12001 0.12122 1.26369 0.231448 1.37614L19.0897 20.7899C19.2386 20.9295 19.4341 21.0047 19.6355 20.9998C19.8369 20.9948 20.0287 20.9102 20.171 20.7634C20.3134 20.6167 20.3953 20.4191 20.3998 20.2117C20.4043 20.0044 20.331 19.8032 20.1951 19.6501L1.33857 0.236334C1.26594 0.161383 1.17966 0.101927 1.08467 0.0613728C0.989674 0.0208187 0.887842 -3.43323e-05 0.785008 7.62939e-06Z"
                                  fill="#fff" />
                          </svg>
                      </button>
                  </div>
                  <div class="scrollbar-inner">
                      <div class="popup-content">
                          <div class="invite-friends-main">
                              <p>1. Gib zuerst deine eigene Bestellung auf.</p>
                              <p>2. Lade Freund:innen ein, ebenfalls zu bestellen <strong>(keine Begrenzung der Anzahl)</strong>.</p>
                              <p>3. Die <strong>frühere Bestellung</strong> gilt als „<strong>Einladender</strong>“, die <strong>spätere</strong> als „<strong>Eingeladener</strong>“ (maßgeblich ist die Bestellzeit).</p>
                              <p>4. Sobald beide Bestellungen bestätigt sind, sende die <strong>E-Mail-Adresse</strong> und die <strong>Bestellnummer</strong> deiner Freund:innen an unseren Kundenservice.</p>
                              <p>5. Nach erfolgreicher Prüfung erhältst du bis zu <strong>15% Cashback</strong> auf den Bestellwert jedes/r Eingeladenen.</p>
                              <div class="bf-tips">
                                <p><strong>Tipp: </strong>„Bestellung teilen“ auf der Zahlungsbestätigungsseite oder in „Meine Bestellungen“ anklicken und in Social Media teilen.</p>
                              </div>
                          </div>
                          <div class="invite-friends-important-notes">
                              <h4>Wichtige Hinweise</h4>
                              <ul>
                                  <li>Das Cashback wird ausgezahlt, sobald beide Bestellungen als „<strong>Abgeschlossen</strong>“ markiert sind.</li>
                                  <li><strong>Das Cashback wird nur an den Einladenden ausgezahlt, nachdem der/die Eingeladene die erste Bestellung aufgegeben hat.</strong></li>
                                  <li>Der maximale Cashback, den ein Einladender erhalten kann, darf den Zwischensummenbetrag seiner eigenen qualifizierenden Bestellung (der Bestellung, die er vor dem Versenden der Einladung aufgegeben hat) nicht überschreiten.</li>
                                  <li>Wird <strong>entweder die Bestellung des Einladenden oder die des/der Eingeladenen storniert</strong>, entfällt der Cashback-Anspruch.</li>
                                  <li>Bei einer <strong>Rückerstattung</strong> wird der entsprechende Cashback-Betrag <strong>abgezogen</strong>.</li>
                                  <li>Je mehr Freund:innen du einlädst, desto mehr Cashback kannst du erhalten!</li>
                                  <li>Im Zweifelsfall ist die Auslegung durch Costway.de maßgeblich.</li>
                              </ul>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
            `;
                $('body').append(modalHTML);
        }

        

                $(document).on('click', '#invite-friends-modal', function (e) {
                    if (!$(e.target).closest('.activity-rules-content').length) {
                        $(this).removeClass("show");
                    }
                });
                $(document).on('click', "a[data-name='invite_friends_banner'],a[data-name='order_invite_friends_banner']", function (e) {
                  e.preventDefault();
                  var clickType = $(this).data('name');
                  showInviteFriendsmodal(clickType);
              });

                 // 点击关闭按钮
                $(document).on('click', "#invite-friends-modal .close-btn", function () {
                    $("#invite-friends-modal").removeClass("show");
                });

                function showInviteFriendsmodal(eventType = 'invite_friends_banner'){
                  // 初始化时创建弹窗 如果弹窗不存在，则添加到body
          if ($('#invite-friends-modal').length === 0) {
            createInviteModal();
          }
                  $('#invite-friends-modal .scrollbar-inner').scrollbar();
                  const images = $(window).width() <= 750  ? [
                  "https://cdn1.costway.de/public/blackfriday/torch-hunt/de/de-mb.png"
                  ] : [
                      "https://cdn1.costway.de/public/blackfriday/torch-hunt/de/de-pc.png"
                  ];
                  preloadImages(images, function() {
                    $("#invite-friends-modal").addClass("show");
                    if (eventType) {
                        window.trackCustomEvent(eventType);
                    }
                });
                }
                window.showInviteFriendsmodal = showInviteFriendsmodal;

                // 通用图片预加载函数
                function preloadImages(urls, callback) {
                    let loaded = 0;
                    const total = urls.length;

                    urls.forEach(src => {
                        const img = new Image();
                        img.onload = check;
                        img.onerror = check;
                        img.src = src;
                        if (img.complete) {
                            check();
                        }
                    });

                    function check() {
                        loaded++;
                        if (loaded === total && typeof callback === "function") {
                            callback();
                        }
                    }
                }
            });
        });
</script>
<script type="text/x-magento-init">
        {
            "*": {
                "Magento_Ui/js/core/app": {
                    "components": {
                        "storage-manager": {
                            "component": "Magento_Catalog/js/storage-manager",
                            "appendTo": "",
                            "storagesConfiguration" : {"recently_viewed_product":{"requestConfig":{"syncUrl":"https:\/\/www.costway.de\/catalog\/product\/frontend_action_synchronize\/"},"lifetime":"1000","allowToSendRequest":null},"recently_compared_product":{"requestConfig":{"syncUrl":"https:\/\/www.costway.de\/catalog\/product\/frontend_action_synchronize\/"},"lifetime":"1000","allowToSendRequest":null},"product_data_storage":{"updateRequestConfig":{"url":"https:\/\/www.costway.de\/rest\/default\/V1\/products-render-info"},"requestConfig":{"syncUrl":"https:\/\/www.costway.de\/catalog\/product\/frontend_action_synchronize\/"},"allowToSendRequest":null}}                        }
                    }
                }
            }
        }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    
    // window.$crisp=[];window.CRISP_WEBSITE_ID="e0222bb4-1491-401a-b7c1-9b8f5cfe8732";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();
    
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
    
        // 公共函数 begin
    
       var emarsysProductTopRecommendedFunction=function () {
          const _limit = 40;
          ScarabQueue.push([
            "recommend",
            {
              logic: "RELATED", // unique logic
              limit: _limit,
              containerId: "amrelated-block-4", // unique container
              templateId: "product-top-recommended-tmpl",
              success: function (SC, render) {
                const products = SC.page.products;
                //console.log("Emarsys product sku:", products);
                let productIds = SC.page.products.map(function (product) {
                  return product.id;
                });
                //console.log("sku:", productIds);
                require([
                  "jquery",
                  "jquery.lazyload.min",
                  "amSearchSlick",
                ], function ($, Swiper) {
                  // 没有数据时不显示loading效果
                  if (products.length === 0) {
                    $("#amrelated-block-4 .costway-loading-box").hide();
                    return;
                  }
                  // 有数据请求搜索数据
                  $.ajax({
                    url: "https://search-eu.costway.com/searchApi/mobile/search-product",
                    type: "POST",
                    contentType: "application/json",
                    headers: {
                      country: 'de',
                      client: "pc",
                    },
                    dataType: "json",
                    cache: false,
                    data: JSON.stringify({
                      page: 1,
                      pageSize: _limit,
                      skusFilters: productIds,
                      isEmarsysSku: true,
                    }),
                    beforeSend: function () {
                      setPositionLoadingBox(productTopRecommended);
                    },
                    success: function (data) {
                      //console.log("search:", data);
                      if (data.data?.total > 0) {
                        SC.page.products = data.data.datalist.slice(0, 20); // 取前20个
                        SC.page.products.forEach((product) => {
                          product.specialPrice = formatPrice(product.specialPrice);
                          product.rawPrice = formatPrice(product.rawPrice);
                          product.url = product.url + '?entrypoint=relatedproducts';
                        });
                        SC.title = 'Ähnliche Produkte'; ///详情页顶部标题，需要修改
                        render(SC);
                        //console.log("render:", SC.page.products);
    
                        $('#amrelated-block-4 [data-amrelated-js="slider"]').slick(
                          {
                            dots: false,
                            infinite: false,
                            slidesToShow: 5,
                            slidesToScroll: 5,
                            variableWidth: true,
                            centerMode: false,
                            responsive: [
                              {
                                breakpoint: 1280,
                                settings: {
                                  slidesToShow: 4,
                                  slidesToScroll: 4,
                                },
                              },
                              {
                                breakpoint: 767,
                                settings: {
                                  arrows: false,
                                  slidesToShow: 2,
                                  slidesToScroll: 2,
                                },
                              },
                            ],
                          }
                        );
                        $('#amrelated-block-4 [data-amrelated-js="slider"]').on(
                          "afterChange",
                          function (event, slick, currentSlide) {
                            if (typeof $.fn.lazyload !== "undefined") {
                              $(window).trigger("scroll");
                            }
                          }
                        );
    
                        $("#amrelated-block-4 img.lazy").lazyload();
                        $(window).trigger("scroll");
                        initializeCountdown();
                      } else {
                        $("#amrelated-block-4 .costway-loading-box").hide();
                      }
                    },
                    error: function (xhr, status, error) {
                      //console.log("error:", xhr, status, error);
                      $("#amrelated-block-4 .costway-loading-box").hide();
                    },
                  });
                });
              },
            },
          ]);
        }
    
      var emarsysProductBottomAlsoBoughtFunction = function (){
          const _limit = 40;
          ScarabQueue.push([
            "recommend",
            {
              logic: "ALSO_BOUGHT", // unique logic
              limit: _limit,
              containerId: "amrelated-block-3", // unique container
              templateId: "product-top-recommended-tmpl",
              success: function (SC, render) {
                const products = SC.page.products;
                //console.log("Emarsys product sku:", products);
                let productIds = SC.page.products.map(function (product) {
                  return product.id;
                });
                //console.log("sku:", productIds);
                require([
                  "jquery",
                  "jquery.lazyload.min",
                  "amSearchSlick",
                ], function ($, Swiper) {
                  // 没有数据时不显示loading效果
                  if (products.length === 0) {
                    $("#amrelated-block-3 .costway-loading-box").hide();
                    return;
                  }
                  // 有数据请求搜索数据
                  $.ajax({
                    url: "https://search-eu.costway.com/searchApi/mobile/search-product",
                    type: "POST",
                    contentType: "application/json",
                    headers: {
                      country: 'de',
                      client: "pc",
                    },
                    dataType: "json",
                    cache: false,
                    data: JSON.stringify({                  
                      page: 1,
                      pageSize: _limit,
                      skusFilters: productIds,
                      isEmarsysSku: true,
                    }),
                    beforeSend: function () {
                      setPositionLoadingBox(productBottomRecommended);
                    },
                    success: function (data) {
                      //console.log("search:", data);
                      if (data.data?.total > 0) {
                        SC.page.products = data.data.datalist.slice(0, 20); // 取前20个
                        SC.page.products.forEach((product) => {
                          product.specialPrice = formatPrice(product.specialPrice);
                          product.rawPrice = formatPrice(product.rawPrice);
                          product.url = product.url + '?entrypoint=youmightlike';
                        });
                        SC.title = 'Das könnte Dir auch gefallen'; //详情页底部标题，需要修改
                        render(SC);
                        //console.log("render:", SC.page.products);
    
                        $('#amrelated-block-3 [data-amrelated-js="slider"]').slick({
                          dots: false,
                          infinite: false,
                          slidesToShow: 5,
                          slidesToScroll: 5,
                          variableWidth: true,
                          centerMode: false,
                          responsive: [
                            {
                              breakpoint: 1280,
                              settings: {
                                slidesToShow: 4,
                                slidesToScroll: 4,
                              },
                            },
                            {
                              breakpoint: 767,
                              settings: {
                                arrows: false,
                                slidesToShow: 2,
                                slidesToScroll: 2,
                              },
                            },
                          ],
                        });
                        $('#amrelated-block-3 [data-amrelated-js="slider"]').on(
                          "afterChange",
                          function (event, slick, currentSlide) {
                            if (typeof $.fn.lazyload !== "undefined") {
                              $(window).trigger("scroll");
                            }
                          }
                        );
    
                        $("#amrelated-block-3 img.lazy").lazyload();
                        $(window).trigger("scroll");
                        initializeCountdown();
                      } else {
                        $("#amrelated-block-3 .costway-loading-box").hide();
                      }
                    },
                    error: function (xhr, status, error) {
                      //console.log("error:", xhr, status, error);
                      $("#amrelated-block-3 .costway-loading-box").hide();
                    },
                  });
                });
              },
            },
          ]);
        }
    // 公共函数 end
      </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
      var homeProductRecommended = document.querySelector("#home-product-recommended");
      var homeProductSeeMoreRecommended = document.querySelector("#home-recommended-seemores");
      var productTopRecommended = document.querySelector("#amrelated-block-4");
      var productBottomRecommended = document.querySelector("#amrelated-block-3");
      var cartBottomRecommended = document.querySelector("#amrelated-block-13");
      var noDataCartBottomRecommended = document.querySelector("#amrelated-block-16");
      var searchResultsBottomRecommended = document.querySelector("#amrelated-block-15");
      var noSearchResultsBottomRecommended = document.querySelector("#amrelated-block-5");
    </script>
<script type="text/html" id="home-product-tmpl" >
      <![CDATA[
          <div class="swiper-container swiper-container-horizontal">
              <ul class="home-product swiper-wrapper">
                  {{ for (var i=0; i < SC.page.products.length; i++) { }}
                      {{ var p = SC.page.products[i]; }}
                          <li class="product-item swiper-slide" data-scarabitem="{{= p.productId }}">
                              <div class="product-item-info">
                                  <div class="pro-img pro-effect">
                                      <a href="{{= p.url}}">
                                          <img title="{{= p.title}}" class="product-image-photo default_image lazy" src="/pub/images/default-min.jpg" data-original="{{= p.baseImage}}" width="272" height="272" />
                                      </a>
                                  </div>
                                  <div class="product-item-details">
                                      <p class="product-item-name">
                                          <a title="{{= p.title}}" href="{{= p.url}}" class="product-item-link">{{= p.title}}</a>
                                      </p>
                                      <div class="price-box price-final_price" data-role="priceBox">
                                          <span class="home-special-price" data-price-amount="{{= p.specialPrice}}" data-price-type="finalPrice">{{= p.specialPrice}} €</span>                                      
                                          {{ if(p.specialPrice !== p.rawPrice){ }}
                                                <span class="home-old-price" data-price-amount="{{= p.rawPrice}}" data-price-type="oldPrice">{{= p.rawPrice}} €</span>
                                          {{ } }}
                                      </div>
                                  </div>
                              </div>
                          </li>
                      
                  {{ } }}
                  
              </ul>
              <div class="swiper-button-prev"></div>
              <div class="swiper-button-next"></div>
          </div>
          <span class="see-more-button recommended-button">Mehr anzeigen</span>
      ]]>
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript"> 
      if (homeProductRecommended) {
        // ajax 请求实时数据
        const _limit = 24;
        ScarabQueue.push(['recommend', {
            logic: 'PERSONAL', // unique logic
            limit:_limit,
            containerId: 'home-product-recommended', // unique container
            templateId: 'home-product-tmpl',
            success: function(SC, render) {
              const products = SC.page.products;
              //console.log('Emarsys product sku:',products);
              
              let productIds = SC.page.products.map(function(product) {
                return product.id;
              });
              
               //console.log('sku:',productIds);
              require(["jquery",'swiper.min',"jquery.lazyload.min"], function ($,Swiper) {
                // 没有数据时不显示loading效果
                if (products.length === 0) {
                  $('#home-product-recommended .costway-loading-box').hide();
                  return;
                }
                // 有数据请求搜索数据
                $.ajax({
                  url: 'https://search-eu.costway.com/searchApi/mobile/search-product',
                  type: 'POST',
                  contentType: 'application/json',
                  headers: {
                      'country':'de',
                      'client':'pc'
                  },
                  dataType: 'json',
                  cache: false,
                  data: JSON.stringify({
                      "page":1,
                      "pageSize":_limit,
                      "skusFilters":productIds,
                      "isEmarsysSku": true,
                  }),
                  beforeSend: function () {
                      setPositionLoadingBox(homeProductRecommended);
                    },
                  success: function(data) {
                    //console.log('search:',data);
                    if(data.data?.total > 0){
                        SC.page.products =data.data.datalist.slice(0, 8); // 取前8个
                    }else{
                      $('#home-product-recommended .costway-loading-box').hide();
                      return;
                    }
    
                    SC.page.products.forEach(product => {
                        product.specialPrice = formatPrice(product.specialPrice);
                        product.rawPrice = formatPrice(product.rawPrice);
                        product.url = product.url + '?entrypoint=recommended_homepage';
                    });
    
                    render(SC);
                    //console.log('render:',SC.page.products);                
                    
                    if($(window).width() > 750){
                        new Swiper("#home-product-recommended .swiper-container", {
                            observer: true,
                            observeParents: true,
                            loop: false,
                            slidesPerView: "auto",
                            slidesPerGroup: 4,
                            navigation: { 
                                nextEl: "#home-product-recommended  .swiper-button-next",
                                prevEl: "#home-product-recommended  .swiper-button-prev",
                            },
                            on: {
                              transitionEnd: function () {
                                if (typeof jQuery.fn.lazyload !== "undefined") {
                                $(".home-product-wrap .swiper-container img.lazy").lazyload();
                                }
                              },
                            }
                        });
                    }else{
                        $("#home-product-recommended .product-item").each(function () {
                            if ($(this).index() > 3) {
                                $(this).css("display", "none");
                            }
                        });
                        $(".recommended-button").on('click',function () {
                            $(".recommended .home-product .product-item").each(function () {
                              if ($(this).is(":hidden")) {
                                $(this).css("display", "block");
                              }
                            });
                            $(this).css("display", "none");
                            $(window).trigger("scroll");
                          });
                    }
                    $("#home-product-recommended img.lazy").lazyload();
                    $(window).trigger("scroll");
                  },
                  error: function(xhr, status, error) {
                      //console.log('error:',xhr, status, error);
                      $('#home-product-recommended .costway-loading-box').hide();
                  }
                })
              });
            }
          }]); 
        // Send the request only once
        ScarabQueue.push(['go']);
      }
    </script>
<script type="text/html" id="home-recommended-seemores-tmpl" >
      <![CDATA[
          <div style="font-size:0">
            <ol class="products list items product-slider owl-top-btn product-items three_blocks widget-product-grid" >
            {{ for (var i=0; i < SC.page.products.length; i++) { }}
            {{ var p = SC.page.products[i]; }}
    
              <li class="product-item" data-scarabitem="{{= p.productId }}">
                <div class="product-item-info">
                  <div class="pro-img pro-effect product-item-photo">
                    <a href="{{= p.url}}" tabindex="-1" >
                      <img
                        style="position: relative; display: block"
                        title="{{= p.title}}"
                        class="product-image-photo default_image lazy"
                        src="/pub/images/default-min.jpg" data-original="{{= p.baseImage}}"
                        alt="{{= p.title}}"  width="297" height="297"
                      />
                    </a>
                  </div>
                  <div class="product-item-details">
                    <p class="product-item-name">
                      <a title="{{= p.title}}" href="{{= p.url}}" class="product-item-link" > {{= p.title}}</a>
                    </p>
                    <div
                      class="price-box price-final_price"
                      data-role="priceBox"
                      data-product-id="{{=p.productId}}"
                      data-price-box="product-id-{{=p.productId}}"
                    >
                      <span class="special-price">
                        <span class="price-container price-final_price tax weee">
                          <span class="price-label">Special Price</span>
                          <span
                            id="product-price-{{=p.productId}}"
                            data-price-amount="{{= p.specialPrice}}"
                            data-price-type="finalPrice"
                            class="price-wrapper"
                            ><span class="price">{{= p.specialPrice}} €</span></span
                          >
                        </span>
                      </span>
                      {{ if(p.specialPrice !== p.rawPrice){ }}
                      <span class="old-price">
                        <span class="price-container price-final_price tax weee">
                          <span class="price-label">Regular Price</span>
                          <span
                            id="old-price-{{=p.productId}}"
                            data-price-amount="{{= p.rawPrice}}"
                            data-price-type="oldPrice"
                            class="price-wrapper"
                          >
                            <span class="price">{{= p.rawPrice}} €</span></span
                          >
                        </span>
                      </span>
                      {{ } }}
                    </div>
                    
                  </div>
                </div>
              </li>
    
              {{ } }}
            </ol>
          </div>
    ]]>
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
      if (homeProductSeeMoreRecommended) {
        // ajax 请求实时数据
        const _limit = 64;
        ScarabQueue.push(['recommend', {
            logic: 'PERSONAL', // unique logic
            limit:_limit,
            containerId: 'home-recommended-seemores', // unique container
            templateId: 'home-recommended-seemores-tmpl',
            success: function(SC, render) {
              const products = SC.page.products;
              //console.log('Emarsys product sku:',products);
              let productIds = SC.page.products.map(function(product) {
                return product.id;
              });
               //console.log('sku:',productIds);
              require(["jquery","jquery.lazyload.min"], function ($) {
                // 没有数据时不显示loading效果
                if (productIds.length === 0) {
                  $('#home-recommended-seemores .costway-loading-box').hide();
                  return;
                }
                // 有数据请求搜索数据
                $.ajax({
                  url: 'https://search-eu.costway.com/searchApi/mobile/search-product',
                  type: 'POST',
                  contentType: 'application/json',
                  headers: {
                      'country':'de',
                      'client':'pc'
                  },
                  dataType: 'json',
                  cache: false,
                  data: JSON.stringify({
                      "page":1,
                      "pageSize":_limit,
                      "skusFilters":productIds,
                      "isEmarsysSku": true,
                  }),
                   beforeSend: function () {
                      setPositionLoadingBox(homeProductSeeMoreRecommended);
                    },
                  success: function(data) {
                    //console.log('search:',data);
                    if(data.data?.total > 0){
                      SC.page.products =data.data.datalist.slice(0, 36); // 取前36个
                      SC.page.products.forEach(product => {
                        product.specialPrice = formatPrice(product.specialPrice);
                        product.rawPrice = formatPrice(product.rawPrice);
                        product.url = product.url + '?entrypoint=recommended_page';
                      });
      
                      render(SC);
                      $("#home-recommended-seemores img.lazy").lazyload();
                      $(window).trigger("scroll");
                    }else{
                      $('#home-recommended-seemores .costway-loading-box').hide();
                    }
                  },
                  error: function(xhr, status, error) {
                      //console.log('error:',xhr, status, error);
                      $('#home-recommended-seemores .costway-loading-box').hide();
                  }
                })
              });
            }
          }]); 
          // Send the request only once
          ScarabQueue.push(['go']);
      }
    </script>
<script type="text/html" id="product-top-recommended-tmpl" >
        <![CDATA[  
        <h2  class="block-title" >{{=SC.title}} </h2>
        <div class="block-content">
          <div class="grid products-grid">
            <div class="product-items widget-product-grid" data-amrelated-js="slider">       
                {{ for (var i=0; i < SC.page.products.length; i++) { }}
                {{ var p = SC.page.products[i]; }}
                
                      <div class="product-item" style="width:100% !important;" data-scarabitem="{{= p.productId }}">
                        <div class="product-item-info">
                          <a href="{{= p.url}}" class="product-item-photo">
                            <span class="product-image-container">
                              <span class="product-image-wrapper">
                                <img class="product-image-photo lazy" src="/pub/images/default-min.jpg" data-original="{{= p.baseImage}}" width="175" height="175" alt="{{= p.title}}" /></span>
                            </span>
                            {{ if(p.icon.type !== ''){ }}
                                <div class="emars-tagwrap">
                                {{ if(p.icon.type === 'price_drop' && p.icon.value > 0 ){ }}
                                {{ if(isServerTimeInRange(blockFirdayServerTime) === true){ }}
                                    <div class="jiabao-tips">Preis Garantie</div>
                                    <div class="price-drop-list black-friday">
                                        <div class="drop-txt">Preis</div>
                                        <div class="price-drop-con">
                                            <img class="icon-time" title="Endet in" src="/pub/images/black-friday/black-friday-icon-time.png">
                                            <span class="end-days-emarsys" data-countdown="{{= p.icon.value}}"></span>
                                        </div>
                                    </div>
                                {{ } else { }}
                                    <div class="price-drop-list">
                                    <div class="drop-txt">Flash Sale</div>
                                    <div class="price-drop-con">
                                        <img class="icon-time" title="Endet in" src="/pub/images/decline/icon-time.png">
                                        <span class="end-in">Endet in</span>
                                        <span class="end-days-emarsys" data-countdown="{{= p.icon.value}}"></span>
                                    </div>
                                    </div>
                                    {{ } }}
                                     {{ } else if (p.icon.type === 'pre_order') { }}
                                <div class="early-bird-warpper list-item emarsys-item">
                                  <div class="early-bird-main">
                                      <div class="early-left">
                                          <div class="early-title">
                                              <div class="early-title-cen">
                                                  Frühbucher
                                              </div>
                                          </div>
                                          <div class="early-cen"></div>
                                          <div class="early-text">
                                              {{= p.icon.label}}
                                          </div>
                                      </div>
                                  </div>
                              </div>
                                    {{ } else if (p.icon.type === 'out_of_stock') { }}
                                    <div class="sold-out">Nicht auf Lager</div>
                                {{ } else { }}
                                <span class="on-sale-tips {{= p.icon.type}}">{{= p.icon.label}}</span>
                                {{ } }}
                                </div>
                            {{ } }}
                           </a>
                          <div class="product-item-details">
                            <h3 class="product-item-name">
                              <a title="{{= p.title}}" href="{{= p.url}}" class="product-item-link" >{{= p.title}}</a>
                            </h3>  
                            <div class="price-box range second price-final_price" data-role="priceBox" data-product-id="{{=p.productId}}">
                              <span class="special-price">
                                <span class="price-container price-final_price">
                                  <span class="price-label">special price</span>
                                  <span id="product-price-{{=p.productId}}" data-price-amount="{{= p.specialPrice}}" data-price-type="finalPrice1" class="price-wrapper">
                                    <span class="price" ><span class="price">{{= p.specialPrice}} €</span></span>
                                  </span>
                                </span>
                              </span>
                              {{ if(p.specialPrice !== p.rawPrice){ }}
                              <span class="old-price">
                                <span class="price-container price-final_price tax weee" >
                                  <span class="price-label">special price</span>
                                  <span id="product-price-{{=p.productId}}" data-price-amount="{{= p.rawPrice}}" data-price-type="finalPrice1" class="price-wrapper" >
                                    <span class="price" ><span class="price">{{= p.rawPrice}} €</span></span>
                                  </span>
                                </span>
                              </span>
                              {{ } }}
                            </div>
                          </div>
                        </div>
                      </div>
                  
                {{ } }}
            </div>
          </div>
        </div>    
      ]]>
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
      var emarsysBodyElement = document.body;
      // 详情页从GTM抽出来，特殊处理
      
      //简单产品
      if (emarsysBodyElement.matches(".catalog-product-view:not(.page-product-configurable)")) {
        // 获取 sku 元素
        const formElement = document.querySelector("form[data-product-sku]");
        const productSku = formElement.getAttribute("data-product-sku").trim();
         if (customer_id) {
         ScarabQueue.push(["setCustomerId", `DE_${customer_id}`]);         
        }
        ScarabQueue.push(["view", productSku]);
    
        // 详情页top推荐
    
        if (productTopRecommended) {
          emarsysProductTopRecommendedFunction();
        }
    
        // ALSO_BOUGHT
        if (productBottomRecommended) {
          emarsysProductBottomAlsoBoughtFunction();
        }
        // Send the request only once
        ScarabQueue.push(["go"]);
      }
    
      // 搜索页从GTM抽出来，特殊处理
      if (emarsysBodyElement.classList.contains("search-result-index")) {
        const url = new URL(window.location.href);
        const params = new URLSearchParams(url.search);
        // 获取参数 q 的值
        const qValue = params.get("q");
        ScarabQueue.push(["searchTerm", qValue]);
        // Search result bottom recommended
        if (searchResultsBottomRecommended) {
          const _limit = 40;
          ScarabQueue.push([
            "recommend",
            {
              logic: "SEARCH", // unique logic
              limit: _limit,
              containerId: "amrelated-block-15", // unique container
              templateId: "product-top-recommended-tmpl",
              success: function (SC, render) {
                const products = SC.page.products;
                //console.log("Emarsys product sku:", products);
                let productIds = SC.page.products.map(function (product) {
                  return product.id;
                });
                //console.log("sku:", productIds);
                require([
                  "jquery",
                  "jquery.lazyload.min",
                  "amSearchSlick",
                ], function ($, Swiper) {
                  // 没有数据时不显示loading效果
                  if (products.length === 0) {
                    $("#amrelated-block-15 .costway-loading-box").hide();
                    return;
                  }
                  // 有数据请求搜索数据
                  $.ajax({
                    url: "https://search-eu.costway.com/searchApi/mobile/search-product",
                    type: "POST",
                    contentType: "application/json",
                    headers: {
                      country: 'de',
                      client: "pc",
                    },
                    dataType: "json",
                    cache: false,
                    data: JSON.stringify({                  
                      page: 1,
                      pageSize: _limit,
                      skusFilters: productIds,
                      isEmarsysSku: true,
                    }),
                    beforeSend: function () {
                      setPositionLoadingBox(searchResultsBottomRecommended);
                    },
                    success: function (data) {
                      //console.log("search:", data);
                      if (data.data?.total > 0) {
                        SC.page.products = data.data.datalist.slice(0, 20); // 取前20个
                        SC.page.products.forEach((product) => {
                          product.specialPrice = formatPrice(product.specialPrice);
                          product.rawPrice = formatPrice(product.rawPrice);
                          product.url = product.url + '?entrypoint=searchresult_page';
                        });
                        SC.title = 'Unsere Empfehlungen'; //搜索有结果页的标题,需要修改
                        render(SC);
                        //console.log("render:", SC.page.products);
    
                        $('#amrelated-block-15 [data-amrelated-js="slider"]').slick(
                          {
                            dots: false,
                            infinite: false,
                            slidesToShow: 5,
                            slidesToScroll: 5,
                            variableWidth: true,
                            centerMode: false,
                            responsive: [
                              {
                                breakpoint: 1280,
                                settings: {
                                  slidesToShow: 4,
                                  slidesToScroll: 4,
                                },
                              },
                              {
                                breakpoint: 767,
                                settings: {
                                  arrows: false,
                                  slidesToShow: 2,
                                  slidesToScroll: 2,
                                },
                              },
                            ],
                          }
                        );
                        $('#amrelated-block-15 [data-amrelated-js="slider"]').on(
                          "afterChange",
                          function (event, slick, currentSlide) {
                            if (typeof $.fn.lazyload !== "undefined") {
                              $(window).trigger("scroll");
                            }
                          }
                        );
    
                        $("#amrelated-block-15 img.lazy").lazyload();
                        $(window).trigger("scroll");
                        initializeCountdown();
                      } else {
                        $("#amrelated-block-15 .costway-loading-box").hide();
                      }
                    },
                    error: function (xhr, status, error) {
                      //console.log("error:", xhr, status, error);
                      $("#amrelated-block-15 .costway-loading-box").hide();
                    },
                  });
                });
              },
            },
          ]);      
        }
        // NO Search result bottom recommended
        if (noSearchResultsBottomRecommended) {
          const _limit = 40;
          ScarabQueue.push([
            "recommend",
            {
              logic: "SEARCH", // unique logic
              limit: _limit,
              containerId: "amrelated-block-5", // unique container
              templateId: "product-top-recommended-tmpl",
              success: function (SC, render) {
                const products = SC.page.products;
                //console.log("Emarsys product sku:", products);
                let productIds = SC.page.products.map(function (product) {
                  return product.id;
                });
                //console.log("sku:", productIds);
                require([
                  "jquery",
                  "jquery.lazyload.min",
                  "amSearchSlick",
                ], function ($, Swiper) {
                  // 没有数据时不显示loading效果
                  if (products.length === 0) {
                    $("#amrelated-block-5 .costway-loading-box").hide();
                    return;
                  }
                  // 有数据请求搜索数据
                  $.ajax({
                    url: "https://search-eu.costway.com/searchApi/mobile/search-product",
                    type: "POST",
                    contentType: "application/json",
                    headers: {
                      country: 'de',
                      client: "pc",
                    },
                    dataType: "json",
                    cache: false,
                    data: JSON.stringify({
                      page: 1,
                      pageSize: _limit,
                      skusFilters: productIds,
                      isEmarsysSku: true,
                    }),
                    beforeSend: function () {
                      setPositionLoadingBox(noSearchResultsBottomRecommended);
                    },
                    success: function (data) {
                      //console.log("search:", data);
                      if (data.data?.total > 0) {
                        SC.page.products = data.data.datalist.slice(0, 20); // 取前20个
                        SC.page.products.forEach((product) => {
                          product.specialPrice = formatPrice(product.specialPrice);
                          product.rawPrice = formatPrice(product.rawPrice);
                          product.url = product.url + '?entrypoint=searchresult_page';
                        });
                        SC.title = 'Unsere Empfehlungen'; //搜索无结果页的标题, 需要修改
                        render(SC);
                        //console.log("render:", SC.page.products);
    
                        $('#amrelated-block-5 [data-amrelated-js="slider"]').slick({
                          dots: false,
                          infinite: false,
                          slidesToShow: 5,
                          slidesToScroll: 5,
                          variableWidth: true,
                          centerMode: false,
                          responsive: [
                            {
                              breakpoint: 1280,
                              settings: {
                                slidesToShow: 4,
                                slidesToScroll: 4,
                              },
                            },
                            {
                              breakpoint: 767,
                              settings: {
                                arrows: false,
                                slidesToShow: 2,
                                slidesToScroll: 2,
                              },
                            },
                          ],
                        });
                        $('#amrelated-block-5 [data-amrelated-js="slider"]').on(
                          "afterChange",
                          function (event, slick, currentSlide) {
                            if (typeof $.fn.lazyload !== "undefined") {
                              $(window).trigger("scroll");
                            }
                          }
                        );
    
                        $("#amrelated-block-5 img.lazy").lazyload();
                        $(window).trigger("scroll");
                        initializeCountdown();
                      } else {
                        $("#amrelated-block-5 .costway-loading-box").hide();
                      }
                    },
                    error: function (xhr, status, error) {
                      //console.log("error:", xhr, status, error);
                      $("#amrelated-block-5 .costway-loading-box").hide();
                    },
                  });
                });
              },
            },
          ]);            
        }
        // Send the request only once
        ScarabQueue.push(["go"]);
      }
    
      // 购物车页从GTM抽出来，特殊处理
      if (emarsysBodyElement.classList.contains("checkout-cart-index")) {
        if (
          typeof checkoutConfig !== "undefined" &&
          checkoutConfig.quoteItemData &&
          checkoutConfig.quoteItemData.length > 0
        ) {
          // 获取当前用户的ID
          if (customer_id) {
            ScarabQueue.push(["setCustomerId", `DE_${customer_id}`]);
          }
          const quoteItemData = checkoutConfig.quoteItemData.map((item) => ({
            item: item.sku,
            price: parseFloat(item.price),
            quantity: item.qty,
          }));
          ScarabQueue.push(["cart", quoteItemData]);
        } else {
          ScarabQueue.push(["cart", []]);
        }
        // 购物车有结果页的底部推荐
        if (cartBottomRecommended) {
          const _limit = 40;
          ScarabQueue.push([
            "recommend",
            {
              logic: "CART", // unique logic
              limit: _limit,
              containerId: "amrelated-block-13", // unique container
              templateId: "product-top-recommended-tmpl",
              success: function (SC, render) {
                const products = SC.page.products;
                //console.log("Emarsys product sku:", products);
                let productIds = SC.page.products.map(function (product) {
                  return product.id;
                });
                //console.log("sku:", productIds);
                require([
                  "jquery",
                  "jquery.lazyload.min",
                  "amSearchSlick",
                ], function ($, Swiper) {
                  // 没有数据时不显示loading效果
                  if (products.length === 0) {
                    $("#amrelated-block-13 .costway-loading-box").hide();
                    return;
                  }
                  // 有数据请求搜索数据
                  $.ajax({
                    url: "https://search-eu.costway.com/searchApi/mobile/search-product",
                    type: "POST",
                    contentType: "application/json",
                    headers: {
                      country: 'de',
                      client: "pc",
                    },
                    dataType: "json",
                    cache: false,
                    data: JSON.stringify({
                      page: 1,
                      pageSize: _limit,
                      skusFilters: productIds,
                      isEmarsysSku: true,
                    }),
                    beforeSend: function () {
                      setPositionLoadingBox(cartBottomRecommended);
                    },
                    success: function (data) {
                      //console.log("search:", data);
                      if (data.data?.total > 0) {
                        SC.page.products = data.data.datalist.slice(0, 20); // 取前20个
                        SC.page.products.forEach((product) => {
                          product.specialPrice = formatPrice(product.specialPrice);
                          product.rawPrice = formatPrice(product.rawPrice);
                          product.url = product.url + '?entrypoint=cart';
                        });
                        SC.title = 'Unsere Empfehlungen'; // 购物车页的标题需要修改
                        render(SC);
                        //console.log("render:", SC.page.products);
    
                        $('#amrelated-block-13 [data-amrelated-js="slider"]').slick(
                          {
                            dots: false,
                            infinite: false,
                            slidesToShow: 5,
                            slidesToScroll: 5,
                            variableWidth: true,
                            centerMode: false,
                            responsive: [
                              {
                                breakpoint: 1280,
                                settings: {
                                  slidesToShow: 4,
                                  slidesToScroll: 4,
                                },
                              },
                              {
                                breakpoint: 767,
                                settings: {
                                  arrows: false,
                                  slidesToShow: 2,
                                  slidesToScroll: 2,
                                },
                              },
                            ],
                          }
                        );
                        $('#amrelated-block-13 [data-amrelated-js="slider"]').on(
                          "afterChange",
                          function (event, slick, currentSlide) {
                            if (typeof $.fn.lazyload !== "undefined") {
                              $(window).trigger("scroll");
                            }
                          }
                        );
    
                        $("#amrelated-block-13 img.lazy").lazyload();
                        $(window).trigger("scroll");
                        initializeCountdown();
                      } else {
                        $("#amrelated-block-13 .costway-loading-box").hide();
                      }
                    },
                    error: function (xhr, status, error) {
                      //console.log("error:", xhr, status, error);
                      $("#amrelated-block-13 .costway-loading-box").hide();
                    },
                  });
                });
              },
            },
          ]);
        }
        // 购物车无结果页的底部推荐
        if (noDataCartBottomRecommended) {
          const _limit = 40;
          ScarabQueue.push([
            "recommend",
            {
              logic: "CART", // unique logic
              limit: _limit,
              containerId: "amrelated-block-16", // unique container
              templateId: "product-top-recommended-tmpl",
              success: function (SC, render) {
                const products = SC.page.products;
                //console.log("Emarsys product sku:", products);
                let productIds = SC.page.products.map(function (product) {
                  return product.id;
                });
                //console.log("sku:", productIds);
                require([
                  "jquery",
                  "jquery.lazyload.min",
                  "amSearchSlick",
                ], function ($, Swiper) {
                  // 没有数据时不显示loading效果
                  if (products.length === 0) {
                    $("#amrelated-block-16 .costway-loading-box").hide();
                    return;
                  }
                  // 有数据请求搜索数据
                  $.ajax({
                    url: "https://search-eu.costway.com/searchApi/mobile/search-product",
                    type: "POST",
                    contentType: "application/json",
                    headers: {
                      country: 'de',
                      client: "pc",
                    },
                    dataType: "json",
                    cache: false,
                    data: JSON.stringify({
                      page: 1,
                      pageSize: _limit,
                      skusFilters: productIds,
                      isEmarsysSku: true,
                    }),
                    beforeSend: function () {
                      setPositionLoadingBox(noDataCartBottomRecommended);
                    },
                    success: function (data) {
                      //console.log("search:", data);
                      if (data.data?.total > 0) {
                        SC.page.products = data.data.datalist.slice(0, 20); // 取前20个
                        SC.page.products.forEach((product) => {
                          product.specialPrice = formatPrice(product.specialPrice);
                          product.rawPrice = formatPrice(product.rawPrice);
                          product.url = product.url + '?entrypoint=cart';
                        });
                        SC.title = 'Unsere Empfehlungen'; // 购物车页的标题需要修改
                        render(SC);
                        //console.log("render:", SC.page.products);
    
                        $('#amrelated-block-16 [data-amrelated-js="slider"]').slick(
                          {
                            dots: false,
                            infinite: false,
                            slidesToShow: 5,
                            slidesToScroll: 5,
                            variableWidth: true,
                            centerMode: false,
                            responsive: [
                              {
                                breakpoint: 1280,
                                settings: {
                                  slidesToShow: 4,
                                  slidesToScroll: 4,
                                },
                              },
                              {
                                breakpoint: 767,
                                settings: {
                                  arrows: false,
                                  slidesToShow: 2,
                                  slidesToScroll: 2,
                                },
                              },
                            ],
                          }
                        );
                        $('#amrelated-block-16 [data-amrelated-js="slider"]').on(
                          "afterChange",
                          function (event, slick, currentSlide) {
                            if (typeof $.fn.lazyload !== "undefined") {
                              $(window).trigger("scroll");
                            }
                          }
                        );
    
                        $("#amrelated-block-16 img.lazy").lazyload();
                        $(window).trigger("scroll");
                        initializeCountdown();
                      } else {
                        $("#amrelated-block-16 .costway-loading-box").hide();
                      }
                    },
                    error: function (xhr, status, error) {
                      //console.log("error:", xhr, status, error);
                      $("#amrelated-block-16 .costway-loading-box").hide();
                    },
                  });
                });
              },
            },
          ]);
        }
        // Send the request only once
        ScarabQueue.push(["go"]);
      }        
    </script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
            // dummy variable - please replace with your customer ID variable
            var webEmarsysSdkCustomerId = typeof customer_id !== "undefined" && customer_id > 0 ? customer_id : "";
            var emarsysFieldId = 6696;
            var emarsysPopupRootElement = document.querySelector("#emarsys-permission-popup");
            var emarsysSubscribePopupShowTimer = null;
            var emarsysTimeout = window.innerWidth < 768 ? 120000 : 210000; // PC：三分半  210000，MB:两分钟 120000
            var emarsysVisibilityTimeout = 30000; // 30 seconds
            var emarsysPopupHideTimer = null; // 定时器，用于隐藏弹窗
    
    
            function emarsysIsChrome() {
                var userAgent = navigator.userAgent;
                // 检查是否为 Chrome 浏览器，同时排除 Edge 浏览器
                var isChrome =
                    userAgent.indexOf("Chrome") > -1 && userAgent.indexOf("Edg") === -1;
                return isChrome;
            }
    
            function emarsysVisibilityTimeoutCallback() {
                //console.log("show popup timeout callback, hide popup")
                emarsysPopupHideTimer = setInterval(() => {
                    hideEmarsysPermissionPopup()
                }, emarsysVisibilityTimeout);
            }
    
            //function - subscribe() - to trigger premission popup by browser and sync browser token to Emarsys - [all pages]
            // new subscriber - start
            function generalSubscribe() {
                WebEmarsysSdk.push(function (res) {
                    if (!emarsysIsChrome() && emarsysPopupRootElement.classList.contains("flex")) {
                        hideEmarsysPermissionPopup("accept");
                    }
                    emarsysSubscribe();
    
                    WebEmarsysSdk.push([
                        "onSubscribe",
                        function (res) {
                            //Result: The user has subscribed web push
                            localStorage.setItem("emarsysSubscribe", "subscribe");
    
                            if (webEmarsysSdkCustomerId) {
                                // for user in login status
                                WebEmarsysSdk.push(function (res) {
                                    WebEmarsysSdk.isSubscribed()
                                        .then(function (res) {
                                            const contactInfo = {
                                                fieldId: Number(emarsysFieldId),
                                                fieldValue: webEmarsysSdkCustomerId,
                                            };
                                            loginResult = WebEmarsysSdk.login(contactInfo).then(
                                                function (res) {
                                                    if (res) {
                                                        localStorage.setItem("emarsysLogin",
                                                            "login");
                                                    }
                                                }
                                            );
                                        })
                                        .catch(function (err) {
                                            console.error("Is subscribed error", err);
                                        });
                                });
                            }
                        },
                    ]);
                });
            }
            // new subscriber - end
    
            // login / Logout - start
    
            //login() - map existing contact to this browser - [all pages]
            //suggest to run once only
            if (webEmarsysSdkCustomerId) {
                // for user in login status
                if (!localStorage.getItem("emarsysLogin")) {
                    WebEmarsysSdk.push(function (res) {
                        WebEmarsysSdk.isSubscribed()
                            .then(function (res) {
                                const contactInfo = {
                                    fieldId: Number(emarsysFieldId),
                                    fieldValue: webEmarsysSdkCustomerId,
                                };
                                loginResult = WebEmarsysSdk.login(contactInfo).then(function (
                                    res
                                ) {
                                    //console.log("Login Result: " + res);
                                    if (res) {
                                        localStorage.setItem("emarsysLogin", "login");
                                    }
                                });
                            })
                            .catch(function (err) {
                                console.error("Is subscribed error", err);
                            });
                    });
                }
            } else {
                //for visitor (anonymous)
                if (localStorage.getItem("emarsysLogin")) {
                    WebEmarsysSdk.push(function (res) {
                        WebEmarsysSdk.isSubscribed()
                            .then(function (res) {
                                logoutResult = WebEmarsysSdk.logout().then(function (res) {
                                    //console.log("Logout Result: " + res);
                                    if (res) {
                                        localStorage.removeItem("emarsysLogin");
                                    }
                                });
                            })
                            .catch(function (err) {
                                console.error("Is subscribed error", err);
                            });
                    });
                }
            }
            // login / Logout - end
    
            // unsubscribe() - [the page after web push opt-out]
            // unsubscribe - start
            // WebEmarsysSdk.push(function (res) {
            // 	WebEmarsysSdk.unsubscribe();
            // 	localStorage.removeItem("emarsysSubscribe");
            // });
            // unsubscribe - end
    
    
            // 设置 cookie 的函数
            function emarsysSetCookie(name, value, expires) {
                var expiresString = "";
                if (expires) {
                    expiresString = "; expires=" + expires.toUTCString();
                }
                document.cookie =
                    name + "=" + (value || "") + expiresString + "; SameSite=None; Secure; path=/";
            }
    
            function emarsysGetCookie(name) {
                var nameEQ = name + "=";
                var ca = document.cookie.split(";");
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == " ") c = c.substring(1, c.length);
                    if (c.indexOf(nameEQ) == 0)
                        return c.substring(nameEQ.length, c.length);
                }
                return null;
            }
    
            // 计算到午夜的时间
            function emarsysGetMidnightExpiry() {
                var now = new Date();
                var midnight = new Date();
                midnight.setHours(24, 0, 0, 0); // 设置为今天的24点，即午夜
                return midnight;
            }
    
    
            function hideEmarsysPermissionPopup(status) {
                //console.log("Close popup or set cookie");
                clearInterval(emarsysPopupHideTimer);
                emarsysPopupHideTimer = null;
                clearInterval(emarsysSubscribePopupShowTimer);
                emarsysSubscribePopupShowTimer = null;
                if (status != "accept") {
                    emarsysSetHTMLPopupCookie();
                }
    
                if (emarsysPopupRootElement) {
                    emarsysPopupRootElement.classList.remove("flex");
                }
            }
    
            function emarsysShowHTMLPopup() {
                //  不在checkout页面显示弹窗且同意或拒绝过弹窗，则不显示弹窗
                if (
                    emarsysPopupRootElement &&
                    !emarsysGetCookie("emarsysClosePopup") &&
                    !permissionGrantedRejectedWebPush && !document.body.classList.contains("checkout-index-index")
                ) {
                    emarsysPopupRootElement.classList.add("flex");
                    if (!emarsysIsChrome()) {
                        emarsysVisibilityTimeoutCallback()
                    }
    
                }
            }
    
            // logic to display HTML popup
    
            function isIOS() {
                userAgent = window.navigator.userAgent.toLowerCase();
                return /iphone|ipad|ipod/.test(userAgent);
            }
    
            function isStandaloneWebApp() {
                var isStandaloneWebAppValue = false;
    
                if (window.matchMedia("(display-mode: standalone)").matches) {
                    // The website is being viewed as a standalone web app
                    //console.log("Website is being viewed as a web app");
                    isStandaloneWebAppValue = true;
                }
                return isStandaloneWebAppValue;
            }
    
            var permissionGrantedRejectedWebPush = false;
            var permissionGrantedWebPush = false;
            var isSubscribedStatus = false;
    
            // If it is not an iOS device, it will run the following logic for HTML pop-up window.
            if (isIOS() && !isStandaloneWebApp()) {
                //console.log("Not an iOS device or standalone web app");
                // no action for iOS and browser			
    
            } else {
                WebEmarsysSdk.push([
                    "onReady",
                    function (res) {
                        WebEmarsysSdk.push([
                            "onPermissionGranted",
                            function (res) {
                                //Result: The user has subscribed web push
                                //console.log("EVENT: onPermissionGranted");
                                permissionGrantedRejectedWebPush = true;
                                permissionGrantedWebPush = true;
                                                            //console.log("trackCustomEvent:", typeof window.trackCustomEvent);
                                   if (typeof window.trackCustomEvent === 'function') {
                                   window.trackCustomEvent("web_pushmessage_btn",true)
                                   }
                            },
                        ]);
                        WebEmarsysSdk.push([
                            "onPermissionDenied",
                            function (res) {
                                //result: The user has rejected web push
                                //console.log("EVENT: onPermissionDenied");
                                permissionGrantedRejectedWebPush = true;
                                                            //console.log("trackCustomEvent:", typeof window.trackCustomEvent);
                            if (typeof window.trackCustomEvent === 'function') {
                                window.trackCustomEvent("web_pushmessage_btn",false)
                            }
                            },
                        ]);
                        WebEmarsysSdk.isSubscribed()
                            .then(function (e) {
                                //result: the user subscribes to Emarsys web push
                                isSubscribedStatus = e;
                            })
                            .catch(function (err) {});
    
                        //console.log("onReady,", 'The count down began:', emarsysTimeout);
                        // emarsysSubscribePopupShowTimer = setTimeout(emrsysFuncHTMLPopup, emarsysTimeout);
                        // 检查 localStorage 中是否已有开始时间
                        let startTime = localStorage.getItem('startTime');
                        if (!startTime) {
                            // 如果没有，设置当前时间为开始时间并存储到 localStorage
                            startTime = Date.now();
                            localStorage.setItem('startTime', startTime);
                        }
                        // 计算目标时间
                        const targetTime = parseInt(startTime, 10) + emarsysTimeout;
                        //console.log('targetTime:', targetTime);
                        if (targetTime) {
                            const remainingTime = targetTime - Date.now();
                            if (remainingTime > 0) {
                                //console.log('The count down ended:', remainingTime);
                                emarsysSubscribePopupShowTimer = setTimeout(emrsysFuncHTMLPopup, remainingTime);
                            } else {
                                localStorage.removeItem('startTime');
                            }
                        }
                        //Since above asynchronous function may take time to call back, it setup to wait for 2 seconds to the next logic.
                    },
                ]);
            }
    
            function emarsysSetHTMLPopupCookie() {
                const expiryDate = emarsysGetMidnightExpiry();
                emarsysSetCookie("emarsysClosePopup", "1", expiryDate);
            }
    
            function emarsysSubscribe() {
                // 判断是否是执行过WebEmarsysSdk.subscribe() 并且不在checkout页面
                if (!emarsysGetCookie("emarsysClosePopup") && !document.body.classList.contains("checkout-index-index")) {
                    WebEmarsysSdk.subscribe();
                    emarsysSetHTMLPopupCookie();
                }
    
            }
    
    
            function emrsysFuncHTMLPopup() {
                
                //Re-subscribe web push
                if (permissionGrantedWebPush == true && isSubscribedStatus == false) {
                    //console.log("Resubscribe: WebEmarsysSdk.subscribe()");
                    WebEmarsysSdk.subscribe();
                }
    
                if (!permissionGrantedRejectedWebPush) {
                    // If the web push has not been subscribed or rejected in this browser, you can run your logic for HTML popup.
                    //console.log("Show HTML popup");
                    !emarsysIsChrome() ? emarsysShowHTMLPopup() : emarsysSubscribe();
                }
    
                localStorage.removeItem('startTime');
            }
        </script>
<script type="text/x-magento-init">
    {
        "*": {
            "subscribeModal": {}
        }
    }
</script>
<script type="b582c3d0dfb6bd35c494053c-text/javascript">
require(["jquery", 'toastr'], function ($,toastr) {
    'use strict';
    // 在页面加载时检查是否有注册成功的标志
    $(document).ready(function() {
        var toastrOptions  = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "3000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    
        const subscribeRegisterStatus = localStorage.getItem('subscribeRregisterSuccess')
        if (subscribeRegisterStatus && subscribeRegisterStatus.trim() !== '') {
            const addToastrOptions = {...toastrOptions,toastClass:"toast-subscribe-register-success"}
            toastr["success"](subscribeRegisterStatus,'',addToastrOptions)
            localStorage.removeItem('subscribeRregisterSuccess');
        }
    });
});
</script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="b582c3d0dfb6bd35c494053c-|49" defer></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"580c2e2b1b0a4f51ae17ae80996ff79f","server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>
